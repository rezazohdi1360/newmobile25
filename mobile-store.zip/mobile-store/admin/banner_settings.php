<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

if (!isAdmin()) redirect('../login.php');

/* ---------- توابع کمکی ---------- */
function bs_clean_url($u) {
    $u = trim((string)$u);
    if ($u === '') return '';
    if (preg_match('#^(https?://|/)#i', $u)) return $u;
    if (preg_match('#^[A-Za-z0-9_./?=&%\-]+$#', $u)) return $u;
    return '';
}

function bs_preview_src($src) {
    $src = trim((string)$src);
    if ($src === '') return '';
    if (preg_match('#^https?://#i', $src)) return $src;
    return '../' . ltrim($src, '/');
}

function bs_upload_image($file, $slot, $w = 0, $h = 0, $suffix = '') {
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) return null;

    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('خطا در آپلود فایل');
    }
    if (($file['size'] ?? 0) > 5 * 1024 * 1024) {
        throw new Exception('حجم تصویر باید کمتر از ۵ مگابایت باشد');
    }

    $info = @getimagesize($file['tmp_name']);
    if (!$info) throw new Exception('فایل انتخاب‌شده تصویر معتبر نیست');

    $mime = $info['mime'] ?? '';
    $map = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
    ];
    if (!isset($map[$mime])) {
        throw new Exception('فرمت مجاز: JPG, PNG, WEBP, GIF');
    }

    $ext = $map[$mime];
    $dir = __DIR__ . '/../assets/grocery-banners';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);

    // نام فایل شامل شماره اسلاید: main_1-...، main_2-...
    $filename = $slot . ($suffix !== '' ? $suffix : '') . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(3)) . '.' . $ext;
    $dest = $dir . '/' . $filename;

    $w = max(0, (int)$w);
    $h = max(0, (int)$h);

    if (($w > 0 || $h > 0) && function_exists('imagecreatetruecolor')) {
        $data = file_get_contents($file['tmp_name']);
        $src = @imagecreatefromstring($data);
        if (!$src) throw new Exception('خواندن تصویر برای تغییر سایز ممکن نشد');

        $ow = imagesx($src);
        $oh = imagesy($src);

        if ($w > 0 && $h > 0) {
            $nw = $w;
            $nh = $h;
        } elseif ($w > 0) {
            $nw = $w;
            $nh = (int)round($oh * $w / $ow);
        } else {
            $nh = $h;
            $nw = (int)round($ow * $h / $oh);
        }

        $nw = max(1, min($nw, 4000));
        $nh = max(1, min($nh, 4000));

        $dst = imagecreatetruecolor($nw, $nh);

        if ($mime === 'image/png' || $mime === 'image/webp') {
            imagealphablending($dst, false);
            imagesavealpha($dst, true);
            $trans = imagecolorallocatealpha($dst, 0, 0, 0, 127);
            imagefilledrectangle($dst, 0, 0, $nw, $nh, $trans);
        }

        imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $ow, $oh);

        if ($ext === 'jpg') {
            imagejpeg($dst, $dest, 88);
        } elseif ($ext === 'png') {
            imagepng($dst, $dest, 6);
        } elseif ($ext === 'webp') {
            imagewebp($dst, $dest, 88);
        } else {
            imagegif($dst, $dest);
        }

        imagedestroy($src);
        imagedestroy($dst);
    } else {
        if (!move_uploaded_file($file['tmp_name'], $dest)) {
            throw new Exception('ذخیره فایل ممکن نشد');
        }
    }

    return 'assets/grocery-banners/' . $filename;
}

/* ---------- اسلات‌های بنر (هر اسلات ۳ تصویر) ---------- */
$slots = [
    'main' => [
        'label'   => 'بنر اصلی بزرگ',
        'images'  => [
            'assets/grocery-banners/01-hero-basket.jpg',
            'assets/grocery-banners/01-hero-basket_2.jpg',
            'assets/grocery-banners/01-hero-basket_3.jpg',
        ],
        'link'    => 'archive.php',
        'alt'     => 'سبد خرید مواد غذایی',
        'width'   => 1600,
        'height'  => 600,
    ],
    'cat1' => [
        'label'   => 'بنر دسته ۱ — لبنیات و تخم‌مرغ',
        'images'  => [
            'assets/grocery-banners/02-dairy-eggs.jpg',
            'assets/grocery-banners/02-dairy-eggs_2.jpg',
            'assets/grocery-banners/02-dairy-eggs_3.jpg',
        ],
        'link'    => 'archive.php?sort=best',
        'alt'     => 'لبنیات و تخم مرغ تازه',
        'width'   => 800,
        'height'  => 600,
    ],
    'cat2' => [
        'label'   => 'بنر دسته ۲ — حبوبات و برنج',
        'images'  => [
            'assets/grocery-banners/03-legumes-rice.jpg',
            'assets/grocery-banners/03-legumes-rice_2.jpg',
            'assets/grocery-banners/03-legumes-rice_3.jpg',
        ],
        'link'    => 'archive.php?sort=best',
        'alt'     => 'حبوبات و برنج',
        'width'   => 800,
        'height'  => 600,
    ],
    'cat3' => [
        'label'   => 'بنر دسته ۳ — مرغ و ماهی',
        'images'  => [
            'assets/grocery-banners/04-chicken-fish.jpg',
            'assets/grocery-banners/04-chicken-fish_2.jpg',
            'assets/grocery-banners/04-chicken-fish_3.jpg',
        ],
        'link'    => 'archive.php',
        'alt'     => 'مرغ و ماهی تازه',
        'width'   => 800,
        'height'  => 600,
    ],
    'bottom' => [
        'label'   => 'بنر پایین صفحه',
        'images'  => [
            'assets/005.jpg',
            'assets/005_2.jpg',
            'assets/005_3.jpg',
        ],
        'link'    => 'archive.php',
        'alt'     => 'از حبوبات و چای تا لبنیات و گوشت تازه',
        'width'   => 984,
        'height'  => 319,
    ],
    'trust_badge' => [
        'label'   => 'نماد اعتماد الکترونیک (فوتر)',
        'images'  => [
            'assets/trust-badge.png',
            'assets/trust-badge.png',
            'assets/trust-badge.png',
        ],
        'link'    => '#',
        'alt'     => 'نماد اعتماد الکترونیک - جهت اطمینان کلیک نمایید',
        'width'   => 150,
        'height'  => 150,
    ],
];

$saved = json_decode(site_get($pdo, 'home_banners', ''), true);
if (!is_array($saved)) $saved = [];

/* ---------- مهاجرت خودکار: اگر داده قدیمی با کلید image بود، به images تبدیل کن ---------- */
foreach ($slots as $key => $def) {
    if (!isset($saved[$key]) || !is_array($saved[$key])) continue;
    if (isset($saved[$key]['image']) && !isset($saved[$key]['images'])) {
        $oldImg = $saved[$key]['image'];
        $saved[$key]['images'] = [$oldImg, $oldImg, $oldImg];
    }
}

$message = '';
$errors = [];

if (empty($_SESSION['csrf_banners'])) {
    $_SESSION['csrf_banners'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf_banners'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_banners'] ?? '', $_POST['csrf'] ?? '')) {
        $errors[] = 'توکن امنیتی نامعتبر است';
    } else {
        foreach ($slots as $key => $def) {
            $row = isset($saved[$key]) && is_array($saved[$key]) ? $saved[$key] : [];
            $oldImages = $row['images'] ?? $def['images'];
            if (!is_array($oldImages) || count($oldImages) < 3) {
                $oldImages = array_pad($oldImages, 3, '');
            }

            $link = bs_clean_url($_POST['link'][$key] ?? '');
            $alt  = trim((string)($_POST['alt'][$key] ?? ''));
            $w    = (int)($_POST['width'][$key] ?? 0);
            $h    = (int)($_POST['height'][$key] ?? 0);

            $finalImages = [];

            for ($i = 1; $i <= 3; $i++) {
                $image = bs_clean_url($_POST['image_url'][$key][$i] ?? '');

                $file = [
                    'name'     => $_FILES['image']['name'][$key][$i] ?? '',
                    'type'     => $_FILES['image']['type'][$key][$i] ?? '',
                    'tmp_name' => $_FILES['image']['tmp_name'][$key][$i] ?? '',
                    'error'    => $_FILES['image']['error'][$key][$i] ?? UPLOAD_ERR_NO_FILE,
                    'size'     => $_FILES['image']['size'][$key][$i] ?? 0,
                ];

                try {
                    $uploaded = bs_upload_image($file, $key, $w, $h, '_' . $i);
                    if ($uploaded) $image = $uploaded;
                } catch (Exception $e) {
                    $errors[] = $def['label'] . ' (اسلاید ' . $i . '): ' . $e->getMessage();
                }

                $finalImages[$i] = $image ?: ($oldImages[$i - 1] ?? $def['images'][$i - 1]);
            }

            $saved[$key] = [
                'images' => array_values($finalImages),
                'link'   => $link ?: ($row['link'] ?? $def['link']),
                'alt'    => $alt !== '' ? $alt : ($row['alt'] ?? $def['alt']),
                'width'  => $w,
                'height' => $h,
            ];
        }

        if (!$errors) {
            site_set($pdo, 'home_banners', json_encode($saved, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
            $message = 'تنظیمات بنرها با موفقیت ذخیره شد.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>مدیریت بنرها | <?= htmlspecialchars(SITE_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
<style>
*{box-sizing:border-box}
body{font-family:'Vazirmatn',tahoma,sans-serif;background:#f0f0f1;color:#1d2327;margin:0;line-height:1.8}
a{text-decoration:none;color:#2271b1}
.container{max-width:1100px;margin:28px auto;padding:0 20px}
.top{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:20px}
.top h1{font-size:22px;margin:0}
.top a{background:#fff;border:1px solid #c3c4c7;padding:8px 14px;border-radius:4px;font-size:13px}
.alert{padding:12px 16px;border-radius:4px;margin-bottom:16px;font-size:13px}
.ok{background:#edfaef;border:1px solid #b8e6bf;color:#116329}
.err{background:#fcf0f1;border:1px solid #f0b7bb;color:#8a2424}
.slot{background:#fff;border:1px solid #c3c4c7;border-radius:6px;padding:18px;margin-bottom:18px}
.slot h2{font-size:16px;margin:0 0 12px;border-bottom:1px solid #f0f0f1;padding-bottom:10px}
.thumbs{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:14px}
.thumb-box{background:#f6f7f7;border:1px solid #dcdcde;border-radius:5px;padding:6px;text-align:center}
.thumb-box img{width:100%;height:110px;object-fit:contain;display:block;margin:0 auto 6px}
.thumb-box .cap{font-size:11.5px;color:#50575e;font-weight:700}
fieldset.slide-box{border:1px dashed #c3c4c7;border-radius:5px;padding:12px;margin-bottom:12px;background:#fafbfc}
fieldset.slide-box legend{font-size:12.5px;font-weight:800;color:#2271b1;padding:0 6px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.field{display:flex;flex-direction:column;gap:5px}
.field label{font-size:12.5px;font-weight:700;color:#50575e}
.field input[type=text],.field input[type=number],.field input[type=file]{
    width:100%;padding:9px 11px;border:1px solid #8c8f94;border-radius:4px;font-family:inherit;font-size:13px;background:#fff
}
.note{font-size:11.5px;color:#646970;margin-top:4px}
.actions{position:sticky;bottom:0;background:#f0f0f1;padding:14px 0;display:flex;gap:10px;z-index:50;border-top:1px solid #dcdcde}
.actions button{background:#2271b1;color:#fff;border:0;border-radius:4px;padding:11px 24px;font-family:inherit;font-weight:700;cursor:pointer}
.actions button:hover{background:#135e96}
@media(max-width:700px){.grid{grid-template-columns:1fr}.thumbs{grid-template-columns:1fr 1fr 1fr;gap:6px}.thumb-box img{height:70px}}
</style>
</head>
<body>
<div class="container">
    <div class="top">
        <h1>🖼 مدیریت بنرهای صفحه اصلی</h1>
        <a href="index.php">← بازگشت به داشبورد</a>
    </div>

    <?php if ($message): ?><div class="alert ok"><?= htmlspecialchars($message) ?></div><?php endif; ?>
    <?php if ($errors): ?><div class="alert err"><?= implode('<br>', array_map('htmlspecialchars', $errors)) ?></div><?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf) ?>">

        <?php foreach ($slots as $key => $def):
            $row = array_merge($def, $saved[$key] ?? []);
            if (!isset($row['images']) || !is_array($row['images']) || count($row['images']) < 3) {
                $row['images'] = array_pad($row['images'] ?? [], 3, '');
            }
        ?>
        <section class="slot">
            <h2><?= htmlspecialchars($def['label']) ?></h2>

            <div class="thumbs">
                <?php for ($i = 1; $i <= 3; $i++): ?>
                    <div class="thumb-box">
                        <img src="<?= htmlspecialchars(bs_preview_src($row['images'][$i-1])) ?>" alt="">
                        <div class="cap">اسلاید <?= $i ?></div>
                    </div>
                <?php endfor; ?>
            </div>

            <?php for ($i = 1; $i <= 3; $i++): ?>
            <fieldset class="slide-box">
                <legend>اسلاید <?= $i ?></legend>
                <div class="grid">
                    <div class="field">
                        <label>آپلود تصویر اسلاید <?= $i ?></label>
                        <input type="file" name="image[<?= $key ?>][<?= $i ?>]" accept="image/jpeg,image/png,image/webp,image/gif">
                        <span class="note">حداکثر ۵ مگابایت — JPG / PNG / WEBP / GIF</span>
                    </div>
                    <div class="field">
                        <label>یا آدرس تصویر اسلاید <?= $i ?></label>
                        <input type="text" name="image_url[<?= $key ?>][<?= $i ?>]" value="<?= htmlspecialchars($row['images'][$i-1]) ?>" placeholder="assets/... یا https://...">
                        <span class="note">اگر فایل آپلود شود، این مقدار با فایل جدید جایگزین می‌شود.</span>
                    </div>
                </div>
            </fieldset>
            <?php endfor; ?>

            <div class="grid" style="margin-top:6px">
                <div class="field">
                    <label>لینک / بک‌لینک (مشترک هر ۳ اسلاید)</label>
                    <input type="text" name="link[<?= $key ?>]" value="<?= htmlspecialchars($row['link']) ?>" placeholder="archive.php یا https://example.com">
                </div>
                <div class="field">
                    <label>متن جایگزین (alt) مشترک</label>
                    <input type="text" name="alt[<?= $key ?>]" value="<?= htmlspecialchars($row['alt']) ?>">
                </div>
                <div class="field">
                    <label>عرض نهایی تصاویر (px)</label>
                    <input type="number" name="width[<?= $key ?>]" value="<?= (int)($row['width'] ?? 0) ?>" min="0" placeholder="مثلاً 1600">
                </div>
                <div class="field">
                    <label>ارتفاع نهایی تصاویر (px)</label>
                    <input type="number" name="height[<?= $key ?>]" value="<?= (int)($row['height'] ?? 0) ?>" min="0" placeholder="مثلاً 600">
                    <span class="note">اگر فقط یکی از عرض/ارتفاع را وارد کنید، نسبت تصویر حفظ می‌شود.</span>
                </div>
            </div>
        </section>
        <?php endforeach; ?>

        <div class="actions">
            <button type="submit">💾 ذخیره تنظیمات بنرها</button>
        </div>
    </form>
</div>
</body>
</html>