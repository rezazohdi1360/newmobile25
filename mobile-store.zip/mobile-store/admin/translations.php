<?php
/**
 * مدیریت ترجمه‌ی محتوای سایت (انگلیسی / عربی)
 *  - متن رابط (دکمه‌ها، منوها، ...) از lang/en.php و lang/ar.php می‌آید.
 *  - اینجا محتوای پایگاه‌داده (نام محصول، دسته‌بندی، مشخصات، تنظیمات سایت) و «واژه‌نامه» ویرایش می‌شود.
 *  - «ترجمه‌ی خودکار»: با واژه‌نامه‌ی داخلی (برندها و واژه‌های رایج) و در صورت فعال بودن cURL با MyMemory.
 */
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/mail.php';
require_once '../includes/i18n.php';

if (!isAdmin()) redirect('../login.php');
i18n_ensure($pdo);

$langs = ['en' => 'English', 'ar' => 'العربية'];
$lang  = isset($langs[$_GET['lang'] ?? '']) ? $_GET['lang'] : 'en';
$types = ['products' => 'نام محصولات', 'short' => 'توضیح کوتاه محصولات', 'categories' => 'دسته‌بندی‌ها', 'specs' => 'مشخصات فنی', 'settings' => 'تنظیمات سایت', 'terms' => 'واژه‌نامه'];
$type  = isset($types[$_GET['type'] ?? '']) ? $_GET['type'] : 'products';
$q     = trim((string)($_GET['q'] ?? ''));
$only  = ($_GET['only'] ?? '') === 'missing';
$page  = max(1, (int)($_GET['page'] ?? 1));
$per   = 40;
$isMy  = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql';
$back  = 'translations.php?' . http_build_query(array_filter(['lang' => $lang, 'type' => $type, 'q' => $q, 'only' => $only ? 'missing' : '', 'page' => $page > 1 ? $page : ''], 'strlen'));

/** همه‌ی متن‌های فارسی یک نوع (تکراری‌ها یکی می‌شود) */
function tr_sources(PDO $pdo, $type) {
    $rows = [];
    $col = function ($sql) use ($pdo) { try { return $pdo->query($sql)->fetchAll(PDO::FETCH_COLUMN); } catch (Throwable $e) { return []; } };
    if ($type === 'products')   $rows = $col("SELECT DISTINCT name FROM products WHERE name IS NOT NULL AND name <> '' ORDER BY name");
    if ($type === 'short')      $rows = $col("SELECT DISTINCT short_desc FROM products WHERE short_desc IS NOT NULL AND short_desc <> '' ORDER BY short_desc");
    if ($type === 'categories') $rows = $col("SELECT DISTINCT name FROM categories WHERE name <> '' ORDER BY name");
    if ($type === 'specs') {
        $rows = array_merge($col("SELECT DISTINCT group_name FROM product_specs WHERE group_name <> ''"),
                            $col("SELECT DISTINCT spec_key FROM product_specs WHERE spec_key <> ''"),
                            $col("SELECT DISTINCT spec_value FROM product_specs WHERE spec_value <> '' AND CHAR_LENGTH(spec_value) < 120"));
    }
    if ($type === 'settings') {
        $d = site_defaults();
        $rows = [SITE_NAME, SITE_OWNER, SITE_ADDRESS, SITE_HOURS, site_get($pdo, 'site_tagline', 'تخصصی‌ترین مرجع ابزارآلات')];
        foreach (['pricelist_title', 'pricelist_note'] as $k) $rows[] = site_get($pdo, $k, '');
        $rows = array_merge($rows, $col("SELECT svalue FROM site_settings WHERE skey LIKE 'hero%' OR skey LIKE 'banner%' OR skey LIKE 'promo%' OR skey LIKE 'footer%' OR skey LIKE 'about%'"));
    }
    $out = [];
    foreach ($rows as $r) {
        $r = trim((string)$r);
        if ($r === '' || !preg_match('/[\x{0600}-\x{06FF}]/u', $r)) continue;   // فقط متن‌های دارای حروف فارسی/عربی
        $out[i18n_norm($r)] = $r;
    }
    return array_values($out);
}

function tr_upsert(PDO $pdo, $lang, $src, $dst, $term = 0, $auto = 0) {
    $h = md5(i18n_norm($src)); $now = date('Y-m-d H:i:s');
    if (trim($dst) === '') {
        $pdo->prepare("DELETE FROM i18n_texts WHERE lang = ? AND src_hash = ?")->execute([$lang, $h]);
        return;
    }
    $sql = "INSERT INTO i18n_texts (lang, src_hash, src, dst, is_term, auto_made, updated_at) VALUES (?,?,?,?,?,?,?) "
         . ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql'
            ? "ON DUPLICATE KEY UPDATE dst = VALUES(dst), is_term = VALUES(is_term), auto_made = VALUES(auto_made), updated_at = VALUES(updated_at)"
            : "ON CONFLICT(lang, src_hash) DO UPDATE SET dst = excluded.dst, is_term = excluded.is_term, auto_made = excluded.auto_made, updated_at = excluded.updated_at");
    $pdo->prepare($sql)->execute([$lang, $h, i18n_norm($src), trim($dst), $term, $auto, $now]);
}

/** ترجمه با واژه‌نامه فقط اگر هیچ حرف فارسی باقی نماند (وگرنه null) */
function tr_glossary(PDO $pdo, $lang, $src, $needFull = true) {
    $GLOBALS['I18N_PDO'] = $pdo;
    $out = i18n_tr($src, $lang, false);
    if ($out === $src) return null;
    if ($needFull && preg_match('/[\x{0600}-\x{06FF}]/u', $out)) return null;
    return $out;
}

/** ترجمه با MyMemory (رایگان؛ نیاز به cURL و اینترنت سرور) */
function tr_mymemory($text, $lang) {
    if (!function_exists('curl_init')) return null;
    $ch = curl_init('https://api.mymemory.translated.net/get?q=' . rawurlencode(mb_substr($text, 0, 450)) . '&langpair=fa|' . $lang);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 4]);
    $r = curl_exec($ch); curl_close($ch);
    if (!$r) return null;
    $j = json_decode($r, true);
    $t = $j['responseData']['translatedText'] ?? '';
    if ($t === '' || stripos($t, 'MYMEMORY WARNING') !== false || stripos($t, 'INVALID') !== false) return null;
    return html_entity_decode($t, ENT_QUOTES, 'UTF-8');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!mail_csrf_ok()) { setFlash('error', 'نشست شما منقضی شده است؛ دوباره تلاش کنید.'); redirect($back); }
    $act = $_POST['act'] ?? '';
    if ($act === 'save') {
        $n = 0;
        foreach ((array)($_POST['src'] ?? []) as $i => $src) {
            $dst = trim((string)($_POST['dst'][$i] ?? ''));
            $old = trim((string)($_POST['old'][$i] ?? ''));
            if ($dst === $old) continue;   // تغییری نکرده
            tr_upsert($pdo, $lang, $src, $dst, $type === 'terms' ? 1 : 0, 0);
            $n++;
        }
        setFlash('success', $n ? "$n ترجمه ذخیره شد." : 'تغییری برای ذخیره نبود.');
    } elseif ($act === 'auto') {
        $have = [];
        $st = $pdo->prepare("SELECT src FROM i18n_texts WHERE lang = ?"); $st->execute([$lang]);
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $s) $have[i18n_norm($s)] = 1;
        $n = 0;
        foreach (tr_sources($pdo, $type) as $src) {
            if (isset($have[i18n_norm($src)])) continue;
            $t = tr_glossary($pdo, $lang, $src);
            if ($t !== null) { tr_upsert($pdo, $lang, $src, $t, 0, 1); $n++; }
        }
        setFlash('success', "$n مورد با واژه‌نامه ترجمه شد (فقط مواردی که کاملاً پوشش داده می‌شدند). بقیه را دستی یا با «MyMemory» تکمیل کنید.");
    } elseif ($act === 'mymemory') {
        $have = [];
        $st = $pdo->prepare("SELECT src FROM i18n_texts WHERE lang = ?"); $st->execute([$lang]);
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $s) $have[i18n_norm($s)] = 1;
        if (!function_exists('curl_init')) {
            setFlash('error', 'افزونه‌ی cURL در PHP فعال نیست.');
        } else {
            $n = 0; $fail = 0;
            foreach (tr_sources($pdo, $type) as $src) {
                if (isset($have[i18n_norm($src)])) continue;
                if ($n + $fail >= 20) break;   // هر بار حداکثر ۲۰ مورد (محدودیت رایگان سرویس)
                $t = tr_mymemory($src, $lang);
                if ($t === null) { $fail++; if ($fail >= 3) break; continue; }
                tr_upsert($pdo, $lang, $src, $t, 0, 1); $n++;
            }
            setFlash($n ? 'success' : 'error', $n ? "$n مورد با MyMemory ترجمه شد؛ لطفاً مرور کنید." : 'ترجمه‌ی آنلاین انجام نشد (اینترنت سرور یا سهمیه‌ی سرویس).');
        }
    } elseif ($act === 'add_term') {
        $fa = trim((string)($_POST['fa'] ?? ''));
        $any = false;
        foreach ($langs as $lk => $_) {
            $v = trim((string)($_POST['t_' . $lk] ?? ''));
            if ($fa !== '' && $v !== '') { tr_upsert($pdo, $lk, $fa, $v, 1, 0); $any = true; }
        }
        setFlash($any ? 'success' : 'error', $any ? 'عبارت به واژه‌نامه اضافه شد.' : 'متن فارسی و حداقل یک ترجمه را وارد کنید.');
    } elseif ($act === 'delete') {
        $pdo->prepare("DELETE FROM i18n_texts WHERE id = ?")->execute([(int)($_POST['id'] ?? 0)]);
        setFlash('success', 'حذف شد.');
    }
    redirect($back);
}

// ── لیست ──
$GLOBALS['I18N_PDO'] = $pdo;
$existing = [];
$st = $pdo->prepare("SELECT src, dst, auto_made FROM i18n_texts WHERE lang = ?"); $st->execute([$lang]);
foreach ($st->fetchAll() as $r) $existing[i18n_norm($r['src'])] = $r;

if ($type === 'terms') {
    $st = $pdo->prepare("SELECT id, src, dst FROM i18n_texts WHERE lang = ? AND is_term = 1 ORDER BY id DESC"); $st->execute([$lang]);
    $terms = $st->fetchAll();
    $list = []; $total = count($terms); $pages = 1;
} else {
    $all = tr_sources($pdo, $type);
    if ($q !== '') $all = array_values(array_filter($all, function ($s) use ($q) { return mb_stripos($s, $q) !== false; }));
    if ($only) $all = array_values(array_filter($all, function ($s) use ($existing) { return !isset($existing[i18n_norm($s)]); }));
    $total = count($all); $pages = max(1, (int)ceil($total / $per));
    $page = min($page, $pages);
    $list = array_slice($all, ($page - 1) * $per, $per);
}
$cnt = ['done' => 0, 'all' => 0];
if ($type !== 'terms') { $every = tr_sources($pdo, $type); $cnt['all'] = count($every); foreach ($every as $s) if (isset($existing[i18n_norm($s)])) $cnt['done']++; }

$pageTitle = 'مدیریت ترجمه‌ها';
require_once '../includes/header.php';
$inp = 'w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs';
$tab = function ($l, $t) use ($lang, $type) { return '?' . http_build_query(['lang' => $l ?? $lang, 'type' => $t ?? $type]); };
?>
<div class="max-w-6xl mx-auto px-4 py-8">
  <div class="flex justify-between items-center mb-5 flex-wrap gap-3">
    <h1 class="text-2xl font-black text-slate-900 flex items-center gap-2"><span class="w-2 h-7 bg-brand-orange rounded-full"></span>🌐 مدیریت ترجمه‌ها</h1>
    <div class="flex gap-2 flex-wrap">
      <a href="../en/" target="_blank" class="bg-brand-orange hover:bg-brand-hover text-white font-bold px-4 py-2.5 rounded-xl text-xs">👁 سایت انگلیسی</a>
      <a href="../ar/" target="_blank" class="bg-brand-orange hover:bg-brand-hover text-white font-bold px-4 py-2.5 rounded-xl text-xs">👁 سایت عربی</a>
      <a href="index.php" class="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-4 py-2.5 rounded-xl text-xs">← داشبورد</a>
    </div>
  </div>

  <div class="bg-amber-50 border border-amber-200 text-amber-900 rounded-2xl p-3 text-[11px] leading-6 mb-4">
    متن‌های ثابت سایت (دکمه‌ها، منوها، فرم‌ها) به‌صورت خودکار ترجمه می‌شوند. اینجا <b>محتوای ثبت‌شده توسط شما</b> (نام محصول، دسته‌بندی، مشخصات و ...) را ترجمه کنید.
    هر متنی که ترجمه نداشته باشد، به همان فارسی نمایش داده می‌شود. «واژه‌نامه» عبارت‌هایی است که داخل هر متن (مثلاً نام برند) جایگزین می‌شود.
  </div>

  <div class="flex gap-2 mb-3 flex-wrap items-center">
    <?php foreach ($langs as $lk => $ln): ?>
      <a href="<?= $tab($lk, null) ?>" class="px-4 py-2 rounded-xl text-xs font-bold <?= $lk === $lang ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-700' ?>"><?= $ln ?></a>
    <?php endforeach; ?>
    <span class="w-px h-6 bg-slate-200 mx-1"></span>
    <?php foreach ($types as $tk => $tn): ?>
      <a href="<?= $tab(null, $tk) ?>" class="px-3 py-2 rounded-xl text-xs font-bold <?= $tk === $type ? 'bg-brand-orange text-white' : 'bg-white border border-slate-200 text-slate-700' ?>"><?= $tn ?></a>
    <?php endforeach; ?>
  </div>

<?php if ($type === 'terms'): ?>
  <form method="post" class="bg-white border border-slate-200 rounded-2xl p-4 mb-4 grid md:grid-cols-4 gap-3 items-end">
    <?= mail_csrf_field() ?><input type="hidden" name="act" value="add_term">
    <div><label class="block text-xs font-bold text-slate-600 mb-1">عبارت فارسی</label><input name="fa" class="<?= $inp ?>" required></div>
    <div><label class="block text-xs font-bold text-slate-600 mb-1">English</label><input name="t_en" dir="ltr" class="<?= $inp ?>"></div>
    <div><label class="block text-xs font-bold text-slate-600 mb-1">العربية</label><input name="t_ar" class="<?= $inp ?>"></div>
    <div><button class="bg-slate-900 hover:bg-black text-white font-bold px-6 py-2.5 rounded-xl text-xs">➕ افزودن به واژه‌نامه</button></div>
  </form>
  <div class="bg-white border border-slate-200 rounded-2xl overflow-hidden">
    <table class="w-full text-xs"><thead class="bg-slate-50 text-slate-500"><tr><th class="p-3 text-right">فارسی</th><th class="p-3 text-right"><?= $langs[$lang] ?></th><th class="p-3 w-16"></th></tr></thead><tbody>
    <?php foreach ($terms as $t): ?>
      <tr class="border-t border-slate-100"><td class="p-3"><?= sanitize($t['src']) ?></td><td class="p-3" dir="auto"><?= sanitize($t['dst']) ?></td>
        <td class="p-3"><form method="post" onsubmit="return confirm('حذف شود؟')"><?= mail_csrf_field() ?><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>"><button class="text-red-500">حذف</button></form></td></tr>
    <?php endforeach; if (!$terms): ?><tr><td colspan="3" class="p-8 text-center text-slate-400">هنوز عبارتی در واژه‌نامه نیست.</td></tr><?php endif; ?>
    </tbody></table>
  </div>
<?php else: ?>
  <div class="flex gap-2 flex-wrap items-center mb-3">
    <form method="get" class="flex gap-2 flex-wrap">
      <input type="hidden" name="lang" value="<?= $lang ?>"><input type="hidden" name="type" value="<?= $type ?>">
      <input type="search" name="q" value="<?= sanitize($q) ?>" placeholder="جستجو..." class="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs w-56">
      <label class="text-xs text-slate-600 flex items-center gap-1"><input type="checkbox" name="only" value="missing" <?= $only ? 'checked' : '' ?>> فقط بدون ترجمه</label>
      <button class="bg-white border border-slate-200 px-4 py-2 rounded-xl text-xs">🔍 فیلتر</button>
    </form>
    <span class="text-xs text-slate-500"><?= fa_digits($cnt['done']) ?> از <?= fa_digits($cnt['all']) ?> ترجمه شده</span>
    <form method="post" class="mr-auto flex gap-2"><?= mail_csrf_field() ?>
      <button name="act" value="auto" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded-xl text-xs" title="با واژه‌نامه‌ی داخلی (بدون اینترنت)">⚡ ترجمه‌ی خودکار با واژه‌نامه</button>
      <button name="act" value="mymemory" class="bg-sky-600 hover:bg-sky-700 text-white font-bold px-4 py-2 rounded-xl text-xs" title="ترجمه‌ی آنلاین، هر بار ۲۰ مورد">🌍 ۲۰ مورد با MyMemory</button>
    </form>
  </div>
  <form method="post" class="bg-white border border-slate-200 rounded-2xl overflow-hidden">
    <?= mail_csrf_field() ?><input type="hidden" name="act" value="save">
    <table class="w-full text-xs"><thead class="bg-slate-50 text-slate-500"><tr><th class="p-3 text-right w-1/2">فارسی (اصل)</th><th class="p-3 text-right"><?= $langs[$lang] ?></th></tr></thead><tbody>
    <?php foreach ($list as $i => $src):
        $ex = $existing[i18n_norm($src)] ?? null;
        $sugg = $ex ? null : tr_glossary($pdo, $lang, $src, false);
    ?>
      <tr class="border-t border-slate-100 align-top">
        <td class="p-3 leading-6"><?= sanitize($src) ?></td>
        <td class="p-3">
          <input type="hidden" name="src[<?= $i ?>]" value="<?= sanitize($src) ?>"><input type="hidden" name="old[<?= $i ?>]" value="<?= sanitize($ex['dst'] ?? '') ?>">
          <input type="text" name="dst[<?= $i ?>]" value="<?= sanitize($ex['dst'] ?? '') ?>" dir="<?= $lang === 'en' ? 'ltr' : 'rtl' ?>" class="<?= $inp ?>" placeholder="<?= $sugg !== null ? sanitize($sugg) : '' ?>">
          <?php if ($ex): ?><span class="text-[10px] <?= $ex['auto_made'] ? 'text-amber-600' : 'text-emerald-600' ?>"><?= $ex['auto_made'] ? 'خودکار — مرور کنید' : 'ثبت شده' ?></span>
          <?php elseif ($sugg !== null): ?><span class="text-[10px] text-slate-400">پیشنهاد واژه‌نامه (در سایت همین نمایش داده می‌شود؛ برای ثبت نهایی ذخیره کنید)</span><?php endif; ?>
        </td>
      </tr>
    <?php endforeach; if (!$list): ?><tr><td colspan="2" class="p-8 text-center text-slate-400">موردی پیدا نشد.</td></tr><?php endif; ?>
    </tbody></table>
    <?php if ($list): ?><div class="p-3 border-t border-slate-100 flex justify-between items-center">
      <button class="bg-slate-900 hover:bg-black text-white font-bold px-6 py-2.5 rounded-xl text-xs">💾 ذخیره‌ی ترجمه‌های این صفحه</button>
      <span class="text-xs text-slate-500">صفحه <?= fa_digits($page) ?> از <?= fa_digits($pages) ?></span>
    </div><?php endif; ?>
  </form>
  <?php if ($pages > 1): ?><div class="flex gap-1 mt-4 flex-wrap">
    <?php $nb = preg_replace('/&page=\d+/', '', $back); for ($p = 1; $p <= $pages; $p++): ?><a href="<?= $nb . ($p > 1 ? '&page=' . $p : '') ?>" class="px-3 py-1.5 rounded-lg text-xs <?= $p === $page ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200' ?>"><?= fa_digits($p) ?></a><?php endfor; ?>
  </div><?php endif; ?>
<?php endif; ?>
</div>
<?php require_once '../includes/footer.php'; ?>
