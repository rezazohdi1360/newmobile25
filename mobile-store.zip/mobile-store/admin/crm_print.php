<?php
/**
 * چاپ CRM
 *  crm_print.php?id=N                    → پرونده‌ی کامل یک مشتری (اطلاعات، تاریخچه‌ی ارتباط، سفارش‌ها)
 *  crm_print.php?q=&stage=&due=          → لیست مشتریان طبق همان فیلتر صفحه‌ی CRM
 * صفحه بعد از باز شدن، پنجره‌ی چاپ مرورگر را خودکار نشان می‌دهد (برای PDF هم می‌شود «ذخیره به‌صورت PDF» زد).
 */
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/crm.php';

if (!isAdmin()) redirect('../login.php');
crm_ensure($pdo);

$stages = crm_stages(); $types = crm_activity_types(); $srcs = crm_sources();
$stageLbl = function ($k) use ($stages) { return isset($stages[$k]) ? preg_replace('/^\X\s/u', '', $stages[$k][0]) : $k; };
$typeLbl  = function ($k) use ($types) { return isset($types[$k]) ? preg_replace('/^\X\s/u', '', $types[$k]) : $k; };
$when  = function ($dt) { return $dt ? fa_digits(jalali_str($dt, false) . ' — ' . date('H:i', strtotime($dt))) : '—'; };
$day   = function ($d) { return $d ? fa_digits(jalali_str($d, false)) : '—'; };
$money = function ($n) { return fa_digits(number_format((float)$n)); };
$statusLbl = ['pending' => 'در انتظار', 'processing' => 'در حال پردازش', 'shipped' => 'ارسال‌شده', 'delivered' => 'تحویل‌شده', 'cancelled' => 'لغو‌شده'];
$siteName = defined('SITE_NAME') ? SITE_NAME : 'فروشگاه';
$printedAt = fa_digits(jalali_str(date('Y-m-d'), false) . ' — ' . date('H:i'));

$contact = null; $rows = [];
if (isset($_GET['id'])) {
    $st = $pdo->prepare("SELECT * FROM crm_contacts WHERE id=?");
    $st->execute([(int)$_GET['id']]);
    $contact = $st->fetch();
    if (!$contact) { http_response_code(404); exit('مشتری پیدا نشد.'); }
} else {
    $q     = trim((string)($_GET['q'] ?? ''));
    $stage = isset($stages[$_GET['stage'] ?? '']) ? $_GET['stage'] : '';
    $due   = !empty($_GET['due']);
    [$W, $params, $order] = crm_list_filter($q, $stage, $due);
    $st = $pdo->prepare("SELECT * FROM crm_contacts WHERE $W ORDER BY $order LIMIT 2000");
    $st->execute($params);
    $rows = $st->fetchAll();
}
$e = function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); };
?><!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $contact ? 'پرونده‌ی مشتری — ' . $e($contact['name']) : 'لیست مشتریان CRM' ?></title>
<style>
  @page { size: A4; margin: 12mm; }
  * { box-sizing: border-box; }
  body { font-family: Vazirmatn, Tahoma, "Segoe UI", sans-serif; color: #111; font-size: 12px; line-height: 1.8; margin: 0; padding: 16px; background: #fff; }
  .bar { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #111; padding-bottom: 8px; margin-bottom: 14px; }
  .bar h1 { font-size: 17px; margin: 0; }
  .bar small { color: #555; }
  .actions { margin-bottom: 12px; }
  .actions button, .actions a { font: inherit; font-size: 12px; padding: 6px 14px; border: 1px solid #333; background: #111; color: #fff; border-radius: 6px; cursor: pointer; text-decoration: none; margin-left: 6px; }
  .actions a { background: #fff; color: #111; }
  h2 { font-size: 13px; margin: 18px 0 6px; border-right: 4px solid #111; padding-right: 8px; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
  th, td { border: 1px solid #999; padding: 4px 7px; text-align: right; vertical-align: top; }
  th { background: #eee; font-weight: 700; }
  tr { page-break-inside: avoid; }
  thead { display: table-header-group; }
  .info td:nth-child(odd) { background: #f4f4f4; font-weight: 700; width: 14%; white-space: nowrap; }
  .ltr { direction: ltr; unicode-bidi: embed; text-align: right; }
  .note { white-space: pre-wrap; word-break: break-word; }
  .muted { color: #666; }
  .stats { display: flex; gap: 8px; margin: 10px 0; }
  .stats div { flex: 1; border: 1px solid #999; padding: 6px 10px; border-radius: 6px; }
  .stats b { display: block; font-size: 14px; }
  @media print { .actions { display: none; } body { padding: 0; } }
</style>
</head>
<body>
<div class="actions"><button onclick="window.print()">🖨 چاپ</button><a href="javascript:window.close()">بستن</a></div>
<div class="bar">
  <h1><?= $e($siteName) ?> — <?= $contact ? 'پرونده‌ی مشتری' : 'لیست مشتریان (CRM)' ?></h1>
  <small>تاریخ چاپ: <?= $printedAt ?></small>
</div>

<?php if ($contact):
    $orders = crm_contact_orders($pdo, $contact);
    [$oCount, $oSum, $oLast] = crm_order_stats($orders);
    $st = $pdo->prepare("SELECT * FROM crm_activities WHERE contact_id=? ORDER BY created_at DESC, id DESC");
    $st->execute([$contact['id']]);
    $acts = $st->fetchAll();
?>
  <h2>اطلاعات مشتری</h2>
  <table class="info">
    <tr><td>نام</td><td><?= $e($contact['name']) ?></td><td>مرحله</td><td><?= $e($stageLbl($contact['stage'])) ?></td></tr>
    <tr><td>موبایل</td><td class="ltr"><?= $e($contact['phone'] ?: '—') ?></td><td>ایمیل</td><td class="ltr"><?= $e($contact['email'] ?: '—') ?></td></tr>
    <tr><td>شهر</td><td><?= $e($contact['city'] ?: '—') ?></td><td>برچسب‌ها</td><td><?= $e($contact['tags'] ?: '—') ?></td></tr>
    <tr><td>پیگیری بعدی</td><td><?= $day($contact['next_followup']) ?></td><td>آخرین ارتباط</td><td><?= $when($contact['last_contact_at']) ?></td></tr>
    <tr><td>منبع</td><td><?= $e($srcs[$contact['source']] ?? $contact['source']) ?></td><td>تاریخ ثبت</td><td><?= $when($contact['created_at']) ?></td></tr>
    <?php if ($contact['notes']): ?><tr><td>یادداشت</td><td colspan="3" class="note"><?= $e($contact['notes']) ?></td></tr><?php endif; ?>
  </table>

  <div class="stats">
    <div>تعداد سفارش<b><?= fa_digits($oCount) ?></b></div>
    <div>جمع خرید (تومان)<b><?= $money($oSum) ?></b></div>
    <div>آخرین سفارش<b><?= $oLast ? $day($oLast) : '—' ?></b></div>
  </div>

  <h2>تاریخچه‌ی ارتباط (<?= fa_digits(count($acts)) ?>)</h2>
  <?php if (!$acts): ?><p class="muted">گزارشی ثبت نشده است.</p><?php else: ?>
  <table><thead><tr><th style="width:22%">تاریخ</th><th style="width:16%">نوع</th><th>گزارش</th></tr></thead><tbody>
    <?php foreach ($acts as $a): ?>
      <tr><td><?= $when($a['created_at']) ?></td><td><?= $e($typeLbl($a['type'])) ?></td><td class="note"><?= $e($a['note']) ?></td></tr>
    <?php endforeach; ?>
  </tbody></table>
  <?php endif; ?>

  <h2>سفارش‌ها (<?= fa_digits(count($orders)) ?>)</h2>
  <?php if (!$orders): ?><p class="muted">سفارشی پیدا نشد.</p><?php else: ?>
  <table><thead><tr><th>شماره</th><th>تاریخ</th><th>وضعیت</th><th>مبلغ (تومان)</th></tr></thead><tbody>
    <?php foreach ($orders as $o): ?>
      <tr><td>#<?= fa_digits($o['id']) ?></td><td><?= $day($o['created_at']) ?></td><td><?= $e($statusLbl[$o['status']] ?? $o['status']) ?></td><td><?= $money($o['total']) ?></td></tr>
    <?php endforeach; ?>
  </tbody></table>
  <?php endif; ?>

<?php else: ?>
  <p class="muted">
    <?php
      $f = [];
      if ($q !== '') $f[] = 'جستجو: «' . $e($q) . '»';
      if ($stage !== '') $f[] = 'مرحله: ' . $e($stageLbl($stage));
      if ($due) $f[] = 'فقط پیگیری‌های امروز و عقب‌افتاده';
      echo $f ? implode(' — ', $f) . ' — ' : '';
    ?>تعداد: <?= fa_digits(count($rows)) ?> مشتری
  </p>
  <table>
    <thead><tr><th style="width:4%">#</th><th>نام</th><th>موبایل</th><th>ایمیل</th><th>شهر</th><th>مرحله</th><th>سفارش</th><th>جمع خرید (تومان)</th><th>پیگیری بعدی</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $i => $r):
        [$n, $sum] = crm_order_stats(crm_contact_orders($pdo, $r)); ?>
      <tr>
        <td><?= fa_digits($i + 1) ?></td>
        <td><?= $e($r['name']) ?><?php if ($r['tags']): ?><div class="muted"><?= $e($r['tags']) ?></div><?php endif; ?></td>
        <td class="ltr"><?= $e($r['phone'] ?: '—') ?></td>
        <td class="ltr"><?= $e($r['email'] ?: '—') ?></td>
        <td><?= $e($r['city'] ?: '—') ?></td>
        <td><?= $e($stageLbl($r['stage'])) ?></td>
        <td><?= fa_digits($n) ?></td>
        <td><?= $sum ? $money($sum) : '—' ?></td>
        <td><?= $day($r['next_followup']) ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="9" class="muted" style="text-align:center">موردی برای چاپ نیست.</td></tr><?php endif; ?>
    </tbody>
  </table>
<?php endif; ?>
<script>window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 400); });</script>
</body>
</html>
