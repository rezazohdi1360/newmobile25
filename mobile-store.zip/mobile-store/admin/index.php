<?php
/**
 * داشبورد مدیریت (طراحی کلاسیک - استایل وردپرس راست‌چین)
 */
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/reviews.php';
require_once '../includes/mail.php';
require_once '../includes/crm.php';
$pendingReviews = reviews_pending_count($pdo);
$unreadMail = mail_unread_count($pdo);

if (!isAdmin()) redirect('../login.php');
$crmDue = crm_due_count($pdo);

if (!function_exists('ms_fa_digits')) {
    function ms_fa_digits($value) {
        return strtr((string)$value, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']);
    }
}
if (!function_exists('ms_money')) {
    function ms_money($n) { return ms_fa_digits(number_format((float)$n)); }
}

// 🌟 تابع تبدیل تاریخ میلادی به شمسی 🌟
if (!function_exists('gregorian_to_jalali')) {
    function gregorian_to_jalali($gy, $gm, $gd) {
        $g_d_m = array(0,31,59,90,120,151,181,212,243,273,304,334);
        $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
        $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100)) + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
        $jy = -1595 + (33 * ((int)($days / 12053)));
        $days %= 12053;
        $jy += 4 * ((int)($days / 1461));
        $days %= 1461;
        if ($days > 365) {
            $jy += (int)(($days - 1) / 365);
            $days = ($days - 1) % 365;
        }
        if ($days < 186) {
            $jm = 1 + (int)($days / 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + (int)(($days - 186) / 30);
            $jd = 1 + (($days - 186) % 30);
        }
        return array($jy, $jm, $jd);
    }
}
if (!function_exists('ms_jalali_date')) {
    function ms_jalali_date($format = 'Y/m/d', $timestamp = null) {
        if ($timestamp === null) $timestamp = time();
        $date = getdate($timestamp);
        list($jy, $jm, $jd) = gregorian_to_jalali($date['year'], $date['mon'], $date['mday']);
        
        $result = str_replace(
            ['Y', 'm', 'd', 'H', 'i', 's'],
            [sprintf('%04d', $jy), sprintf('%02d', $jm), sprintf('%02d', $jd), sprintf('%02d', $date['hours']), sprintf('%02d', $date['minutes']), sprintf('%02d', $date['seconds'])],
            $format
        );
        return ms_fa_digits($result);
    }
}

$stats = [
    'products' => $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn(),
    'orders'   => $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn(),
    'users'    => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
    'revenue'  => $pdo->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE status='delivered'")->fetchColumn(),
];

// موجودی کالاها (همان شرط نمایش در سایت)
$inStockCount = $pdo->query("
    SELECT COUNT(*) FROM products
    WHERE status = 1 AND stock_status = 'in_stock' AND stock > 0 AND price > 0
")->fetchColumn();
$outStockCount = max(0, (int)$stats['products'] - (int)$inStockCount);

try {
    $mailTotal = (int)$pdo->query("SELECT COUNT(*) FROM mail_messages WHERE direction='in' AND is_trashed=0")->fetchColumn();
    $recentMail = $pdo->query("SELECT id, from_name, from_email, subject, is_read, created_at FROM mail_messages WHERE direction='in' AND is_trashed=0 ORDER BY created_at DESC, id DESC LIMIT 5")->fetchAll();
} catch (Throwable $e) { $mailTotal = 0; $recentMail = []; }

try {
    $crmTotal = (int)$pdo->query("SELECT COUNT(*) FROM crm_contacts")->fetchColumn();
    $st = $pdo->prepare("SELECT id, name, phone, stage, next_followup FROM crm_contacts WHERE next_followup IS NOT NULL AND next_followup <= ? AND stage <> 'inactive' ORDER BY next_followup ASC LIMIT 5");
    $st->execute([date('Y-m-d')]);
    $crmFollowups = $st->fetchAll();
} catch (Throwable $e) { $crmTotal = 0; $crmFollowups = []; }

$recentOrders   = $pdo->query("SELECT o.*, u.name AS user_name FROM orders o LEFT JOIN users u ON o.user_id=u.id ORDER BY o.id DESC LIMIT 5")->fetchAll();
$recentProducts = $pdo->query("SELECT * FROM products ORDER BY id DESC LIMIT 5")->fetchAll();

$adminName = $_SESSION['name'] ?? 'مدیر';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>داشبورد مدیریت | <?= htmlspecialchars(SITE_NAME) ?></title>
<link rel="preconnect" href="https://cdn.jsdelivr.net">
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
<style>
:root{
    --navy:#1b2a41;--navy-deep:#111c2d;--navy-soft:#2a3d5c;
    --gold:#b8923a;--gold-light:#d9b968;--gold-pale:#f4ead2;
    --burgundy:#7a1f2b;--green:#2f6b4f;--cream:#f0f0f1;--paper:#fff;
    --ink:#22262e;--muted:#6b7280;--line:#c3c4c7;
    --shadow:0 1px 1px rgba(0,0,0,.04);
    --shadow-hover:0 3px 8px rgba(0,0,0,.1);
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Vazirmatn',tahoma,sans-serif;background:var(--cream);color:var(--ink);line-height:1.7;-webkit-font-smoothing:antialiased; overflow-x: hidden;}
a{text-decoration:none;color:inherit;transition:color .2s,background .2s,border-color .2s,transform .2s,box-shadow .2s}
img{max-width:100%;display:block}

/* چیدمان شبیه وردپرس (سایدبار سمت راست + محتوا چپ) */
.wp-layout { display: flex; flex-direction: row; min-height: 100vh; }
.wp-sidebar { width: 260px; background: #1d2327; color: #c3c4c7; flex-shrink: 0; position: sticky; top: 0; height: 100vh; overflow-y: auto; display: flex; flex-direction: column; z-index: 1000; }
.wp-content { flex-grow: 1; display: flex; flex-direction: column; width: calc(100% - 260px); min-width: 0; }

/* استایل سایدبار */
.sidebar-logo { padding: 24px 20px; border-bottom: 1px solid #2c3338; text-align: center; }
.sidebar-logo .logo-mark { display: inline-flex; width: 46px; height: 46px; border-radius: 50%; background: #2271b1; color: #fff; align-items: center; justify-content: center; font-size: 20px; margin-bottom: 10px; border: 2px solid #fff; box-shadow: 0 0 0 2px #2271b1; }
.sidebar-logo strong { display: block; color: #fff; font-size: 18px; font-weight: 800; }
.sidebar-logo small { display: block; color: #a7aaad; font-size: 11px; letter-spacing: 1px; }
.sidebar-menu { display: flex; flex-direction: column; padding: 10px 0; }
.sidebar-menu a { padding: 12px 20px; color: #c3c4c7; font-size: 14px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #2c3338; transition: all 0.2s; border-right: 3px solid transparent; }
.sidebar-menu a:hover { background: #2c3338; color: #72aee6; }
.sidebar-menu a.active { background: #2271b1; color: #fff; border-bottom-color: #2271b1; border-right-color: #72aee6; }
.sidebar-menu .badge { background: #d63638; color: #fff; border-radius: 10px; padding: 0 6px; font-size: 11px; font-weight: bold; }

/* هدر بالای محتوا */
.top-bar{background:#fff;color:#50575e;font-size:13px;padding:10px 0;border-bottom:1px solid #c3c4c7;}
.top-bar .container{display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;max-width:100%;padding:0 24px; align-items: center;}
.top-bar b{color:#2271b1;font-weight:600}
.date-time-box { display: flex; gap: 12px; align-items: center; font-weight: 600; background: #f6f7f7; padding: 4px 12px; border-radius: 4px; border: 1px solid #e2e4e7;}

.site-header{background:#fff;border-bottom:1px solid #c3c4c7;position:sticky;top:0;z-index:100;box-shadow:0 1px 3px rgba(0,0,0,.04)}
.header-inner{display:flex;align-items:center;justify-content:space-between;padding:10px 0;gap:24px;max-width:100%;padding:10px 24px;}
.header-actions{display:flex;gap:8px;flex-wrap:wrap;margin-right:auto;}
.header-actions a{color:#2271b1;font-size:13px;font-weight:600;display:flex;align-items:center;gap:6px;padding:6px 12px;border-radius:3px;border:1px solid transparent}
.header-actions a:hover{background:#f0f0f1;border-color:#8c8f94;}
.header-actions .logout{background:#f6f7f7;color:#d63638;border-color:#d63638}
.header-actions .logout:hover{background:#d63638;color:#fff;border-color:#d63638}

.container{max-width:1400px;margin:0 auto;padding:0 24px}

/* خوشامد */
.welcome{margin:24px 0;background:#fff;border:1px solid #c3c4c7;border-radius:4px;padding:24px 30px;box-shadow:var(--shadow);display:flex;align-items:center;justify-content:space-between;gap:20px;flex-wrap:wrap;border-right:4px solid #2271b1;}
.welcome h1{font-size:22px;font-weight:800;color:#1d2327;}
.welcome h1 em{font-style:normal;color:#2271b1;}
.welcome p{font-size:13.5px;color:#50575e;margin-top:4px;}
.welcome .date{font-size:13px;color:#50575e;background:#f0f0f1;padding:4px 12px;border-radius:3px;}

/* 🌟 آمار (۵ ستون) 🌟 */
.stats-grid{
    display:grid;
    grid-template-columns: repeat(5, 1fr); /* 5 ستون مساوی */
    gap:12px;
    margin-bottom:24px;
    width: 100%;
}
.stat-card{
    background:#fff;
    border:1px solid #c3c4c7;
    border-radius:4px;
    padding:12px 10px;
    box-shadow:var(--shadow);
    position:relative;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
    transition:all .2s;
}
a.stat-card:hover{transform:translateY(-2px);box-shadow:0 4px 10px rgba(0,0,0,.1);border-color:#2271b1;}
.stat-icon{width:28px;height:28px;border-radius:4px;display:grid;place-items:center;font-size:14px;background:#f0f6fc;color:#2271b1;margin-bottom:6px}
.stat-num{font-size:20px;font-weight:800;color:#1d2327;line-height:1.2}
.stat-num.small{font-size:16px}
.stat-label{font-size:12px;color:#50575e;margin-top:2px}
.stat-sub{font-size:11px;margin-top:6px;padding-top:6px;border-top:1px solid #f0f0f1;color:#50575e;display:flex;flex-wrap:wrap;gap:6px}
.stat-sub .ok{color:var(--green);font-weight:700}
.stat-sub .no{color:var(--burgundy);font-weight:700}

/* پنل‌ها */
.panel{background:#fff;border:1px solid #c3c4c7;border-radius:4px;padding:20px;box-shadow:var(--shadow);margin-bottom:24px;}
.panel-title{font-size:16px;font-weight:700;color:#1d2327;margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid #f0f0f1;}

/* شبکه دسترسی سریع */
.quick-actions { 
    display: grid; 
    grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); 
    gap: 12px; 
}
.qbtn {
    display: flex; 
    align-items: center; 
    gap: 8px;
    padding: 12px 16px; 
    background: #fff; 
    border: 1px solid #c3c4c7; 
    border-radius: 4px; 
    color: #2c3338; 
    font-size: 13px; 
    font-weight: 600; 
    box-shadow: 0 1px 1px rgba(0,0,0,.04); 
    transition: all 0.2s; 
}
.qbtn:hover { background: #f6f7f7; border-color: #8c8f94; color: #135e96; }
.qbtn.primary { background: #2271b1; color: #fff; border-color: #2271b1; }
.qbtn.primary:hover { background: #135e96; border-color: #135e96; color: #fff; }

.two-col{display:grid;grid-template-columns:1fr 1fr;gap:24px;}
.list-row{display:flex;justify-content:space-between;align-items:center;padding:12px 4px;border-bottom:1px solid #f0f0f1;gap:12px;transition:background .2s;}
a.list-row:hover { background: #f6f7f7; }
.list-row:last-of-type{border-bottom:none}
.order-id{font-size:13px;font-weight:700;color:#1d2327}
.order-user{font-size:12.5px;color:#50575e;margin-right:8px}
.order-total{font-size:13px;font-weight:700;color:#1d2327;white-space:nowrap}
.order-total small{font-size:11px;color:#50575e;font-weight:500}
.p-row{display:flex;align-items:center;gap:14px;padding:12px 4px;border-bottom:1px solid #f0f0f1}
.p-row:last-of-type{border-bottom:none}
.p-row img{width:46px;height:46px;object-fit:contain;background:#f6f7f7;border:1px solid #c3c4c7;border-radius:4px;padding:4px;flex-shrink:0}
.p-info{flex:1;min-width:0}
.p-name{font-size:13px;font-weight:600;color:#1d2327;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.p-price{font-size:12.5px;font-weight:700;color:#2271b1;margin-top:1px}
.p-price small{color:#50575e;font-weight:500;font-size:11px}
.view-all{display:block;text-align:center;margin-top:16px;padding:10px;border:1px solid #2271b1;border-radius:3px;color:#2271b1;font-weight:600;font-size:13px;}
.view-all:hover{background:#f0f6fc;color:#135e96;}
.empty{text-align:center;color:#50575e;font-size:13px;padding:36px 0}

/* فوتر */
.site-footer{background:#fff;color:#50575e;margin-top:auto;border-top:1px solid #c3c4c7;text-align:center;padding:20px 0;font-size:13px}

/* واکنش‌گرا */
@media(max-width:992px){
    .stats-grid { grid-template-columns: repeat(3, 1fr); }
}
@media(max-width:900px){
    .two-col{grid-template-columns:1fr}
    .wp-layout { flex-direction: column; }
    .wp-sidebar { width: 100%; height: auto; position: relative; }
    .wp-content { width: 100%; }
}
@media(max-width:768px){
    .container{padding:0 16px}
    .stats-grid{grid-template-columns:repeat(2,1fr);gap:12px}
    .quick-actions{grid-template-columns: 1fr;}
}
@media(max-width:480px){
    .stats-grid{grid-template-columns:1fr}
}
</style>
</head>
<body>

<div class="wp-layout">
    <aside class="wp-sidebar">
        <div class="sidebar-logo">
            <a href="index.php">
                <span class="logo-mark">📱</span>
                <strong><?= htmlspecialchars(SITE_NAME) ?></strong>
                <small>ADMIN PANEL</small>
            </a>
        </div>
        <nav class="sidebar-menu">
            <a href="index.php" class="active">📊 داشبورد</a>
            <a href="products.php">📦 محصولات</a>
            <a href="sample_products.php">🧪 محصولات نمونه</a>
            <a href="featured.php">⭐ محصولات منتخب</a>
            <a href="banner_settings.php">🖼 مدیریت بنرها</a>
            <a href="price_update.php">💰 به‌روزرسانی قیمت</a>
            <a href="messages.php">📧 پیام‌ها<?php if (!empty($unreadMail)): ?> <span class="badge"><?= (int)$unreadMail ?></span><?php endif; ?></a>
            <a href="crm.php">🤝 CRM مشتریان<?php if (!empty($crmDue)): ?> <span class="badge"><?= (int)$crmDue ?></span><?php endif; ?></a>
            <a href="reviews.php">💬 نظرات<?php if (!empty($pendingReviews)): ?> <span class="badge"><?= (int)$pendingReviews ?></span><?php endif; ?></a>
            <a href="coupons.php">🎟 کد تخفیف</a>
            <a href="orders.php">🛒 سفارشات</a>
            <a href="categories.php">📁 دسته‌بندی‌ها</a>
            <a href="users.php">👥 کاربران</a>
            <a href="shipping.php">🚚 تنظیمات ارسال</a>
            <a href="settings.php">⚙ اطلاعات تماس</a>
            <a href="telegram.php">✈️ تلگرام</a>
        </nav>
    </aside>

    <div class="wp-content">
        <div class="top-bar">
            <div class="container">
                <!-- سمت راست -->
                <span>🔐 پنل مدیریت &nbsp;|&nbsp; <b><?= htmlspecialchars(SITE_NAME) ?></b></span>
                
                <!-- 🌟 سمت چپ: ساعت اول، تاریخ دوم 🌟 -->
                <div class="date-time-box">
                    <span id="live-clock">⏰ <?= ms_jalali_date('H:i:s') ?></span>
                    <span style="color:#c3c4c7">|</span>
                    <span>📅 <?= ms_jalali_date('Y/m/d') ?></span>
                </div>
            </div>
        </div>

        <header class="site-header">
            <div class="header-inner">
                <div class="header-actions">
                    <a href="../index.php" target="_blank">🌐 مشاهده سایت</a>
                    <a href="../logout.php" class="logout">🚪 خروج</a>
                </div>
            </div>
        </header>

        <div class="container">
            <section class="welcome">
                <div>
                    <h1>خوش آمدید، <em><?= sanitize($adminName) ?></em></h1>
                    <p>نمای کلی فروشگاه و دسترسی سریع به بخش‌های مدیریت</p>
                </div>
                <div class="date">📅 <?= ms_jalali_date('Y/m/d') ?></div>
            </section>

            <!-- آمار (۵ ستون) -->
            <section class="stats-grid">
                <a href="products.php" class="stat-card">
                    <div class="stat-icon">📦</div>
                    <div class="stat-num"><?= ms_money($stats['products']) ?></div>
                    <div class="stat-label">محصول</div>
                    <div class="stat-sub">
                        <span class="ok">موجود: <?= ms_money($inStockCount) ?></span>
                        <span class="no">ناموجود: <?= ms_money($outStockCount) ?></span>
                    </div>
                </a>
                <a href="orders.php" class="stat-card">
                    <div class="stat-icon">🛒</div>
                    <div class="stat-num"><?= ms_money($stats['orders']) ?></div>
                    <div class="stat-label">سفارش</div>
                </a>
                <a href="users.php" class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-num"><?= ms_money($stats['users']) ?></div>
                    <div class="stat-label">کاربر</div>
                </a>
                <a href="messages.php" class="stat-card">
                    <div class="stat-icon">📧</div>
                    <div class="stat-num"><?= ms_money($mailTotal) ?></div>
                    <div class="stat-label">پیام دریافتی</div>
                    <div class="stat-sub">
                        <span class="<?= $unreadMail ? 'no' : 'ok' ?>">خوانده‌نشده: <?= ms_money($unreadMail) ?></span>
                    </div>
                </a>
                <div class="stat-card">
                    <div class="stat-icon">💰</div>
                    <div class="stat-num small"><?= ms_money($stats['revenue']) ?></div>
                    <div class="stat-label">درآمد (تومان)</div>
                </div>
            </section>

            <!-- دسترسی سریع -->
            <section class="panel">
                <h2 class="panel-title">دسترسی سریع</h2>
                <div class="quick-actions">
                    <a href="product_add.php" class="qbtn primary">➕ افزودن محصول</a>
                    <a href="crm.php" class="qbtn">🤝 CRM مشتریان<?= $crmDue ? ' (' . ms_fa_digits($crmDue) . ' پیگیری)' : '' ?></a>
                    <a href="banner_settings.php" class="qbtn">🖼 مدیریت بنرها</a>
                    <a href="mail_settings.php" class="qbtn">⚙ تنظیمات ایمیل</a>
                    <a href="catalog.php?all=1" class="qbtn" onclick="return confirm('کاتالوگ PDF همه‌ی محصولات ساخته شود؟ برای محصولات زیاد ممکن است چند دقیقه طول بکشد. (برای انتخاب محصولات خاص از «مدیریت محصولات» استفاده کنید)')">📄 کاتالوگ PDF محصولات</a>
                </div>
            </section>

            <div class="two-col">
                <section class="panel">
                    <h3 class="panel-title">🛒 آخرین سفارشات</h3>
                    <?php if (empty($recentOrders)): ?>
                        <p class="empty">هنوز سفارشی ثبت نشده است</p>
                    <?php else: ?>
                        <?php foreach ($recentOrders as $o): ?>
                        <div class="list-row">
                            <div>
                                <span class="order-id">#<?= ms_fa_digits($o['id']) ?></span>
                                <span class="order-user"><?= sanitize($o['user_name'] ?? $o['customer_name'] ?? 'مهمان') ?></span>
                            </div>
                            <span class="order-total"><?= ms_money($o['total']) ?> <small>تومان</small></span>
                        </div>
                        <?php endforeach; ?>
                        <a href="orders.php" class="view-all">مشاهده همه سفارشات</a>
                    <?php endif; ?>
                </section>

                <section class="panel">
                    <h3 class="panel-title">📦 آخرین محصولات</h3>
                    <?php if (empty($recentProducts)): ?>
                        <p class="empty">هنوز محصولی اضافه نشده است</p>
                    <?php else: ?>
                        <?php foreach ($recentProducts as $p):
                            $imgSrc = $p['main_image'] ?? '';
                            if (empty($imgSrc)) {
                                $imgSrc = 'https://placehold.co/100x100/f1f5f9/1e293b?text=No+Img';
                            } elseif (strpos($imgSrc, 'http') !== 0) {
                                $imgSrc = '../' . $imgSrc;
                            }
                        ?>
                        <div class="p-row">
                            <img src="<?= sanitize($imgSrc) ?>" alt=""
                                 onerror="this.onerror=null;this.src='https://placehold.co/100x100/f1f5f9/1e293b?text=P'">
                            <div class="p-info">
                                <div class="p-name"><?= sanitize($p['name']) ?></div>
                                <div class="p-price"><?= ms_money($p['sale_price'] ?: $p['price']) ?> <small>تومان</small></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <a href="products.php" class="view-all">مشاهده همه محصولات</a>
                    <?php endif; ?>
                </section>
            </div>

            <section class="panel">
                <h3 class="panel-title">🤝 CRM — پیگیری‌های امروز و عقب‌افتاده <small style="font-weight:500;color:#50575e">(<?= ms_fa_digits($crmTotal) ?> مشتری ثبت‌شده)</small></h3>
                <?php if (empty($crmFollowups)): ?>
                    <p class="empty"><?= $crmTotal ? 'پیگیری معوقی وجود ندارد 🎉' : 'هنوز مشتری‌ای در CRM ثبت نشده است' ?></p>
                    <a href="crm.php" class="view-all">ورود به CRM</a>
                <?php else: ?>
                    <?php foreach ($crmFollowups as $f): ?>
                    <a href="crm.php?id=<?= (int)$f['id'] ?>" class="list-row">
                        <div style="min-width:0;flex:1">
                            <span class="order-id"><?= sanitize($f['name']) ?></span>
                            <span class="order-user" dir="ltr"><?= sanitize($f['phone'] ?: '') ?></span>
                        </div>
                        <span class="order-total"><small>⏰ <?= ms_jalali_date('Y/m/d', strtotime($f['next_followup'])) ?></small></span>
                    </a>
                    <?php endforeach; ?>
                    <a href="crm.php?due=1" class="view-all">مشاهده همه پیگیری‌ها</a>
                <?php endif; ?>
            </section>

            <section class="panel">
                <h3 class="panel-title">📧 آخرین پیام‌های دریافتی</h3>
                <?php if (empty($recentMail)): ?>
                    <p class="empty">هنوز پیامی دریافت نشده است</p>
                <?php else: ?>
                    <?php foreach ($recentMail as $m): ?>
                    <a href="messages.php?id=<?= (int)$m['id'] ?>" class="list-row" style="<?= $m['is_read'] ? '' : 'font-weight:800' ?>">
                        <div style="min-width:0;flex:1">
                            <span class="order-id"><?= $m['is_read'] ? '' : '● ' ?><?= sanitize($m['from_name'] ?: $m['from_email'] ?: 'ناشناس') ?></span>
                            <span class="order-user"><?= sanitize(mb_substr((string)$m['subject'], 0, 70)) ?></span>
                        </div>
                        <span class="order-total"><small><?= ms_jalali_date('Y/m/d H:i', strtotime($m['created_at'])) ?></small></span>
                    </a>
                    <?php endforeach; ?>
                    <a href="messages.php" class="view-all">مشاهده همه پیام‌ها</a>
                <?php endif; ?>
            </section>
        </div>

        <footer class="site-footer">
            © <?= ms_jalali_date('Y') ?> <?= htmlspecialchars(SITE_NAME) ?> — پنل مدیریت
        </footer>
    </div>
</div>

<!-- اسکریپت ساعت زنده و ثانیه‌شمار -->
<script>
function updateClock() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const timeString = `${hours}:${minutes}:${seconds}`;
    
    // تبدیل اعداد انگلیسی به فارسی
    const faTime = timeString.replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
    
    const clockEl = document.getElementById('live-clock');
    if (clockEl) {
        clockEl.innerText = '⏰ ' + faTime;
    }
}
setInterval(updateClock, 1000);
updateClock(); // اجرای اولیه
</script>

</body>
</html>