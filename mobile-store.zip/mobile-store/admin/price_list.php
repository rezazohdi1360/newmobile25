<?php
/**
 * مدیریت لیست قیمت (صفحه‌ی عمومی: ../price-list.php)
 * تنظیمات صفحه + اطلاعات هر کالا: کد، واحد، قیمت پلکانی (تا دو پله)، مخفی از لیست، «استعلام بگیرید»
 * قیمت و موجودی خود کالا همچنان از «مدیریت محصولات» می‌آید.
 */
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/mail.php';   // mail_csrf* (CSRF مشترک پنل)
require_once '../includes/pricelist.php';
require_once '../includes/coupons.php';

if (!isAdmin()) redirect('../login.php');
pricelist_ensure($pdo);

$num = function ($v) {
    $v = preg_replace('/[^\d]/', '', en_digits((string)$v));
    return $v === '' ? null : (int)$v;
};

$q    = trim((string)($_GET['q'] ?? ''));
$cat  = (int)($_GET['cat'] ?? 0);
$page = max(1, (int)($_GET['page'] ?? 1));
$back = 'price_list.php?' . http_build_query(array_filter(['q' => $q, 'cat' => $cat ?: '', 'page' => $page > 1 ? $page : ''], 'strlen'));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!mail_csrf_ok()) { setFlash('error', 'نشست شما منقضی شده است؛ دوباره تلاش کنید.'); redirect($back); }
    $act = $_POST['act'] ?? '';

    if ($act === 'settings') {
        site_set($pdo, 'pricelist_enabled', !empty($_POST['enabled']) ? '1' : '0');
        site_set($pdo, 'pricelist_title', trim(mb_substr((string)($_POST['title'] ?? ''), 0, 120)) ?: 'لیست قیمت عمده');
        site_set($pdo, 'pricelist_phone', trim(mb_substr((string)($_POST['phone'] ?? ''), 0, 30)));
        site_set($pdo, 'pricelist_note', trim(mb_substr((string)($_POST['note'] ?? ''), 0, 1500)));
        setFlash('success', 'تنظیمات لیست قیمت ذخیره شد.');

    } elseif ($act === 'save_items') {
        $rows = $_POST['it'] ?? [];
        $now  = date('Y-m-d H:i:s');
        $up = $pdo->prepare("INSERT INTO price_list_items (product_id, code, unit, tier1_qty, tier1_price, tier2_qty, tier2_price, hidden, inquiry, updated_at)
                             VALUES (?,?,?,?,?,?,?,?,?,?)
                             ON DUPLICATE KEY UPDATE code=VALUES(code), unit=VALUES(unit), tier1_qty=VALUES(tier1_qty), tier1_price=VALUES(tier1_price),
                                tier2_qty=VALUES(tier2_qty), tier2_price=VALUES(tier2_price), hidden=VALUES(hidden), inquiry=VALUES(inquiry), updated_at=VALUES(updated_at)");
        $del = $pdo->prepare("DELETE FROM price_list_items WHERE product_id=?");
        $saved = 0; $bad = 0;
        foreach ($rows as $pid => $r) {
            $pid = (int)$pid;
            if ($pid <= 0 || !is_array($r)) continue;
            $code = trim(mb_substr((string)($r['code'] ?? ''), 0, 40));
            $unit = trim(mb_substr((string)($r['unit'] ?? ''), 0, 60));
            $t1q = $num($r['t1q'] ?? ''); $t1p = $num($r['t1p'] ?? '');
            $t2q = $num($r['t2q'] ?? ''); $t2p = $num($r['t2p'] ?? '');
            // پله ناقص (فقط تعداد یا فقط قیمت) نادیده گرفته می‌شود
            if (!$t1q || !$t1p) { $t1q = $t1p = null; }
            if (!$t2q || !$t2p) { $t2q = $t2p = null; }
            if ($t1q && $t2q && $t2q <= $t1q) { $t2q = $t2p = null; $bad++; }   // پله‌ی دوم باید تعداد بیشتری داشته باشد
            $hidden = !empty($r['hidden']) ? 1 : 0;
            $inq    = !empty($r['inq']) ? 1 : 0;
            if ($code === '' && $unit === '' && !$t1q && !$t2q && !$hidden && !$inq) { $del->execute([$pid]); continue; }
            $up->execute([$pid, $code ?: null, $unit ?: null, $t1q, $t1p, $t2q, $t2p, $hidden, $inq, $now]);
            $saved++;
        }
        setFlash('success', fa_digits($saved) . ' کالا ذخیره شد.' . ($bad ? ' (در ' . fa_digits($bad) . ' کالا پله‌ی دوم باید تعداد بیشتری از پله‌ی اول داشته باشد و نادیده گرفته شد.)' : ''));
    }
    redirect($back);
}

// ───── لیست کالاها ─────
$cats = $pdo->query("SELECT id, name FROM categories ORDER BY name")->fetchAll();
$where = ['p.status = 1']; $params = [];
if ($cat) { $where[] = 'p.category_id = ?'; $params[] = $cat; }
if ($q !== '') { $where[] = '(p.name LIKE ? OR i.code LIKE ?)'; $params[] = "%$q%"; $params[] = "%$q%"; }
$W = implode(' AND ', $where);
$from = "FROM products p LEFT JOIN categories c ON c.id = p.category_id LEFT JOIN price_list_items i ON i.product_id = p.id WHERE $W";
$st = $pdo->prepare("SELECT COUNT(*) $from"); $st->execute($params);
$total = (int)$st->fetchColumn();
$perPage = 40; $pages = max(1, (int)ceil($total / $perPage)); $page = min($page, $pages);
$st = $pdo->prepare("SELECT p.id, p.name, p.price, p.sale_price, p.stock, p.stock_status, c.name AS cat_name,
                            i.code, i.unit, i.tier1_qty, i.tier1_price, i.tier2_qty, i.tier2_price, i.hidden, i.inquiry
                     $from ORDER BY (c.name IS NULL), c.name, p.name LIMIT $perPage OFFSET " . (($page - 1) * $perPage));
$st->execute($params);
$items = $st->fetchAll();
$hiddenN = (int)$pdo->query("SELECT COUNT(*) FROM price_list_items WHERE hidden=1")->fetchColumn();
$S = pricelist_settings($pdo);
$money = function ($n) { return fa_digits(number_format((float)$n)); };
$qs = function ($extra = []) use ($q, $cat) { return '?' . http_build_query(array_filter(array_merge(['q' => $q, 'cat' => $cat ?: ''], $extra), 'strlen')); };

$pageTitle = 'مدیریت لیست قیمت';
require_once '../includes/header.php';
$inp = 'w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs';
?>
<div class="max-w-7xl mx-auto px-4 py-8">
  <div class="flex justify-between items-center mb-5 flex-wrap gap-3">
    <h1 class="text-2xl font-black text-slate-900 flex items-center gap-2"><span class="w-2 h-7 bg-brand-orange rounded-full"></span>💰 مدیریت لیست قیمت</h1>
    <div class="flex gap-2 flex-wrap">
      <a href="../price-list.php" target="_blank" class="bg-brand-orange hover:bg-brand-hover text-white font-bold px-4 py-2.5 rounded-xl text-xs">👁 مشاهده‌ی صفحه‌ی لیست قیمت</a>
      <a href="../price-list.php?download=xlsx" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2.5 rounded-xl text-xs">⬇ دانلود اکسل</a>
      <a href="index.php" class="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-4 py-2.5 rounded-xl text-xs">← داشبورد</a>
    </div>
  </div>

  <details class="bg-white border border-slate-200 rounded-2xl p-5 mb-5" <?= isset($_GET['settings']) ? 'open' : '' ?>>
    <summary class="cursor-pointer font-black text-slate-800 text-sm">⚙️ تنظیمات صفحه‌ی لیست قیمت <span class="text-[11px] font-bold <?= $S['enabled'] ? 'text-emerald-600' : 'text-red-500' ?>">(<?= $S['enabled'] ? 'فعال' : 'غیرفعال' ?>)</span></summary>
    <form method="post" class="mt-4 grid md:grid-cols-2 gap-4">
      <?= mail_csrf_field() ?><input type="hidden" name="act" value="settings">
      <div><label class="block text-xs font-bold text-slate-600 mb-1">عنوان صفحه</label>
        <input type="text" name="title" maxlength="120" value="<?= sanitize($S['title']) ?>" class="<?= $inp ?>"></div>
      <div><label class="block text-xs font-bold text-slate-600 mb-1">شماره واتس‌اپ برای دکمه‌ی «استعلام» (مثلاً 09151002298)</label>
        <input type="text" name="phone" dir="ltr" maxlength="30" value="<?= sanitize($S['phone']) ?>" class="<?= $inp ?>"></div>
      <div class="md:col-span-2"><label class="block text-xs font-bold text-slate-600 mb-1">توضیح پایین صفحه</label>
        <textarea name="note" rows="3" maxlength="1500" class="<?= $inp ?> leading-6"><?= sanitize($S['note']) ?></textarea></div>
      <label class="text-xs text-slate-700 flex items-center gap-2"><input type="checkbox" name="enabled" value="1" <?= $S['enabled'] ? 'checked' : '' ?>> نمایش صفحه‌ی لیست قیمت برای عموم</label>
      <div><button class="bg-slate-900 hover:bg-black text-white font-bold px-6 py-2.5 rounded-xl text-xs">💾 ذخیره‌ی تنظیمات</button></div>
    </form>
  </details>

  <div class="bg-amber-50 border border-amber-200 text-amber-900 rounded-2xl p-3 text-[11px] leading-6 mb-4">
    قیمت و موجودی هر کالا از «مدیریت محصولات» خوانده می‌شود (اگر «قیمت با تخفیف» ثبت شده باشد همان نمایش داده می‌شود). در این‌جا فقط کد، واحد (مثلاً «هر عدد»)، قیمت پلکانی و نمایش/عدم‌نمایش را تنظیم می‌کنید.
    قیمت پلکانی: مثلاً «از ۱۰ عدد، قیمت هر واحد ۱۱۰٬۰۰۰». اگر کدی نزنید، شناسه‌ی کالا به‌عنوان کد نمایش داده می‌شود.
    <?= $hiddenN ? ' · ' . fa_digits($hiddenN) . ' کالا از لیست مخفی است.' : '' ?>
  </div>

  <form method="get" class="flex gap-2 flex-wrap mb-4">
    <input type="search" name="q" value="<?= sanitize($q) ?>" placeholder="جستجوی نام یا کد..." class="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs w-64">
    <select name="cat" class="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs">
      <option value="0">همه‌ی دسته‌ها</option>
      <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>" <?= $cat === (int)$c['id'] ? 'selected' : '' ?>><?= sanitize($c['name']) ?></option><?php endforeach; ?>
    </select>
    <button class="bg-white border border-slate-200 px-4 py-2 rounded-xl text-xs">🔍 فیلتر</button>
    <span class="text-xs text-slate-500 self-center"><?= fa_digits($total) ?> کالا</span>
  </form>

  <?php if (!$items): ?>
    <div class="bg-white border border-slate-200 rounded-2xl p-10 text-center text-slate-400 text-sm">کالایی پیدا نشد.</div>
  <?php else: ?>
  <form method="post">
    <?= mail_csrf_field() ?><input type="hidden" name="act" value="save_items">
    <div class="bg-white border border-slate-200 rounded-2xl overflow-hidden"><div class="overflow-x-auto">
      <table class="w-full text-xs">
        <thead class="bg-slate-50 border-b border-slate-200"><tr class="text-slate-500">
          <th class="px-3 py-3 text-right font-bold">کالا</th>
          <th class="px-2 py-3 text-right font-bold">قیمت</th>
          <th class="px-2 py-3 text-right font-bold w-24">کد</th>
          <th class="px-2 py-3 text-right font-bold w-28">واحد</th>
          <th class="px-2 py-3 text-right font-bold" colspan="2">پله‌ی ۱ (از تعداد / قیمت)</th>
          <th class="px-2 py-3 text-right font-bold" colspan="2">پله‌ی ۲ (از تعداد / قیمت)</th>
          <th class="px-2 py-3 text-center font-bold">مخفی</th>
          <th class="px-2 py-3 text-center font-bold">استعلام</th>
        </tr></thead>
        <tbody class="divide-y divide-slate-100">
        <?php $lastCat = null; foreach ($items as $it):
            $eff = ($it['sale_price'] && (float)$it['sale_price'] > 0 && (float)$it['sale_price'] < (float)$it['price']) ? $it['sale_price'] : $it['price'];
            $id = (int)$it['id']; $inStock = $it['stock_status'] === 'in_stock' && (int)$it['stock'] > 0;
            if ($it['cat_name'] !== $lastCat): $lastCat = $it['cat_name']; ?>
          <tr class="bg-slate-50"><td colspan="10" class="px-3 py-2 font-black text-slate-700"><?= sanitize($lastCat ?: 'سایر کالاها') ?></td></tr>
        <?php endif; ?>
          <tr class="<?= !empty($it['hidden']) ? 'opacity-50' : '' ?>">
            <td class="px-3 py-2 min-w-[200px]"><div class="font-bold text-slate-800"><?= sanitize($it['name']) ?></div>
              <div class="text-[10px] <?= $inStock ? 'text-emerald-600' : 'text-red-500' ?>"><?= $inStock ? 'موجود' : 'ناموجود' ?> · شناسه <?= fa_digits($id) ?></div></td>
            <td class="px-2 py-2 font-bold whitespace-nowrap"><?= $eff > 0 ? $money($eff) : '—' ?></td>
            <td class="px-2 py-2"><input type="text" name="it[<?= $id ?>][code]" value="<?= sanitize($it['code']) ?>" maxlength="40" dir="ltr" class="<?= $inp ?>"></td>
            <td class="px-2 py-2"><input type="text" name="it[<?= $id ?>][unit]" value="<?= sanitize($it['unit']) ?>" maxlength="60" placeholder="هر عدد" class="<?= $inp ?>"></td>
            <td class="px-1 py-2 w-16"><input type="text" name="it[<?= $id ?>][t1q]" value="<?= $it['tier1_qty'] ?: '' ?>" inputmode="numeric" placeholder="۱۰" class="<?= $inp ?>"></td>
            <td class="px-1 py-2 w-28"><input type="text" name="it[<?= $id ?>][t1p]" value="<?= $it['tier1_price'] ? (int)$it['tier1_price'] : '' ?>" inputmode="numeric" dir="ltr" class="<?= $inp ?>"></td>
            <td class="px-1 py-2 w-16"><input type="text" name="it[<?= $id ?>][t2q]" value="<?= $it['tier2_qty'] ?: '' ?>" inputmode="numeric" placeholder="۵۰" class="<?= $inp ?>"></td>
            <td class="px-1 py-2 w-28"><input type="text" name="it[<?= $id ?>][t2p]" value="<?= $it['tier2_price'] ? (int)$it['tier2_price'] : '' ?>" inputmode="numeric" dir="ltr" class="<?= $inp ?>"></td>
            <td class="px-2 py-2 text-center"><input type="checkbox" name="it[<?= $id ?>][hidden]" value="1" <?= !empty($it['hidden']) ? 'checked' : '' ?>></td>
            <td class="px-2 py-2 text-center"><input type="checkbox" name="it[<?= $id ?>][inq]" value="1" <?= !empty($it['inquiry']) ? 'checked' : '' ?>></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div></div>
    <div class="flex items-center justify-between gap-3 mt-4 flex-wrap">
      <button class="bg-brand-orange hover:bg-brand-hover text-white font-bold px-8 py-3 rounded-xl text-sm">💾 ذخیره‌ی تغییرات این صفحه</button>
      <?php if ($pages > 1): ?>
      <div class="flex gap-1 flex-wrap">
        <?php for ($i = 1; $i <= $pages; $i++): ?>
          <a href="<?= $qs(['page' => $i > 1 ? $i : '']) ?>" class="px-3 py-1.5 rounded-lg text-xs <?= $i === $page ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200' ?>"><?= fa_digits($i) ?></a>
        <?php endfor; ?>
      </div>
      <?php endif; ?>
    </div>
  </form>
  <?php endif; ?>
</div>
<?php require_once '../includes/footer.php'; ?>
