<?php
/**
 * CRM — مدیریت ارتباط با مشتری
 * لیست مشتریان/سرنخ‌ها، فیلتر و جستجو، پیگیری‌های امروز، پرونده‌ی مشتری (تاریخچه‌ی ارتباط + سفارش‌ها)
 */
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/mail.php';   // mail_csrf* (CSRF مشترک پنل)
require_once '../includes/crm.php';
require_once '../includes/recaptcha.php';

if (!isAdmin()) redirect('../login.php');
crm_ensure($pdo);

$stages = crm_stages();
$types  = crm_activity_types();
$srcs   = crm_sources();

// ───── عملیات (POST) ─────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!mail_csrf_ok()) { setFlash('error', 'نشست شما منقضی شده است؛ دوباره تلاش کنید.'); redirect('crm.php'); }
    $act  = $_POST['act'] ?? '';
    $id   = (int)($_POST['id'] ?? 0);
    $back = $id ? 'crm.php?id=' . $id : 'crm.php';
    $now  = crm_now();

    if ($act === 'sync') {
        [$added, $promoted] = crm_sync($pdo);
        setFlash('success', "همگام‌سازی انجام شد: " . fa_digits($added) . " مشتری جدید اضافه و " . fa_digits($promoted) . " سرنخ به «مشتری» ارتقا یافت.");
        $back = 'crm.php';

    } elseif ($act === 'recaptcha_settings') {
        site_set($pdo, 'recaptcha_enabled', !empty($_POST['rc_enabled']) ? '1' : '0');
        site_set($pdo, 'recaptcha_site_key', trim((string)($_POST['rc_site'] ?? '')));
        if (trim((string)($_POST['rc_secret'] ?? '')) !== '') site_set($pdo, 'recaptcha_secret_key', trim($_POST['rc_secret']));
        setFlash('success', 'تنظیمات reCAPTCHA ذخیره شد.');
        $back = 'crm.php#recaptcha';

    } elseif ($act === 'save' && !$id && !(([$rcOk, $rcMsg] = recaptcha_verify($pdo))[0])) {
        setFlash('error', $rcMsg);
        $back = 'crm.php?new=1';

    } elseif ($act === 'save') {
        $name  = trim(mb_substr((string)($_POST['name'] ?? ''), 0, 150));
        $phone = crm_norm_phone($_POST['phone'] ?? '');
        $email = crm_norm_email($_POST['email'] ?? '');
        $city  = trim(mb_substr((string)($_POST['city'] ?? ''), 0, 80));
        $stage = isset($stages[$_POST['stage'] ?? '']) ? $_POST['stage'] : 'lead';
        $tags  = crm_clean_tags($_POST['tags'] ?? '');
        $notes = trim(mb_substr((string)($_POST['notes'] ?? ''), 0, 5000));
        $fuRaw = trim((string)($_POST['next_followup'] ?? ''));
        $fu    = $fuRaw === '' ? null : jalali_to_date($fuRaw);

        if ($name === '') {
            setFlash('error', 'نام مشتری الزامی است.');
            $back = $id ? 'crm.php?id=' . $id : 'crm.php?new=1';
        } elseif ($phone === '' && $email === '') {
            setFlash('error', 'حداقل یکی از «موبایل» یا «ایمیل» را وارد کنید.');
            $back = $id ? 'crm.php?id=' . $id : 'crm.php?new=1';
        } elseif ($fuRaw !== '' && $fu === null) {
            setFlash('error', 'تاریخ پیگیری نامعتبر است (نمونه: ۱۴۰۵/۰۸/۲۵).');
            $back = $id ? 'crm.php?id=' . $id : 'crm.php?new=1';
        } else {
            // جلوگیری از تکرار موبایل/ایمیل
            $dup = $pdo->prepare("SELECT id FROM crm_contacts WHERE id <> ? AND ((? <> '' AND phone = ?) OR (? <> '' AND email = ?)) LIMIT 1");
            $dup->execute([$id, $phone, $phone, $email, $email]);
            if ($d = $dup->fetchColumn()) {
                setFlash('error', 'مشتری دیگری با همین موبایل یا ایمیل وجود دارد.');
                $back = 'crm.php?id=' . (int)$d;
            } elseif ($id) {
                $pdo->prepare("UPDATE crm_contacts SET name=?, phone=?, email=?, city=?, stage=?, tags=?, notes=?, next_followup=?, updated_at=? WHERE id=?")
                    ->execute([$name, $phone ?: null, $email ?: null, $city ?: null, $stage, $tags ?: null, $notes ?: null, $fu, $now, $id]);
                setFlash('success', 'اطلاعات مشتری ذخیره شد.');
            } else {
                $pdo->prepare("INSERT INTO crm_contacts (name, phone, email, city, stage, source, tags, notes, next_followup, created_at, updated_at)
                               VALUES (?,?,?,?,?,'manual',?,?,?,?,?)")
                    ->execute([$name, $phone ?: null, $email ?: null, $city ?: null, $stage, $tags ?: null, $notes ?: null, $fu, $now, $now]);
                $id = (int)$pdo->lastInsertId();
                setFlash('success', 'مشتری جدید اضافه شد.');
                $back = 'crm.php?id=' . $id;
            }
        }

    } elseif ($act === 'activity' && $id) {
        $type = isset($types[$_POST['type'] ?? '']) ? $_POST['type'] : 'note';
        $note = trim(mb_substr((string)($_POST['note'] ?? ''), 0, 3000));
        if ($note === '') {
            setFlash('error', 'متن گزارش را وارد کنید.');
        } else {
            $exists = $pdo->prepare("SELECT COUNT(*) FROM crm_contacts WHERE id=?");
            $exists->execute([$id]);
            if ($exists->fetchColumn()) {
                $pdo->prepare("INSERT INTO crm_activities (contact_id, type, note, created_at) VALUES (?,?,?,?)")->execute([$id, $type, $note, $now]);
                $sets = "updated_at=?"; $p = [$now];
                if ($type !== 'note') { $sets .= ", last_contact_at=?"; $p[] = $now; }
                // ثبت تاریخ پیگیری بعدی (اختیاری)
                $fuRaw = trim((string)($_POST['next_followup'] ?? ''));
                if ($fuRaw !== '') {
                    if ($fu = jalali_to_date($fuRaw)) { $sets .= ", next_followup=?"; $p[] = $fu; }
                    else setFlash('error', 'گزارش ثبت شد، اما تاریخ پیگیری نامعتبر بود و ذخیره نشد.');
                } elseif (!empty($_POST['clear_followup'])) {
                    $sets .= ", next_followup=NULL";
                }
                $p[] = $id;
                $pdo->prepare("UPDATE crm_contacts SET $sets WHERE id=?")->execute($p);
                if (empty($_SESSION['flash'])) setFlash('success', 'گزارش ارتباط ثبت شد.');
            }
        }

    } elseif ($act === 'del_activity' && $id) {
        $aid = (int)($_POST['activity_id'] ?? 0);
        $pdo->prepare("DELETE FROM crm_activities WHERE id=? AND contact_id=?")->execute([$aid, $id]);
        setFlash('success', 'گزارش حذف شد.');

    } elseif ($act === 'delete' && $id) {
        $pdo->prepare("DELETE FROM crm_contacts WHERE id=?")->execute([$id]);
        setFlash('success', 'مشتری از CRM حذف شد (حساب کاربری و سفارش‌ها دست‌نخورده می‌مانند).');
        $back = 'crm.php';
    }
    redirect($back);
}

// ───── همگام‌سازی خودکار در اولین ورود (وقتی CRM هنوز خالی است) ─────
if ((int)$pdo->query("SELECT COUNT(*) FROM crm_contacts")->fetchColumn() === 0 && !isset($_GET['id']) && !isset($_GET['new'])) {
    crm_sync($pdo);
}

$when = function ($dt) { return $dt ? fa_digits(jalali_str($dt, false) . ' — ' . date('H:i', strtotime($dt))) : '—'; };
$day  = function ($d) { return $d ? fa_digits(jalali_str($d, false)) : '—'; };
$money = function ($n) { return fa_digits(number_format((float)$n)); };
$today = date('Y-m-d');

$view = null; $isNew = isset($_GET['new']);
if (isset($_GET['id'])) {
    $st = $pdo->prepare("SELECT * FROM crm_contacts WHERE id=?");
    $st->execute([(int)$_GET['id']]);
    $view = $st->fetch() ?: null;
}

$pageTitle = 'CRM — مدیریت مشتریان';
require_once '../includes/header.php';
?>
<div class="max-w-6xl mx-auto px-4 py-8">
  <div class="flex justify-between items-center mb-5 flex-wrap gap-3">
    <h1 class="text-2xl font-black text-slate-900 flex items-center gap-2"><span class="w-2 h-7 bg-brand-orange rounded-full"></span>🤝 CRM — مدیریت مشتریان</h1>
    <div class="flex gap-2 flex-wrap">
      <a href="crm.php?new=1" class="bg-brand-orange hover:bg-brand-hover text-white font-bold px-4 py-2.5 rounded-xl text-xs">➕ مشتری جدید</a>
      <form method="post" class="inline"><?= mail_csrf_field() ?><input type="hidden" name="act" value="sync">
        <button class="bg-slate-800 hover:bg-slate-900 text-white font-bold px-4 py-2.5 rounded-xl text-xs" title="افزودن کاربران، خریداران و پیام‌های فرم تماس که هنوز در CRM نیستند">🔄 همگام‌سازی از سایت</button></form>
      <?php if (!$isNew && !$view && !isset($_GET['id'])): ?><a href="crm_print.php?<?= sanitize(http_build_query(array_filter(['q' => $_GET['q'] ?? '', 'stage' => $_GET['stage'] ?? '', 'due' => $_GET['due'] ?? ''], 'strlen'))) ?>" target="_blank" class="bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold px-4 py-2.5 rounded-xl text-xs">🖨 چاپ لیست</a><?php endif; ?>
      <a href="index.php" class="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-4 py-2.5 rounded-xl text-xs">← داشبورد</a>
    </div>
  </div>

<?php if ($isNew || $view): ?>
  <?php
    $c = $view ?: ['id' => 0, 'name' => '', 'phone' => '', 'email' => '', 'city' => '', 'stage' => 'lead', 'tags' => '', 'notes' => '', 'next_followup' => null, 'source' => 'manual', 'user_id' => null];
    $orders = $view ? crm_contact_orders($pdo, $c) : [];
    [$oCount, $oSum, $oLast] = crm_order_stats($orders);
    $acts = [];
    if ($view) {
        $st = $pdo->prepare("SELECT * FROM crm_activities WHERE contact_id=? ORDER BY created_at DESC, id DESC");
        $st->execute([$c['id']]);
        $acts = $st->fetchAll();
    }
    $overdue = $view && $c['next_followup'] && $c['next_followup'] <= $today && $c['stage'] !== 'inactive';
    $statusLbl = ['pending' => 'در انتظار', 'processing' => 'در حال پردازش', 'shipped' => 'ارسال‌شده', 'delivered' => 'تحویل‌شده', 'cancelled' => 'لغو‌شده'];
  ?>
  <a href="crm.php" class="inline-block text-xs text-blue-600 mb-3">← بازگشت به لیست مشتریان</a>

  <?php if ($view): ?>
  <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
    <div class="bg-white border border-slate-200 rounded-2xl p-4"><div class="text-[11px] text-slate-500">مرحله</div>
      <div class="mt-1"><span class="text-xs font-bold px-2 py-1 rounded-full <?= $stages[$c['stage']][1] ?? 'bg-slate-100' ?>"><?= $stages[$c['stage']][0] ?? sanitize($c['stage']) ?></span></div></div>
    <div class="bg-white border border-slate-200 rounded-2xl p-4"><div class="text-[11px] text-slate-500">تعداد سفارش</div><div class="text-xl font-black text-slate-900"><?= fa_digits($oCount) ?></div></div>
    <div class="bg-white border border-slate-200 rounded-2xl p-4"><div class="text-[11px] text-slate-500">جمع خرید (تومان)</div><div class="text-xl font-black text-slate-900"><?= $money($oSum) ?></div></div>
    <div class="bg-white border border-slate-200 rounded-2xl p-4"><div class="text-[11px] text-slate-500">آخرین سفارش</div><div class="text-sm font-black text-slate-900 mt-1"><?= $oLast ? $day($oLast) : '—' ?></div></div>
  </div>
  <?php endif; ?>

  <div class="grid lg:grid-cols-5 gap-5">
    <!-- فرم اطلاعات -->
    <form method="post" class="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-5 space-y-3 self-start">
      <?= mail_csrf_field() ?><input type="hidden" name="act" value="save"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
      <h2 class="font-black text-slate-800"><?= $view ? '✏️ اطلاعات مشتری' : '➕ مشتری جدید' ?></h2>
      <div><label class="block text-xs font-bold text-slate-600 mb-1">نام و نام‌خانوادگی *</label>
        <input type="text" name="name" required maxlength="150" value="<?= sanitize($c['name']) ?>" class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm"></div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-bold text-slate-600 mb-1">موبایل</label>
          <input type="text" name="phone" dir="ltr" maxlength="30" value="<?= sanitize($c['phone']) ?>" class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm"></div>
        <div><label class="block text-xs font-bold text-slate-600 mb-1">شهر</label>
          <input type="text" name="city" maxlength="80" value="<?= sanitize($c['city']) ?>" class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm"></div>
      </div>
      <div><label class="block text-xs font-bold text-slate-600 mb-1">ایمیل</label>
        <input type="email" name="email" dir="ltr" maxlength="190" value="<?= sanitize($c['email']) ?>" class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm"></div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-bold text-slate-600 mb-1">مرحله</label>
          <select name="stage" class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm">
            <?php foreach ($stages as $k => [$lbl]): ?><option value="<?= $k ?>" <?= $c['stage'] === $k ? 'selected' : '' ?>><?= $lbl ?></option><?php endforeach; ?>
          </select></div>
        <div><label class="block text-xs font-bold text-slate-600 mb-1">پیگیری بعدی (شمسی)</label>
          <input type="text" name="next_followup" dir="ltr" placeholder="1405/08/25" value="<?= $c['next_followup'] ? sanitize(jalali_str($c['next_followup'], false)) : '' ?>" class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm"></div>
      </div>
      <div><label class="block text-xs font-bold text-slate-600 mb-1">برچسب‌ها (با ویرگول جدا کنید)</label>
        <input type="text" name="tags" maxlength="255" placeholder="مثلاً: عمده‌فروش، آیفون" value="<?= sanitize($c['tags']) ?>" class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm"></div>
      <div><label class="block text-xs font-bold text-slate-600 mb-1">یادداشت</label>
        <textarea name="notes" rows="4" maxlength="5000" class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm leading-7"><?= sanitize($c['notes']) ?></textarea></div>
      <?php if ($view): ?>
        <div class="text-[11px] text-slate-400">منبع: <?= sanitize($srcs[$c['source']] ?? $c['source']) ?> — ثبت: <?= $when($c['created_at']) ?></div>
      <?php endif; ?>
      <?php if (!$view) echo recaptcha_widget($pdo); ?>
      <div class="flex gap-2 flex-wrap pt-1">
        <button class="bg-brand-orange hover:bg-brand-hover text-white font-bold px-6 py-2.5 rounded-xl text-xs">💾 ذخیره</button>
        <?php if ($view && $c['email']): ?><a href="messages.php?compose=1&to=<?= urlencode($c['email']) ?>" class="bg-slate-100 text-slate-700 font-bold px-4 py-2.5 rounded-xl text-xs">✉️ ارسال ایمیل</a><?php endif; ?>
        <?php if ($view): ?><a href="crm_print.php?id=<?= (int)$c['id'] ?>" target="_blank" class="bg-slate-100 text-slate-700 font-bold px-4 py-2.5 rounded-xl text-xs">🖨 چاپ پرونده</a><?php endif; ?>
        <?php if ($view && $c['phone']): ?><a href="tel:<?= sanitize($c['phone']) ?>" class="bg-emerald-50 text-emerald-700 font-bold px-4 py-2.5 rounded-xl text-xs">📞 تماس</a><?php endif; ?>
      </div>
    </form>

    <div class="lg:col-span-3 space-y-5">
    <?php if ($view): ?>
      <?php if ($overdue): ?>
        <div class="bg-amber-50 border border-amber-200 text-amber-900 rounded-2xl p-3 text-xs font-bold">⏰ موعد پیگیری این مشتری <?= $c['next_followup'] === $today ? 'امروز' : 'گذشته' ?> است (<?= $day($c['next_followup']) ?>).</div>
      <?php endif; ?>

      <!-- ثبت ارتباط -->
      <form method="post" class="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
        <?= mail_csrf_field() ?><input type="hidden" name="act" value="activity"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
        <h3 class="font-black text-slate-800 text-sm">📝 ثبت گزارش ارتباط</h3>
        <div class="grid grid-cols-2 gap-3">
          <select name="type" class="px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm">
            <?php foreach ($types as $k => $lbl): ?><option value="<?= $k ?>"><?= $lbl ?></option><?php endforeach; ?>
          </select>
          <input type="text" name="next_followup" dir="ltr" placeholder="پیگیری بعدی: 1405/08/25 (اختیاری)" class="px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm">
        </div>
        <textarea name="note" rows="3" required maxlength="3000" placeholder="خلاصه‌ی گفتگو یا اقدام انجام‌شده..." class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm leading-7"></textarea>
        <div class="flex items-center gap-4 flex-wrap">
          <button class="bg-slate-900 hover:bg-black text-white font-bold px-6 py-2.5 rounded-xl text-xs">ثبت گزارش</button>
          <?php if ($c['next_followup']): ?><label class="text-xs text-slate-600 flex items-center gap-1"><input type="checkbox" name="clear_followup" value="1"> پیگیری انجام شد (پاک‌کردن تاریخ پیگیری)</label><?php endif; ?>
        </div>
      </form>

      <!-- تاریخچه -->
      <div class="bg-white border border-slate-200 rounded-2xl p-5">
        <h3 class="font-black text-slate-800 text-sm mb-3">🕘 تاریخچه‌ی ارتباط (<?= fa_digits(count($acts)) ?>)</h3>
        <?php if (!$acts): ?><p class="text-xs text-slate-400 text-center py-4">هنوز گزارشی ثبت نشده است.</p><?php endif; ?>
        <div class="divide-y divide-slate-100">
        <?php foreach ($acts as $a): ?>
          <div class="py-3 flex gap-3 items-start">
            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-2 text-[11px] text-slate-500 mb-1"><b class="text-slate-700"><?= $types[$a['type']] ?? sanitize($a['type']) ?></b><span><?= $when($a['created_at']) ?></span></div>
              <div class="text-sm leading-7 text-slate-800 break-words" dir="auto"><?= nl2br(sanitize($a['note'])) ?></div>
            </div>
            <form method="post" onsubmit="return confirm('این گزارش حذف شود؟')"><?= mail_csrf_field() ?><input type="hidden" name="act" value="del_activity"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>"><input type="hidden" name="activity_id" value="<?= (int)$a['id'] ?>">
              <button class="text-[11px] bg-red-50 hover:bg-red-100 text-red-700 px-2 py-1 rounded-lg">🗑</button></form>
          </div>
        <?php endforeach; ?>
        </div>
      </div>

      <!-- سفارش‌ها -->
      <div class="bg-white border border-slate-200 rounded-2xl p-5">
        <h3 class="font-black text-slate-800 text-sm mb-3">🛒 سفارش‌های مشتری (<?= fa_digits(count($orders)) ?>)</h3>
        <?php if (!$orders): ?><p class="text-xs text-slate-400 text-center py-4">سفارشی با این موبایل، ایمیل یا حساب کاربری پیدا نشد.</p><?php else: ?>
        <div class="divide-y divide-slate-100 text-xs">
          <?php foreach (array_slice($orders, 0, 15) as $o): ?>
            <a href="orders.php?q=<?= (int)$o['id'] ?>" class="flex items-center justify-between py-2.5 hover:bg-slate-50 gap-3">
              <span class="font-bold text-slate-800">#<?= fa_digits($o['id']) ?></span>
              <span class="text-slate-500"><?= $day($o['created_at']) ?></span>
              <span class="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600"><?= $statusLbl[$o['status']] ?? sanitize($o['status']) ?></span>
              <span class="font-bold text-slate-900"><?= $money($o['total']) ?> <small class="text-slate-400 font-normal">تومان</small></span>
            </a>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>

      <form method="post" onsubmit="return confirm('این مشتری از CRM حذف شود؟ (حساب کاربری و سفارش‌ها حذف نمی‌شوند)')">
        <?= mail_csrf_field() ?><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
        <button class="bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 font-bold px-4 py-2 rounded-xl text-xs">🗑 حذف مشتری از CRM</button>
      </form>
    <?php else: ?>
      <div class="bg-white border border-slate-200 rounded-2xl p-8 text-center text-slate-400 text-sm">پس از ذخیره‌ی مشتری، می‌توانید گزارش تماس‌ها و پیگیری‌ها را ثبت کنید.</div>
    <?php endif; ?>
    </div>
  </div>

<?php elseif (isset($_GET['id'])): ?>
  <div class="bg-white border border-slate-200 rounded-2xl p-10 text-center text-slate-400 text-sm">مشتری پیدا نشد. <a href="crm.php" class="text-blue-600 underline">بازگشت</a></div>

<?php else:
  // ───── لیست ─────
  $q     = trim((string)($_GET['q'] ?? ''));
  $stage = isset($stages[$_GET['stage'] ?? '']) ? $_GET['stage'] : '';
  $due   = !empty($_GET['due']);

  $cnt = ['all' => 0];
  foreach ($stages as $k => $_) $cnt[$k] = 0;
  foreach ($pdo->query("SELECT stage, COUNT(*) n FROM crm_contacts GROUP BY stage")->fetchAll() as $r) {
      $cnt['all'] += (int)$r['n'];
      if (isset($cnt[$r['stage']])) $cnt[$r['stage']] = (int)$r['n'];
  }
  $dueN = crm_due_count($pdo);

  [$W, $params, $order] = crm_list_filter($q, $stage, $due);
  $st = $pdo->prepare("SELECT COUNT(*) FROM crm_contacts WHERE $W"); $st->execute($params);
  $total = (int)$st->fetchColumn();
  $perPage = 25;
  $pages = max(1, (int)ceil($total / $perPage));
  $page = min($pages, max(1, (int)($_GET['page'] ?? 1)));
  $off = ($page - 1) * $perPage;
  $st = $pdo->prepare("SELECT * FROM crm_contacts WHERE $W ORDER BY $order LIMIT $perPage OFFSET $off"); $st->execute($params);
  $rows = $st->fetchAll();
  $qs = function ($extra = []) use ($q, $stage, $due) {
      return '?' . http_build_query(array_filter(array_merge(['q' => $q, 'stage' => $stage, 'due' => $due ? 1 : ''], $extra), 'strlen'));
  };
?>
  <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
    <a href="crm.php" class="bg-white border border-slate-200 rounded-2xl p-4 hover:border-brand-orange"><div class="text-[11px] text-slate-500">همه‌ی مشتریان</div><div class="text-2xl font-black text-slate-900"><?= fa_digits($cnt['all']) ?></div></a>
    <a href="crm.php?stage=lead" class="bg-white border border-slate-200 rounded-2xl p-4 hover:border-brand-orange"><div class="text-[11px] text-slate-500">سرنخ‌ها</div><div class="text-2xl font-black text-sky-700"><?= fa_digits($cnt['lead'] + $cnt['prospect']) ?></div></a>
    <a href="crm.php?stage=customer" class="bg-white border border-slate-200 rounded-2xl p-4 hover:border-brand-orange"><div class="text-[11px] text-slate-500">مشتریان</div><div class="text-2xl font-black text-emerald-700"><?= fa_digits($cnt['customer'] + $cnt['vip']) ?></div></a>
    <a href="crm.php?due=1" class="bg-white border <?= $dueN ? 'border-amber-300 bg-amber-50' : 'border-slate-200' ?> rounded-2xl p-4 hover:border-brand-orange"><div class="text-[11px] text-slate-500">پیگیری‌های امروز / عقب‌افتاده</div><div class="text-2xl font-black <?= $dueN ? 'text-amber-700' : 'text-slate-900' ?>"><?= fa_digits($dueN) ?></div></a>
  </div>

  <div class="flex gap-2 flex-wrap mb-4 items-center">
    <a href="crm.php<?= $q !== '' ? '?q=' . urlencode($q) : '' ?>" class="px-4 py-2 rounded-xl text-xs font-bold <?= $stage === '' && !$due ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-700' ?>">همه (<?= fa_digits($cnt['all']) ?>)</a>
    <?php foreach ($stages as $k => [$lbl]): ?>
      <a href="<?= $qs(['stage' => $k, 'due' => '', 'page' => '']) ?>" class="px-3 py-2 rounded-xl text-xs font-bold <?= $stage === $k ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-700' ?>"><?= $lbl ?> (<?= fa_digits($cnt[$k]) ?>)</a>
    <?php endforeach; ?>
    <form method="get" class="mr-auto flex gap-2">
      <?php if ($stage): ?><input type="hidden" name="stage" value="<?= sanitize($stage) ?>"><?php endif; ?>
      <?php if ($due): ?><input type="hidden" name="due" value="1"><?php endif; ?>
      <input type="search" name="q" value="<?= sanitize($q) ?>" placeholder="جستجوی نام، موبایل، ایمیل، برچسب..." class="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs w-60">
      <button class="bg-white border border-slate-200 px-3 py-2 rounded-xl text-xs">🔍</button>
    </form>
  </div>

  <?php if (!$rows): ?>
    <div class="bg-white border border-slate-200 rounded-2xl p-10 text-center text-slate-400 text-sm">
      <?= ($q !== '' || $stage || $due) ? 'نتیجه‌ای پیدا نشد.' : 'هنوز مشتری‌ای ثبت نشده است. از «مشتری جدید» یا «همگام‌سازی از سایت» استفاده کنید.' ?></div>
  <?php else: ?>
  <div class="bg-white border border-slate-200 rounded-2xl overflow-hidden"><div class="overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="bg-slate-50 border-b border-slate-200"><tr class="text-xs text-slate-500">
        <th class="px-4 py-3 text-right font-bold">مشتری</th>
        <th class="px-4 py-3 text-right font-bold">تماس</th>
        <th class="px-4 py-3 text-right font-bold">مرحله</th>
        <th class="px-4 py-3 text-right font-bold">سفارش / خرید</th>
        <th class="px-4 py-3 text-right font-bold">پیگیری بعدی</th>
        <th class="px-4 py-3 text-right font-bold">آخرین ارتباط</th>
      </tr></thead>
      <tbody class="divide-y divide-slate-100">
      <?php foreach ($rows as $r):
          [$n, $sum] = crm_order_stats(crm_contact_orders($pdo, $r));
          $late = $r['next_followup'] && $r['next_followup'] <= $today && $r['stage'] !== 'inactive'; ?>
        <tr class="hover:bg-slate-50 cursor-pointer" onclick="location.href='crm.php?id=<?= (int)$r['id'] ?>'">
          <td class="px-4 py-3 text-xs">
            <a href="crm.php?id=<?= (int)$r['id'] ?>" class="font-bold text-slate-800"><?= sanitize($r['name']) ?></a>
            <?php foreach (array_slice(crm_tag_list($r['tags']), 0, 3) as $t): ?><span class="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full mr-1"><?= sanitize($t) ?></span><?php endforeach; ?>
            <?php if ($r['city']): ?><div class="text-[11px] text-slate-400"><?= sanitize($r['city']) ?></div><?php endif; ?>
          </td>
          <td class="px-4 py-3 text-xs" dir="ltr" style="text-align:right"><?= sanitize($r['phone'] ?: '—') ?><?php if ($r['email']): ?><div class="text-[11px] text-slate-400"><?= sanitize($r['email']) ?></div><?php endif; ?></td>
          <td class="px-4 py-3"><span class="text-[10px] font-bold px-2 py-1 rounded-full <?= $stages[$r['stage']][1] ?? 'bg-slate-100' ?>"><?= $stages[$r['stage']][0] ?? sanitize($r['stage']) ?></span></td>
          <td class="px-4 py-3 text-xs"><b class="text-brand-orange"><?= fa_digits($n) ?></b> <span class="text-slate-400">سفارش</span><?php if ($sum): ?><div class="text-[11px] text-slate-500"><?= $money($sum) ?> تومان</div><?php endif; ?></td>
          <td class="px-4 py-3 text-xs <?= $late ? 'text-amber-700 font-black' : 'text-slate-600' ?>"><?= $late ? '⏰ ' : '' ?><?= $day($r['next_followup']) ?></td>
          <td class="px-4 py-3 text-[11px] text-slate-500"><?= $when($r['last_contact_at']) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div></div>

  <?php if ($pages > 1): ?>
    <div class="flex gap-1 justify-center mt-4 flex-wrap">
      <?php for ($i = 1; $i <= $pages; $i++): ?>
        <a href="<?= $qs(['page' => $i]) ?>" class="px-3 py-1.5 rounded-lg text-xs <?= $i === $page ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200' ?>"><?= fa_digits($i) ?></a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
  <?php endif; ?>

  <?php $rc = recaptcha_conf($pdo); ?>
  <details id="recaptcha" class="mt-6 bg-white border border-slate-200 rounded-2xl p-5" <?= (isset($_GET['rc']) ? 'open' : '') ?>>
    <summary class="cursor-pointer font-black text-slate-800 text-sm">🔒 تنظیمات reCAPTCHA <span class="text-[11px] font-bold <?= recaptcha_enabled($pdo) ? 'text-emerald-600' : 'text-slate-400' ?>">(<?= recaptcha_enabled($pdo) ? 'فعال' : 'غیرفعال' ?>)</span></summary>
    <form method="post" class="mt-4 space-y-3 max-w-xl">
      <?= mail_csrf_field() ?><input type="hidden" name="act" value="recaptcha_settings">
      <p class="text-[11px] text-slate-500 leading-6">کلیدها را از <b dir="ltr">google.com/recaptcha/admin</b> بگیرید (نوع: reCAPTCHA v2 — «I'm not a robot»؛ دامنه‌ی <span dir="ltr">localhost</span> را هم برای تست اضافه کنید). با فعال‌شدن، افزودن مشتری جدید در CRM نیازمند تأیید «من ربات نیستم» است.</p>
      <div><label class="block text-xs font-bold text-slate-600 mb-1">Site Key</label>
        <input type="text" name="rc_site" dir="ltr" value="<?= sanitize($rc['site']) ?>" class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm"></div>
      <div><label class="block text-xs font-bold text-slate-600 mb-1">Secret Key <?= $rc['secret'] !== '' ? '<span class="text-emerald-600 font-normal">(ثبت شده — برای تغییر، مقدار جدید بنویسید)</span>' : '' ?></label>
        <input type="password" name="rc_secret" dir="ltr" autocomplete="off" class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm"></div>
      <label class="text-xs text-slate-700 flex items-center gap-2"><input type="checkbox" name="rc_enabled" value="1" <?= $rc['enabled'] ? 'checked' : '' ?>> فعال‌سازی reCAPTCHA</label>
      <button class="bg-slate-900 hover:bg-black text-white font-bold px-6 py-2.5 rounded-xl text-xs">💾 ذخیره‌ی تنظیمات</button>
    </form>
  </details>
<?php endif; ?>
</div>
<?php require_once '../includes/footer.php'; ?>
