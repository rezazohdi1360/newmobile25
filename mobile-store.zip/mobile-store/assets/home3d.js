/* صفحه اول سه‌بعدی — فروشگاه ابزارآلات (بدون وابستگی به کتابخانه) */
(function () {
  'use strict';
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fine = window.matchMedia('(hover:hover) and (pointer:fine)').matches;

  /* مسیر چرخ‌دنده ۱۲ دندانه با سوراخ مرکزی (clip-path با evenodd) */
  function gearPath() {
    var N = 12, Ro = 50, Rr = 41, pts = [];
    function p(a, r) {
      var t = a * Math.PI / 180;
      return (50 + r * Math.cos(t)).toFixed(2) + '% ' + (50 + r * Math.sin(t)).toFixed(2) + '%';
    }
    for (var k = 0; k < N; k++) {
      var a = k * 360 / N;
      pts.push(p(a - 11, Rr), p(a - 7, Rr), p(a - 4.5, Ro), p(a + 4.5, Ro), p(a + 7, Rr), p(a + 11, Rr));
    }
    var first = pts[0], hole = [];
    for (var h = 0; h < 28; h++) hole.push(p(h * 360 / 28, 15));
    return 'polygon(evenodd,' + pts.join(',') + ',' + first + ',' + hole.join(',') + ',' + hole[0] + ',' + first + ')';
  }

  function buildTools() {
    var hero = document.querySelector('.hero-main');
    if (!hero || hero.querySelector('.h3d-stage')) return;
    hero.classList.add('has-3d');

    var layers = '', L = 28;
    for (var i = 0; i < L; i++) {
      var cls = i === L - 1 ? 'gl gf' : (i === 0 ? 'gl gb' : 'gl');
      layers += '<div class="' + cls + '" style="transform:translateZ(' + (i - (L - 1) / 2) + 'px)"></div>';
    }
    var nut = '';
    for (var s = 0; s < 6; s++) nut += '<div class="nf"></div>';
    nut += '<div class="nc t"></div><div class="nc b"></div>';

    var stage = document.createElement('div');
    stage.className = 'h3d-stage';
    stage.setAttribute('aria-hidden', 'true');
    stage.innerHTML =
      '<div class="h3d-shadow"></div>' +
      '<div class="h3d-tool">' +
        '<div class="h3d-gear">' + layers + '</div>' +
        '<div class="h3d-nutpos"><div class="h3d-nut">' + nut + '</div></div>' +
      '</div>';
    stage.querySelector('.h3d-gear').style.setProperty('--gear', gearPath());
    hero.appendChild(stage);

    var tool = stage.querySelector('.h3d-tool'),
        gear = stage.querySelector('.h3d-gear'),
        nutPos = stage.querySelector('.h3d-nutpos'),
        nutEl = stage.querySelector('.h3d-nut'),
        shadow = stage.querySelector('.h3d-shadow');

    var tx = 0, ty = 0, cx = 0, cy = 0, t0 = performance.now();

    if (fine && !reduce) {
      hero.addEventListener('pointermove', function (e) {
        var r = hero.getBoundingClientRect();
        tx = ((e.clientX - r.left) / r.width - 0.5) * 2;
        ty = ((e.clientY - r.top) / r.height - 0.5) * 2;
        hero.style.setProperty('--mx', tx.toFixed(3));
        hero.style.setProperty('--my', ty.toFixed(3));
      });
      hero.addEventListener('pointerleave', function () {
        tx = 0; ty = 0;
        hero.style.setProperty('--mx', 0); hero.style.setProperty('--my', 0);
      });
    }

    function frame(now) {
      var t = (now - t0) / 1000;
      cx += (tx - cx) * 0.08;
      cy += (ty - cy) * 0.08;
      var sway = reduce ? 0 : Math.sin(t * 0.6) * 22;
      var bob = reduce ? 0 : Math.sin(t * 1.2) * 6;
      var ry = -24 + sway + cx * 30;
      var rx = 14 - cy * 16;
      tool.style.transform = 'translateY(' + bob.toFixed(1) + 'px) rotateX(' + rx.toFixed(1) + 'deg) rotateY(' + ry.toFixed(1) + 'deg)';
      gear.style.transform = 'rotateZ(' + (reduce ? 0 : (t * 14) % 360).toFixed(1) + 'deg)';
      nutPos.style.transform = 'translate3d(' + (82 + Math.cos(t * 0.8) * 10).toFixed(1) + 'px,' +
        (104 + Math.sin(t * 1.1) * 8).toFixed(1) + 'px,70px)';
      nutEl.style.transform = 'rotateX(' + (reduce ? 25 : t * 50) % 360 + 'deg) rotateY(' + (reduce ? 20 : t * 80) % 360 + 'deg)';
      shadow.style.setProperty('--ss', (1 - bob / 40).toFixed(3));
      shadow.style.setProperty('--so', (0.8 - bob / 40).toFixed(3));
      if (!reduce) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
    if (reduce) frame(performance.now());
  }

  /* کج‌شدن سه‌بعدی کارت‌ها */
  function tilt(el, max) {
    el.classList.add('t3d');
    if (!fine || reduce) return;
    el.addEventListener('pointermove', function (e) {
      var r = el.getBoundingClientRect();
      var px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
      el.classList.add('tilting');
      el.style.setProperty('--ry', ((px - 0.5) * max * 2).toFixed(2) + 'deg');
      el.style.setProperty('--rx', ((0.5 - py) * max * 2).toFixed(2) + 'deg');
      el.style.setProperty('--gx', (px * 100).toFixed(0) + '%');
      el.style.setProperty('--gy', (py * 100).toFixed(0) + '%');
    });
    el.addEventListener('pointerleave', function () {
      el.classList.remove('tilting');
      el.style.setProperty('--rx', '0deg');
      el.style.setProperty('--ry', '0deg');
    });
  }

  function init() {
    buildTools();
    document.querySelectorAll('.product-card').forEach(function (el) { tilt(el, 6); });
    document.querySelectorAll('.category-card').forEach(function (el) { tilt(el, 8); });
    document.querySelectorAll('.hs').forEach(function (el) { tilt(el, 5); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
