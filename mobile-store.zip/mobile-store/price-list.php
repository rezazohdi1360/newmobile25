<?php
/**
 * لیست قیمت — صفحه‌ی عمومی
 * دسته‌بندی‌های بازشونده، جستجو، «فقط موجودها»، نمایش تصاویر، قیمت پلکانی، انتخاب تعداد و جمع تقریبی،
 * دانلود اکسل، چاپ / ذخیره PDF، اشتراک‌گذاری (واتس‌اپ، تلگرام، بله، کپی لینک)، افزودن انتخاب‌شده‌ها به سبد خرید
 */
require_once 'config/database.php';
require_once 'includes/pricelist.php';

$S = pricelist_settings($pdo);
if (!$S['enabled']) { http_response_code(404); exit('این صفحه در دسترس نیست.'); }

// ───── افزودن گروهی به سبد (AJAX) ─────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_cart') {
    header('Content-Type: application/json; charset=utf-8');
    $in = json_decode((string)($_POST['items'] ?? ''), true);
    if (!is_array($in) || !$in) { echo json_encode(['success' => false, 'message' => 'هیچ کالایی انتخاب نشده است']); exit; }
    $ids = array_values(array_unique(array_filter(array_map('intval', array_keys($in)))));
    if (!$ids) { echo json_encode(['success' => false, 'message' => 'انتخاب نامعتبر']); exit; }
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $st = $pdo->prepare("SELECT id, price, stock, stock_status FROM products WHERE status=1 AND id IN ($ph)");
    $st->execute($ids);
    if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) $_SESSION['cart'] = [];
    $added = 0; $skipped = 0;
    foreach ($st->fetchAll() as $p) {
        $q = max(0, (int)($in[$p['id']] ?? 0));
        if ($q < 1 || $p['stock_status'] !== 'in_stock' || (int)$p['stock'] <= 0 || (float)$p['price'] <= 0) { $skipped++; continue; }
        $cap = min((int)$p['stock'], 99);
        $_SESSION['cart'][$p['id']] = min($cap, (int)($_SESSION['cart'][$p['id']] ?? 0) + $q);
        $added++;
    }
    echo json_encode(['success' => $added > 0, 'added' => $added, 'skipped' => $skipped,
        'message' => $added ? '' : 'کالاهای انتخاب‌شده ناموجود هستند']);
    exit;
}

$data = pricelist_load($pdo);
if (($_GET['download'] ?? '') === 'xlsx') pricelist_download($data);

$fa    = function ($v) { return strtr((string)$v, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']); };
$money = function ($n) use ($fa) { return $fa(number_format((float)$n)); };
$e     = function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); };
$day   = function ($d) use ($fa) { return $d ? $fa(jalali_str($d, false)) : '—'; };

$scheme  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$pageUrl = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . strtok($_SERVER['REQUEST_URI'] ?? '/price-list.php', '?');
$shareTxt = 'لیست قیمت ' . SITE_NAME . ($data['updated'] ? ' — ' . jalali_str($data['updated'], false) : '');
$waPhone = preg_replace('/\D+/', '', strtr((string)$S['phone'], ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9']));
if ($waPhone !== '' && $waPhone[0] === '0') $waPhone = '98' . substr($waPhone, 1);
$inquiryUrl = function ($name) use ($waPhone) {
    return $waPhone !== '' ? 'https://wa.me/' . $waPhone . '?text=' . rawurlencode('سلام، قیمت و موجودی «' . $name . '» را می‌خواستم.') : 'contact.php';
};
$hasTier = false;
foreach ($data['groups'] as $g) foreach ($g['items'] as $it) if ($it['tier1_qty'] && $it['tier1_price']) { $hasTier = true; break 2; }
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $e($S['title']) ?> | <?= $e(SITE_NAME) ?></title>
<link rel="preconnect" href="https://cdn.jsdelivr.net">
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
<style>
:root{
    --navy:#1b2a41;--navy-deep:#111c2d;--navy-soft:#2a3d5c;
    --gold:#b8923a;--gold-light:#d9b968;--gold-pale:#f4ead2;
    --burgundy:#7a1f2b;--cream:#faf7f2;--paper:#fff;
    --ink:#22262e;--muted:#6b7280;--line:#e6dfd0;
    --shadow:0 2px 10px rgba(27,42,65,.07);
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Vazirmatn',Tahoma,sans-serif;background:var(--cream);color:var(--ink);line-height:1.7}
a{color:inherit;text-decoration:none}
.pl{max-width:1180px;margin:0 auto;padding:22px 16px 110px}
.pl h1{font-size:24px;font-weight:900;color:var(--navy);display:flex;align-items:center;gap:10px}
.pl h1:before{content:"";width:8px;height:28px;border-radius:99px;background:var(--gold)}
.meta{margin:6px 0 14px;font-size:13px;color:var(--muted)}
.meta b{color:var(--ink)}
.bar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:10px}
.btn{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--line);background:var(--paper);color:var(--ink);border-radius:10px;padding:8px 14px;font:inherit;font-size:12.5px;font-weight:700;cursor:pointer;white-space:nowrap}
.btn:hover{border-color:var(--gold);color:var(--gold)}
.btn.pri{background:var(--gold);border-color:var(--gold);color:#fff}
.btn.pri:hover{background:var(--navy);border-color:var(--navy);color:#fff}
.btn.dark{background:var(--navy);border-color:var(--navy);color:#fff}
.btn[disabled]{opacity:.45;cursor:not-allowed}
.share{display:flex;gap:6px;align-items:center;font-size:12px;color:var(--muted)}
.share a,.share button{border:1px solid var(--line);background:var(--paper);border-radius:8px;padding:5px 10px;font:inherit;font-size:12px;cursor:pointer;color:var(--ink)}
.share a:hover,.share button:hover{border-color:var(--gold);color:var(--gold)}
.filters{display:flex;flex-wrap:wrap;gap:12px;align-items:center;background:var(--paper);border:1px solid var(--line);border-radius:14px;padding:10px 12px;margin:10px 0 14px;box-shadow:var(--shadow)}
.filters input[type=search]{flex:1;min-width:200px;border:1px solid var(--line);border-radius:10px;padding:9px 12px;font:inherit;font-size:13px;background:var(--cream);color:var(--ink);outline:0}
.filters input[type=search]:focus{border-color:var(--gold)}
.filters label{display:flex;align-items:center;gap:6px;font-size:12.5px;font-weight:700;cursor:pointer;white-space:nowrap}
.cat{background:var(--paper);border:1px solid var(--line);border-radius:14px;margin-bottom:10px;overflow:hidden;box-shadow:var(--shadow)}
.cat>summary{list-style:none;cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:10px;padding:13px 16px;font-weight:900;font-size:15px;color:var(--navy)}
.cat>summary::-webkit-details-marker{display:none}
.cat>summary .cnt{font-size:12px;font-weight:700;color:var(--muted)}
.cat>summary:after{content:"▾";color:var(--gold);transition:transform .2s;margin-right:auto}
.cat[open]>summary:after{transform:rotate(180deg)}
.cat[open]>summary{border-bottom:1px solid var(--line);background:var(--gold-pale)}
.tw{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:13px}
th{background:var(--cream);color:var(--muted);font-weight:700;font-size:12px;text-align:right;padding:9px 12px;white-space:nowrap}
td{padding:10px 12px;border-top:1px solid var(--line);vertical-align:middle}
tr.it:hover td{background:#fffdf8}
tr.it.sel td{background:var(--gold-pale)}
.pn{display:flex;align-items:center;gap:10px;min-width:220px}
.pn img{width:46px;height:46px;border-radius:8px;object-fit:cover;background:#eee;flex:none;display:none}
.showimg .pn img{display:block}
.pn b{font-weight:800;color:var(--ink);display:block}
.pn small{color:var(--muted);font-size:11px}
.pr{font-weight:900;color:var(--navy);white-space:nowrap}
.pr small{display:block;font-weight:500;color:var(--muted);font-size:11px}
.pr s{display:block;color:var(--muted);font-weight:500;font-size:11px}
.tier{font-size:12px;color:var(--ink);white-space:nowrap}
.tier span{display:block}
.dt{font-size:12px;color:var(--muted);white-space:nowrap}
.q{display:inline-flex;align-items:center;border:1px solid var(--line);border-radius:10px;overflow:hidden;background:var(--paper)}
.q button{width:30px;height:32px;border:0;background:var(--cream);font:inherit;font-size:16px;font-weight:900;cursor:pointer;color:var(--navy)}
.q button:hover{background:var(--gold);color:#fff}
.q input{width:44px;height:32px;border:0;text-align:center;font:inherit;font-size:13px;font-weight:800;background:transparent;color:var(--ink);outline:0;-moz-appearance:textfield}
.q input::-webkit-outer-spin-button,.q input::-webkit-inner-spin-button{-webkit-appearance:none}
.na{font-size:12px;color:var(--burgundy);font-weight:700;white-space:nowrap}
.inq{font-size:12px;font-weight:800;color:var(--gold);border:1px solid var(--gold);border-radius:8px;padding:4px 10px;white-space:nowrap}
.inq:hover{background:var(--gold);color:#fff}
.empty{text-align:center;color:var(--muted);padding:40px 10px;font-size:14px}
.note{margin-top:14px;font-size:12px;color:var(--muted);line-height:2;background:var(--paper);border:1px dashed var(--line);border-radius:12px;padding:12px 14px}
.cartbar{position:fixed;inset-inline:0;bottom:0;z-index:60;background:var(--navy-deep);color:#fff;padding:10px 16px;display:flex;align-items:center;gap:12px;flex-wrap:wrap;justify-content:center;box-shadow:0 -6px 20px rgba(0,0,0,.2);transform:translateY(110%);transition:transform .25s}
.cartbar.on{transform:none}
.cartbar b{color:var(--gold-light);font-weight:900}
.cartbar .btn{border-color:rgba(255,255,255,.25);background:transparent;color:#fff}
.cartbar .btn.pri{background:var(--gold);border-color:var(--gold)}
.toast{position:fixed;bottom:80px;right:50%;transform:translateX(50%);background:#111;color:#fff;border-radius:10px;padding:9px 16px;font-size:13px;z-index:80;display:none}
.printhead{display:none}
@media(max-width:700px){.col-tier,.col-dt{display:none}.pn{min-width:150px}.pl h1{font-size:19px}}
@media print{
  @page{size:A4;margin:10mm}
  body{background:#fff}
  .noprint,.sh2-top,nav,header,footer,.cartbar,.toast,.col-qty,.filters{display:none!important}
  .pl{padding:0;max-width:none}
  .printhead{display:block;margin-bottom:8px;font-size:12px}
  .cat{box-shadow:none;border-radius:0;break-inside:auto}
  .cat>summary:after{display:none}
  tr.it{break-inside:avoid}
  tr.it.hid{display:none!important}
  .col-dt{display:table-cell}.col-tier{display:table-cell}
  td,th{padding:5px 8px}
}
</style>
</head>
<body>
<?php require __DIR__ . '/includes/site_header.php'; ?>

<div class="pl" id="pl">
  <h1><?= $e($S['title']) ?></h1>
  <div class="meta">
    آخرین به‌روزرسانی: <b><bdi><?= $day($data['updated']) ?></bdi></b> · <b><bdi><?= $fa($data['count']) ?></bdi></b> کالا
  </div>
  <div class="printhead"><?= $e(SITE_NAME) ?> — <?= $e($S['title']) ?> — تاریخ چاپ: <?= $fa(jalali_str(date('Y-m-d'), false)) ?></div>

  <div class="bar noprint">
    <a class="btn pri" href="?download=xlsx">⬇ دانلود اکسل</a>
    <button class="btn" type="button" onclick="plPrint()">🖨 چاپ / ذخیره PDF</button>
    <div class="share">
      اشتراک‌گذاری:
      <a href="https://wa.me/?text=<?= rawurlencode($shareTxt . "\n" . $pageUrl) ?>" target="_blank" rel="noopener">واتس‌اپ</a>
      <a href="https://t.me/share/url?url=<?= rawurlencode($pageUrl) ?>&text=<?= rawurlencode($shareTxt) ?>" target="_blank" rel="noopener">تلگرام</a>
      <a href="https://ble.ir/share/url?url=<?= rawurlencode($pageUrl) ?>" target="_blank" rel="noopener">بله</a>
      <button type="button" id="copyLink" data-url="<?= $e($pageUrl) ?>">کپی لینک</button>
    </div>
  </div>

  <div class="filters noprint">
    <input type="search" id="q" placeholder="جستجوی نام یا کد کالا..." autocomplete="off">
    <label><input type="checkbox" id="onlyStock"> فقط موجودها</label>
    <label><input type="checkbox" id="showImg"> نمایش تصاویر</label>
    <button class="btn" type="button" id="toggleAll">باز کردن همه</button>
  </div>

  <?php if (!$data['groups']): ?>
    <div class="empty">هنوز کالایی در لیست قیمت ثبت نشده است.</div>
  <?php endif; ?>

  <div id="cats">
  <?php foreach ($data['groups'] as $gi => $g): ?>
    <details class="cat" <?= $gi === 0 ? 'open' : '' ?>>
      <summary><span><?= $e($g['name']) ?></span><span class="cnt"><span class="n"><?= $fa(count($g['items'])) ?></span> کالا</span></summary>
      <div class="tw">
      <table>
        <thead><tr>
          <th>کالا</th><th>قیمت (تومان)</th>
          <?php if ($hasTier): ?><th class="col-tier">قیمت پلکانی</th><?php endif; ?>
          <th class="col-dt">به‌روزرسانی</th><th class="col-qty">تعداد</th>
        </tr></thead>
        <tbody>
        <?php foreach ($g['items'] as $it):
            $t = [];
            if ($it['tier1_qty'] && $it['tier1_price']) $t[] = 'از ' . $fa($it['tier1_qty']) . ': ' . $money($it['tier1_price']);
            if ($it['tier2_qty'] && $it['tier2_price']) $t[] = 'از ' . $fa($it['tier2_qty']) . ': ' . $money($it['tier2_price']);
            $canBuy = $it['in_stock'] && !$it['inquiry'];
            $hay = mb_strtolower($it['name'] . ' ' . $it['code']);
        ?>
          <tr class="it" data-id="<?= $it['id'] ?>" data-s="<?= $e($hay) ?>" data-stock="<?= $it['in_stock'] ? 1 : 0 ?>"
              data-price="<?= (int)$it['price'] ?>" data-max="<?= min(99, max(0, $it['stock'])) ?>"
              data-t1q="<?= $it['tier1_qty'] ?>" data-t1p="<?= (int)$it['tier1_price'] ?>" data-t2q="<?= $it['tier2_qty'] ?>" data-t2p="<?= (int)$it['tier2_price'] ?>">
            <td><div class="pn">
              <img loading="lazy" data-src="<?= $e($it['img'] ?: 'icon/placeholder/no-image.png') ?>" alt="">
              <div><b><a href="product.php?id=<?= $it['id'] ?>"><?= $e($it['name']) ?></a></b><small>کد <?= $e($fa($it['code'])) ?></small></div>
            </div></td>
            <td class="pr">
              <?php if ($it['inquiry']): ?><span class="na" style="color:var(--gold)">استعلام بگیرید</span>
              <?php else: ?>
                <?php if ($it['old_price']): ?><s><?= $money($it['old_price']) ?></s><?php endif; ?>
                <?= $money($it['price']) ?><?php if ($it['unit'] !== ''): ?><small><?= $e($it['unit']) ?></small><?php endif; ?>
              <?php endif; ?>
            </td>
            <?php if ($hasTier): ?><td class="tier col-tier"><?php foreach ($t as $line): ?><span><?= $e($line) ?></span><?php endforeach; ?><?= $t ? '' : '—' ?></td><?php endif; ?>
            <td class="dt col-dt"><?= $day($it['upd']) ?></td>
            <td class="col-qty">
              <?php if ($canBuy): ?>
                <div class="q"><button type="button" data-d="1">+</button><input type="number" min="0" max="<?= min(99, $it['stock']) ?>" value="0" inputmode="numeric"><button type="button" data-d="-1">−</button></div>
              <?php elseif ($it['inquiry']): ?>
                <a class="inq" href="<?= $e($inquiryUrl($it['name'])) ?>" target="_blank" rel="noopener">استعلام</a>
              <?php else: ?><span class="na">ناموجود</span><?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </details>
  <?php endforeach; ?>
  </div>
  <div class="empty" id="noRes" style="display:none">کالایی با این مشخصات پیدا نشد.</div>

  <?php if (trim($S['note']) !== ''): ?><div class="note"><?= nl2br($e($S['note'])) ?></div><?php endif; ?>
</div>

<div class="cartbar" id="cartbar">
  <span><b id="selN">۰</b> قلم انتخاب‌شده — جمع تقریبی: <b id="selSum">۰</b> تومان</span>
  <button class="btn pri" type="button" id="addCart">🛒 افزودن به سبد خرید</button>
  <button class="btn" type="button" id="clearSel">پاک کردن</button>
</div>
<div class="toast" id="toast"></div>

<script>
(function(){
  var $=function(s,r){return (r||document).querySelector(s)}, $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
  var fa=new Intl.NumberFormat('fa-IR');
  var rows=$$('tr.it'), cats=$$('details.cat');
  var toastT;
  function toast(m){var t=$('#toast');t.textContent=m;t.style.display='block';clearTimeout(toastT);toastT=setTimeout(function(){t.style.display='none'},2600)}

  // نرمال‌سازی جستجو: ارقام فارسی/عربی → لاتین، ی/ک عربی → فارسی
  function norm(s){return String(s||'').toLowerCase()
    .replace(/[۰-۹]/g,function(d){return d.charCodeAt(0)-1776})
    .replace(/[٠-٩]/g,function(d){return d.charCodeAt(0)-1632})
    .replace(/ي/g,'ی').replace(/ك/g,'ک').replace(/[‌\s]+/g,' ').trim()}
  rows.forEach(function(r){r._s=norm(r.dataset.s)});

  // ───── فیلتر ─────
  var qEl=$('#q'), stEl=$('#onlyStock');
  function filter(){
    var q=norm(qEl.value), only=stEl.checked, any=false;
    cats.forEach(function(c){
      var vis=0;
      $$('tr.it',c).forEach(function(r){
        var ok=(!q||r._s.indexOf(q)>-1)&&(!only||r.dataset.stock==='1');
        r.style.display=ok?'':'none'; r.classList.toggle('hid',!ok);
        if(ok)vis++;
      });
      c.style.display=vis?'':'none';
      $('.n',c).textContent=fa.format(vis);
      if(vis){any=true; if(q)c.open=true;}
    });
    $('#noRes').style.display=any?'none':'block';
  }
  qEl.addEventListener('input',filter); stEl.addEventListener('change',filter);

  // ───── تصاویر ─────
  var pl=$('#pl'), imgLoaded=false;
  $('#showImg').addEventListener('change',function(){
    pl.classList.toggle('showimg',this.checked);
    if(this.checked&&!imgLoaded){imgLoaded=true;$$('img[data-src]').forEach(function(i){i.src=i.dataset.src})}
  });

  // ───── باز/بستن همه ─────
  var allOpen=false, tg=$('#toggleAll');
  tg.addEventListener('click',function(){allOpen=!allOpen;cats.forEach(function(c){c.open=allOpen});tg.textContent=allOpen?'بستن همه':'باز کردن همه'});

  // ───── تعداد و جمع تقریبی (با قیمت پلکانی) ─────
  function unit(r,q){
    var p=+r.dataset.price, a=+r.dataset.t1q, b=+r.dataset.t1p, c=+r.dataset.t2q, d=+r.dataset.t2p;
    if(a&&b&&q>=a)p=b; if(c&&d&&q>=c)p=d; return p;
  }
  function recalc(){
    var n=0,sum=0;
    rows.forEach(function(r){
      var i=$('.q input',r); if(!i)return;
      var q=parseInt(i.value,10)||0;
      r.classList.toggle('sel',q>0);
      if(q>0){n++;sum+=unit(r,q)*q}
    });
    $('#selN').textContent=fa.format(n); $('#selSum').textContent=fa.format(sum);
    $('#cartbar').classList.toggle('on',n>0);
  }
  rows.forEach(function(r){
    var i=$('.q input',r); if(!i)return;
    var max=+r.dataset.max||99;
    function set(v){v=Math.max(0,Math.min(max,v||0));i.value=v;recalc()}
    $$('.q button',r).forEach(function(b){b.addEventListener('click',function(){set((parseInt(i.value,10)||0)+(+b.dataset.d))})});
    i.addEventListener('input',function(){set(parseInt(i.value,10))});
  });
  $('#clearSel').addEventListener('click',function(){rows.forEach(function(r){var i=$('.q input',r);if(i)i.value=0});recalc()});

  // ───── افزودن به سبد ─────
  $('#addCart').addEventListener('click',function(){
    var items={};
    rows.forEach(function(r){var i=$('.q input',r);var q=i?(parseInt(i.value,10)||0):0;if(q>0)items[r.dataset.id]=q});
    if(!Object.keys(items).length){toast('ابتدا تعداد کالاها را انتخاب کنید');return}
    var b=this;b.disabled=true;
    var fd=new FormData();fd.append('action','add_cart');fd.append('items',JSON.stringify(items));
    fetch(location.pathname,{method:'POST',body:fd}).then(function(r){return r.json()}).then(function(j){
      if(j.success){location.href='cart.php'}else{toast(j.message||'خطا در افزودن به سبد');b.disabled=false}
    }).catch(function(){toast('خطا در ارتباط با سرور');b.disabled=false});
  });

  // ───── کپی لینک ─────
  $('#copyLink').addEventListener('click',function(){
    var u=this.dataset.url;
    (navigator.clipboard?navigator.clipboard.writeText(u):Promise.reject()).then(function(){toast('لینک کپی شد')},function(){prompt('لینک:',u)});
  });

  // ───── چاپ: همه‌ی دسته‌ها باز شوند ─────
  var openState=[];
  function beforePrint(){openState=cats.map(function(c){return c.open});cats.forEach(function(c){c.open=true});
    if($('#showImg').checked&&!imgLoaded){imgLoaded=true;$$('img[data-src]').forEach(function(i){i.src=i.dataset.src})}}
  function afterPrint(){cats.forEach(function(c,i){c.open=openState[i]})}
  window.addEventListener('beforeprint',beforePrint); window.addEventListener('afterprint',afterPrint);
  window.plPrint=function(){window.print()};
})();
</script>

<?php require __DIR__ . '/includes/site_footer.php'; ?>
</body>
</html>
