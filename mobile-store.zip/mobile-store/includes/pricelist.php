<?php
/**
 * لیست قیمت (صفحه‌ی عمومی price-list.php + مدیریت admin/price_list.php)
 *  - داده‌ی اصلی از جدول products (قیمت، موجودی، دسته‌بندی)
 *  - جدول price_list_items برای اطلاعات اختیاری هر کالا: کد، واحد، قیمت پلکانی (تا دو پله)، مخفی، «استعلام بگیرید»
 *  - خروجی اکسل (xlsx واقعی بدون کتابخانه‌ی خارجی؛ در نبود افزونه‌ی zip به CSV برمی‌گردد)
 */
require_once __DIR__ . '/../config/site.php';
require_once __DIR__ . '/coupons.php';   // jalali_str

function pricelist_ensure(PDO $pdo) {
    static $done = false;
    if ($done) return;
    $done = true;
    if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) !== 'mysql') return;
    $pdo->exec("CREATE TABLE IF NOT EXISTS price_list_items (
        product_id INT NOT NULL PRIMARY KEY,
        code VARCHAR(40) NULL,
        unit VARCHAR(60) NULL,
        tier1_qty INT NULL,
        tier1_price DECIMAL(15,0) NULL,
        tier2_qty INT NULL,
        tier2_price DECIMAL(15,0) NULL,
        hidden TINYINT NOT NULL DEFAULT 0,
        inquiry TINYINT NOT NULL DEFAULT 0,
        updated_at DATETIME NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");
}

function pricelist_settings(PDO $pdo) {
    return [
        'enabled' => site_get($pdo, 'pricelist_enabled', '1') !== '0',
        'title'   => site_get($pdo, 'pricelist_title', 'لیست قیمت عمده'),
        'note'    => site_get($pdo, 'pricelist_note', 'قیمت‌ها به تومان است. قیمت پلکانی: «از ۱۰» یعنی قیمت هر واحد برای سفارش ۱۰ عدد و بیشتر. برای قیمت و موجودی دقیق‌تر با ما تماس بگیرید.'),
        'phone'   => site_get($pdo, 'pricelist_phone', ''),     // برای دکمه‌ی «استعلام» (واتس‌اپ/تماس)
    ];
}

/** قیمت واحد مؤثر یک کالا برای تعداد مشخص (پلکانی) */
function pricelist_unit_price(array $it, $qty) {
    $p = (float)$it['price'];
    if (!empty($it['tier1_qty']) && !empty($it['tier1_price']) && $qty >= $it['tier1_qty']) $p = (float)$it['tier1_price'];
    if (!empty($it['tier2_qty']) && !empty($it['tier2_price']) && $qty >= $it['tier2_qty']) $p = (float)$it['tier2_price'];
    return $p;
}

/**
 * همه‌ی کالاهای قابل نمایش، گروه‌بندی‌شده بر اساس دسته‌بندی.
 * خروجی: ['groups' => [ [name, items[]] ... ], 'count' => n, 'updated' => 'Y-m-d H:i:s'|null]
 */
function pricelist_load(PDO $pdo, $includeHidden = false) {
    pricelist_ensure($pdo);
    $sql = "SELECT p.id, p.name, p.main_image, p.price, p.sale_price, p.stock, p.stock_status,
                   COALESCE(p.updated_at, p.created_at) AS upd, p.category_id, c.name AS cat_name,
                   i.code, i.unit, i.tier1_qty, i.tier1_price, i.tier2_qty, i.tier2_price, i.hidden, i.inquiry, i.updated_at AS item_upd
            FROM products p
            LEFT JOIN categories c ON c.id = p.category_id
            LEFT JOIN price_list_items i ON i.product_id = p.id
            WHERE p.status = 1" . ($includeHidden ? '' : " AND COALESCE(i.hidden,0) = 0") . "
            ORDER BY (c.name IS NULL), c.name, p.name";
    $rows = $pdo->query($sql)->fetchAll();
    $groups = []; $latest = null;
    foreach ($rows as $r) {
        $base  = (float)$r['price'];
        $price = ($r['sale_price'] && (float)$r['sale_price'] > 0 && (float)$r['sale_price'] < $base) ? (float)$r['sale_price'] : $base;
        $upd = $r['item_upd'] && $r['item_upd'] > $r['upd'] ? $r['item_upd'] : $r['upd'];
        if ($upd && ($latest === null || $upd > $latest)) $latest = $upd;
        $it = [
            'id' => (int)$r['id'], 'name' => $r['name'], 'img' => $r['main_image'],
            'price' => $price, 'old_price' => $price < $base ? $base : 0,
            'code' => trim((string)$r['code']) !== '' ? trim($r['code']) : (string)$r['id'],
            'unit' => trim((string)$r['unit']),
            'tier1_qty' => (int)$r['tier1_qty'], 'tier1_price' => (float)$r['tier1_price'],
            'tier2_qty' => (int)$r['tier2_qty'], 'tier2_price' => (float)$r['tier2_price'],
            'in_stock' => $r['stock_status'] === 'in_stock' && (int)$r['stock'] > 0,
            'stock' => (int)$r['stock'],
            'inquiry' => !empty($r['inquiry']) || $price <= 0,
            'hidden' => !empty($r['hidden']),
            'upd' => $upd,
        ];
        $g = $r['cat_name'] !== null && $r['cat_name'] !== '' ? $r['cat_name'] : 'سایر کالاها';
        $groups[$g][] = $it;
    }
    $out = [];
    foreach ($groups as $name => $items) $out[] = ['name' => $name, 'items' => $items];
    return ['groups' => $out, 'count' => count($rows), 'updated' => $latest];
}

// ════════════════════════════════════════════════════════════
//  خروجی اکسل
// ════════════════════════════════════════════════════════════
function pricelist_rows_for_export(array $data) {
    $rows = [['دسته‌بندی', 'کد', 'نام کالا', 'واحد', 'قیمت (تومان)', 'پله ۱ — تعداد', 'پله ۱ — قیمت', 'پله ۲ — تعداد', 'پله ۲ — قیمت', 'موجودی', 'تاریخ به‌روزرسانی']];
    foreach ($data['groups'] as $g) foreach ($g['items'] as $it) {
        $rows[] = [
            $g['name'], $it['code'], $it['name'], $it['unit'],
            $it['inquiry'] ? 'استعلام' : (int)$it['price'],
            $it['tier1_qty'] ?: '', $it['tier1_price'] ? (int)$it['tier1_price'] : '',
            $it['tier2_qty'] ?: '', $it['tier2_price'] ? (int)$it['tier2_price'] : '',
            $it['in_stock'] ? 'موجود' : 'ناموجود',
            $it['upd'] ? jalali_str($it['upd'], false) : '',
        ];
    }
    return $rows;
}

function pricelist_col_letter($i) {
    $s = '';
    for ($n = $i + 1; $n > 0; $n = intdiv($n - 1, 26)) $s = chr(65 + ($n - 1) % 26) . $s;
    return $s;
}

/** نوشتن xlsx ساده (راست‌به‌چپ، سطر اول عنوان ثابت). خروجی: مسیر فایل موقت یا null اگر zip نبود */
function pricelist_write_xlsx(array $rows, $sheetTitle = 'لیست قیمت') {
    if (!class_exists('ZipArchive')) return null;
    $x = function ($s) { return htmlspecialchars((string)$s, ENT_XML1 | ENT_QUOTES, 'UTF-8'); };
    $sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<sheetViews><sheetView rightToLeft="1" workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
        . '<cols><col min="1" max="1" width="22" customWidth="1"/><col min="2" max="2" width="10" customWidth="1"/><col min="3" max="3" width="46" customWidth="1"/><col min="4" max="4" width="18" customWidth="1"/><col min="5" max="9" width="14" customWidth="1"/><col min="10" max="11" width="14" customWidth="1"/></cols>'
        . '<sheetData>';
    foreach ($rows as $ri => $row) {
        $sheet .= '<row r="' . ($ri + 1) . '">';
        foreach ($row as $ci => $v) {
            $ref = pricelist_col_letter($ci) . ($ri + 1);
            if ($v === '' || $v === null) continue;
            if (is_int($v) || is_float($v)) $sheet .= '<c r="' . $ref . '"><v>' . $v . '</v></c>';
            else $sheet .= '<c r="' . $ref . '" t="inlineStr"><is><t xml:space="preserve">' . $x($v) . '</t></is></c>';
        }
        $sheet .= '</row>';
    }
    $sheet .= '</sheetData></worksheet>';

    $tmp = tempnam(sys_get_temp_dir(), 'pl') ?: null;
    if (!$tmp) return null;
    $zip = new ZipArchive();
    if ($zip->open($tmp, ZipArchive::OVERWRITE) !== true) return null;
    $zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>');
    $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
    $zip->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="' . $x(mb_substr($sheetTitle, 0, 31)) . '" sheetId="1" r:id="rId1"/></sheets></workbook>');
    $zip->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>');
    $zip->addFromString('xl/worksheets/sheet1.xml', $sheet);
    $zip->close();
    return $tmp;
}

/** ارسال فایل اکسل (یا CSV در نبود zip) به مرورگر و پایان اجرا */
function pricelist_download(array $data) {
    $rows = pricelist_rows_for_export($data);
    $stamp = date('Y-m-d');
    $tmp = pricelist_write_xlsx($rows);
    if ($tmp && is_file($tmp)) {
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="price-list-' . $stamp . '.xlsx"');
        header('Content-Length: ' . filesize($tmp));
        readfile($tmp);
        @unlink($tmp);
        exit;
    }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="price-list-' . $stamp . '.csv"');
    echo "\xEF\xBB\xBF";
    foreach ($rows as $r) echo implode(',', array_map(function ($v) { return '"' . str_replace('"', '""', (string)$v) . '"'; }, $r)) . "\r\n";
    exit;
}
