<?php
/**
 * ورود گروهی مشتریان به CRM از فایل اکسل (.xlsx) یا CSV
 *  - خواندن بدون کتابخانه‌ی خارجی (xlsx با ZipArchive + SimpleXML؛ نیازمند افزونه‌ی zip که در XAMPP فعال است)
 *  - تشخیص خودکار ستون‌ها از روی عنوان (فارسی یا انگلیسی)، جداکننده و انکودینگ CSV (UTF-8 / Windows-1256)
 *  - شماره موبایل بدون صفر اول (اکسل صفر را می‌خورد) و ارقام فارسی درست نرمال می‌شوند
 *  - مشتری تکراری (موبایل یا ایمیل مشابه) یا نادیده گرفته می‌شود یا فقط فیلدهای خالی‌اش تکمیل می‌شود
 */
require_once __DIR__ . '/crm.php';

const CRM_IMPORT_MAX_ROWS  = 5000;
const CRM_IMPORT_MAX_BYTES = 5 * 1024 * 1024;

// ════════════════════════════════════════════════════════════
//  خواندن فایل → آرایه‌ی ردیف‌ها (هر ردیف = آرایه‌ی رشته‌ها)
//  خطا: Exception با پیام فارسی
// ════════════════════════════════════════════════════════════
function crm_import_read($path, $origName) {
    $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
    if ($ext === 'xlsx') return crm_import_read_xlsx($path);
    if ($ext === 'csv' || $ext === 'txt' || $ext === 'tsv') return crm_import_read_csv($path);
    if ($ext === 'xls') throw new Exception('فرمت قدیمی .xls پشتیبانی نمی‌شود؛ در اکسل «Save As» را بزنید و فرمت xlsx یا CSV UTF-8 را انتخاب کنید.');
    throw new Exception('فقط فایل‌های xlsx و csv پذیرفته می‌شوند.');
}

function crm_import_read_csv($path) {
    $raw = file_get_contents($path);
    if ($raw === false || trim($raw) === '') throw new Exception('فایل خالی است.');
    // انکودینگ
    if (substr($raw, 0, 3) === "\xEF\xBB\xBF") $raw = substr($raw, 3);
    elseif (substr($raw, 0, 2) === "\xFF\xFE") $raw = mb_convert_encoding(substr($raw, 2), 'UTF-8', 'UTF-16LE');
    elseif (substr($raw, 0, 2) === "\xFE\xFF") $raw = mb_convert_encoding(substr($raw, 2), 'UTF-8', 'UTF-16BE');
    elseif (!mb_check_encoding($raw, 'UTF-8')) {
        $raw = function_exists('iconv') ? (@iconv('Windows-1256', 'UTF-8//IGNORE', $raw) ?: $raw)
                                        : mb_convert_encoding($raw, 'UTF-8', 'Windows-1256');
    }
    // جداکننده: پرتکرارترین در چند خط اول
    $head = implode("\n", array_slice(preg_split('/\R/u', $raw), 0, 5));
    $best = ','; $max = -1;
    foreach ([',', ';', "\t", '|'] as $d) {
        $n = substr_count($head, $d);
        if ($n > $max) { $max = $n; $best = $d; }
    }
    $fh = fopen('php://temp', 'r+');
    fwrite($fh, $raw);
    rewind($fh);
    $rows = [];
    while (($r = fgetcsv($fh, 0, $best, '"', '')) !== false) {
        if ($r === [null]) continue;                       // خط خالی
        $rows[] = array_map(function ($v) { return trim((string)$v); }, $r);
        if (count($rows) > CRM_IMPORT_MAX_ROWS + 1) throw new Exception('حداکثر ' . CRM_IMPORT_MAX_ROWS . ' ردیف در هر بار ورود مجاز است؛ فایل را به چند بخش تقسیم کنید.');
    }
    fclose($fh);
    return $rows;
}

function crm_import_col_index($ref) {            // "AB12" → 27
    $letters = preg_replace('/[^A-Z]/', '', strtoupper($ref));
    $n = 0;
    for ($i = 0; $i < strlen($letters); $i++) $n = $n * 26 + (ord($letters[$i]) - 64);
    return max(0, $n - 1);
}

function crm_import_read_xlsx($path) {
    if (!class_exists('ZipArchive')) throw new Exception('افزونه‌ی zip در PHP فعال نیست (در php.ini خط extension=zip را فعال کنید) — یا فایل را به‌صورت CSV ذخیره کنید.');
    $zip = new ZipArchive();
    if ($zip->open($path) !== true) throw new Exception('فایل xlsx معتبر نیست یا آسیب دیده است.');
    $read = function ($name) use ($zip) { $s = $zip->getFromName($name); return $s === false ? null : $s; };

    // رشته‌های مشترک
    $shared = [];
    if (($xml = $read('xl/sharedStrings.xml')) !== null) {
        $sx = @simplexml_load_string($xml);
        if ($sx) foreach ($sx->si as $si) {
            if (isset($si->t)) { $shared[] = (string)$si->t; continue; }
            $t = ''; foreach ($si->r as $r) $t .= (string)$r->t;   // متن چندتکه (rich text)
            $shared[] = $t;
        }
    }
    // اولین شیت
    $sheetPath = 'xl/worksheets/sheet1.xml';
    if (($wb = $read('xl/workbook.xml')) !== null && ($rels = $read('xl/_rels/workbook.xml.rels')) !== null) {
        $w = @simplexml_load_string($wb); $r = @simplexml_load_string($rels);
        if ($w && $r && isset($w->sheets->sheet[0])) {
            $rid = (string)$w->sheets->sheet[0]->attributes('http://schemas.openxmlformats.org/officeDocument/2006/relationships')->id;
            foreach ($r->Relationship as $rel) {
                if ((string)$rel['Id'] === $rid) {
                    $t = ltrim((string)$rel['Target'], '/');
                    $sheetPath = strpos($t, 'xl/') === 0 ? $t : 'xl/' . $t;
                    break;
                }
            }
        }
    }
    $sheetXml = $read($sheetPath);
    $zip->close();
    if ($sheetXml === null) throw new Exception('شیت اول فایل xlsx پیدا نشد.');
    $sx = @simplexml_load_string($sheetXml);
    if (!$sx) throw new Exception('خواندن شیت xlsx ناموفق بود.');

    $rows = [];
    foreach ($sx->sheetData->row as $row) {
        $cells = []; $maxCol = -1;
        foreach ($row->c as $c) {
            $idx = isset($c['r']) ? crm_import_col_index((string)$c['r']) : ($maxCol + 1);
            $type = (string)$c['t'];
            if ($type === 's')           $val = $shared[(int)$c->v] ?? '';
            elseif ($type === 'inlineStr') { $val = isset($c->is->t) ? (string)$c->is->t : ''; if ($val === '' && isset($c->is->r)) foreach ($c->is->r as $rr) $val .= (string)$rr->t; }
            elseif ($type === 'b')       $val = (string)$c->v === '1' ? '1' : '0';
            else {
                $val = (string)$c->v;
                if ($val !== '' && preg_match('/^-?\d+(\.\d+)?[eE][+\-]?\d+$/', $val)) $val = sprintf('%.0f', (float)$val);  // 9.15E+9
                elseif ($val !== '' && preg_match('/^\d+\.0+$/', $val)) $val = preg_replace('/\.0+$/', '', $val);
            }
            $cells[$idx] = trim($val);
            $maxCol = max($maxCol, $idx);
        }
        if ($maxCol < 0) continue;
        $line = [];
        for ($i = 0; $i <= $maxCol; $i++) $line[] = $cells[$i] ?? '';
        if (implode('', $line) === '') continue;
        $rows[] = $line;
        if (count($rows) > CRM_IMPORT_MAX_ROWS + 1) throw new Exception('حداکثر ' . CRM_IMPORT_MAX_ROWS . ' ردیف در هر بار ورود مجاز است؛ فایل را به چند بخش تقسیم کنید.');
    }
    return $rows;
}

// ════════════════════════════════════════════════════════════
//  نگاشت ستون‌ها
// ════════════════════════════════════════════════════════════
function crm_import_norm_head($s) {
    $s = mb_strtolower(trim((string)$s));
    $s = strtr($s, ['ي' => 'ی', 'ك' => 'ک', 'ة' => 'ه', 'أ' => 'ا', 'إ' => 'ا', 'آ' => 'ا']);
    return preg_replace('/[\s\x{200C}\x{200B}\x{200F}\x{200E}_\-\.:\/()*]+/u', '', $s);
}
function crm_import_fields() {
    // کلید فیلد => عنوان‌های قابل قبول (نرمال‌شده با crm_import_norm_head)
    return [
        'name'      => ['نام', 'نامونامخانوادگی', 'نامنامخانوادگی', 'نامکامل', 'مشتری', 'ناممشتری', 'name', 'fullname', 'customer', 'customername', 'contact'],
        'lastname'  => ['نامخانوادگی', 'فامیل', 'فامیلی', 'lastname', 'surname', 'family'],
        'phone'     => ['موبایل', 'شمارهموبایل', 'تلفنهمراه', 'همراه', 'شماره', 'تلفن', 'شمارهتماس', 'تماس', 'phone', 'mobile', 'tel', 'cell', 'phonenumber'],
        'email'     => ['ایمیل', 'پستالکترونیک', 'پستالکترونیکی', 'email', 'mail', 'emailaddress'],
        'city'      => ['شهر', 'شهرستان', 'city'],
        'stage'     => ['مرحله', 'وضعیت', 'stage', 'status'],
        'tags'      => ['برچسب', 'برچسبها', 'تگ', 'تگها', 'tags', 'tag', 'label', 'labels', 'گروه'],
        'notes'     => ['یادداشت', 'یادداشتها', 'توضیحات', 'توضیح', 'notes', 'note', 'description', 'comment', 'comments'],
        'followup'  => ['پیگیری', 'پیگیریبعدی', 'تاریخپیگیری', 'followup', 'nextfollowup'],
    ];
}
/** [نگاشت فیلد => شماره ستون, آیا ردیف اول عنوان بود؟] */
function crm_import_map(array $firstRow) {
    $fields = crm_import_fields();
    $map = []; $hits = 0;
    foreach ($firstRow as $i => $h) {
        $n = crm_import_norm_head($h);
        if ($n === '') continue;
        foreach ($fields as $key => $aliases) {
            if (isset($map[$key])) continue;
            if (in_array($n, $aliases, true)) { $map[$key] = $i; $hits++; break; }
        }
    }
    if ($hits > 0) return [$map, true];
    // بدون عنوان: ترتیب پیش‌فرض نام، موبایل، ایمیل، شهر، مرحله، برچسب، یادداشت
    $order = ['name', 'phone', 'email', 'city', 'stage', 'tags', 'notes'];
    $map = [];
    foreach ($order as $i => $k) if ($i < count($firstRow)) $map[$k] = $i;
    return [$map, false];
}
function crm_import_stage($v) {
    $n = crm_import_norm_head($v);
    if ($n === '') return null;
    $m = [
        'lead' => 'lead', 'سرنخ' => 'lead', 'جدید' => 'lead', 'new' => 'lead',
        'prospect' => 'prospect', 'درحالمذاکره' => 'prospect', 'مذاکره' => 'prospect', 'پیگیری' => 'prospect',
        'customer' => 'customer', 'مشتری' => 'customer', 'خریدار' => 'customer',
        'vip' => 'vip', 'مشتریویژه' => 'vip', 'ویژه' => 'vip',
        'inactive' => 'inactive', 'غیرفعال' => 'inactive', 'نامشتری' => 'inactive',
    ];
    return $m[$n] ?? null;
}

// ════════════════════════════════════════════════════════════
//  ورود
//  $mode: 'skip' = مشتری تکراری نادیده گرفته شود | 'update' = فقط فیلدهای خالی مشتری موجود تکمیل شود
//  خروجی: ['total','added','updated','skipped','invalid','errors'=>[...],'header'=>bool]
// ════════════════════════════════════════════════════════════
function crm_import_run(PDO $pdo, array $rows, $mode = 'skip') {
    crm_ensure($pdo);
    $rep = ['total' => 0, 'added' => 0, 'updated' => 0, 'skipped' => 0, 'invalid' => 0, 'errors' => [], 'header' => false];
    if (!$rows) return $rep;

    [$map, $hasHeader] = crm_import_map($rows[0]);
    $rep['header'] = $hasHeader;
    if (!isset($map['name']) && !isset($map['phone']) && !isset($map['email'])) {
        throw new Exception('ستون «نام»، «موبایل» یا «ایمیل» پیدا نشد. ردیف اول فایل باید عنوان ستون‌ها باشد (فایل نمونه را دانلود کنید).');
    }
    $data = $hasHeader ? array_slice($rows, 1) : $rows;
    $startLine = $hasHeader ? 2 : 1;

    $get = function ($r, $k) use ($map) { return isset($map[$k]) ? trim((string)($r[$map[$k]] ?? '')) : ''; };

    // مشتری‌های موجود
    $byPhone = []; $byEmail = [];
    foreach ($pdo->query("SELECT id, phone, email FROM crm_contacts")->fetchAll() as $c) {
        if ($p = crm_norm_phone($c['phone'])) $byPhone[$p] = (int)$c['id'];
        if ($e = crm_norm_email($c['email'])) $byEmail[$e] = (int)$c['id'];
    }
    $now = crm_now();
    $ins = $pdo->prepare("INSERT INTO crm_contacts (name, phone, email, city, stage, source, tags, notes, next_followup, created_at, updated_at)
                          VALUES (?,?,?,?,?,'import',?,?,?,?,?)");
    $sel = $pdo->prepare("SELECT * FROM crm_contacts WHERE id=?");
    $addErr = function ($line, $msg) use (&$rep) { $rep['invalid']++; if (count($rep['errors']) < 25) $rep['errors'][] = 'ردیف ' . $line . ': ' . $msg; };

    $pdo->beginTransaction();
    try {
        foreach ($data as $i => $r) {
            $line = $startLine + $i;
            if (implode('', $r) === '') continue;
            if (++$rep['total'] > CRM_IMPORT_MAX_ROWS) break;

            $name  = $get($r, 'name');
            $last  = $get($r, 'lastname');
            if ($last !== '') $name = trim($name . ' ' . $last);
            $phone = crm_norm_phone($get($r, 'phone'));
            $email = crm_norm_email($get($r, 'email'));
            $rawPhone = $get($r, 'phone'); $rawEmail = $get($r, 'email');

            if ($phone === '' && $email === '') {
                $addErr($line, ($rawPhone !== '' || $rawEmail !== '') ? 'موبایل/ایمیل نامعتبر است' : 'موبایل و ایمیل خالی است');
                continue;
            }
            if ($phone !== '' && !preg_match('/^0?\d{8,13}$/', $phone)) { $addErr($line, 'شماره «' . mb_substr($rawPhone, 0, 20) . '» معتبر نیست'); continue; }
            if ($rawEmail !== '' && $email === '' && $phone === '') { $addErr($line, 'ایمیل «' . mb_substr($rawEmail, 0, 30) . '» معتبر نیست'); continue; }
            if ($name === '') $name = $phone ?: $email;

            $city  = mb_substr($get($r, 'city'), 0, 80);
            $stage = crm_import_stage($get($r, 'stage')) ?: 'lead';
            $tags  = crm_clean_tags($get($r, 'tags'));
            $notes = mb_substr($get($r, 'notes'), 0, 5000);
            $fuRaw = $get($r, 'followup');
            $fu    = $fuRaw !== '' ? jalali_to_date($fuRaw) : null;

            $existing = ($phone !== '' && isset($byPhone[$phone])) ? $byPhone[$phone] : (($email !== '' && isset($byEmail[$email])) ? $byEmail[$email] : 0);
            if ($existing) {
                if ($mode !== 'update') { $rep['skipped']++; continue; }
                $sel->execute([$existing]);
                $c = $sel->fetch();
                if (!$c) { $rep['skipped']++; continue; }
                $set = []; $par = [];
                foreach (['city' => $city, 'tags' => $tags, 'notes' => $notes] as $col => $v) {
                    if ($v !== '' && trim((string)$c[$col]) === '') { $set[] = "$col=?"; $par[] = $v; }
                }
                if ($email !== '' && trim((string)$c['email']) === '' && !isset($byEmail[$email])) { $set[] = 'email=?'; $par[] = $email; $byEmail[$email] = $existing; }
                if ($phone !== '' && trim((string)$c['phone']) === '' && !isset($byPhone[$phone])) { $set[] = 'phone=?'; $par[] = $phone; $byPhone[$phone] = $existing; }
                if ($fu && empty($c['next_followup'])) { $set[] = 'next_followup=?'; $par[] = $fu; }
                if ($set) {
                    $set[] = 'updated_at=?'; $par[] = $now; $par[] = $existing;
                    $pdo->prepare('UPDATE crm_contacts SET ' . implode(', ', $set) . ' WHERE id=?')->execute($par);
                    $rep['updated']++;
                } else $rep['skipped']++;
                continue;
            }

            $ins->execute([mb_substr($name, 0, 150), $phone ?: null, $email ?: null, $city ?: null, $stage, $tags ?: null, $notes ?: null, $fu, $now, $now]);
            $id = (int)$pdo->lastInsertId();
            if ($phone) $byPhone[$phone] = $id;
            if ($email) $byEmail[$email] = $id;
            $rep['added']++;
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
    return $rep;
}

/** فایل نمونه‌ی CSV (UTF-8 با BOM تا اکسل فارسی را درست نشان دهد) */
function crm_import_template_csv() {
    $rows = [
        ['نام و نام خانوادگی', 'موبایل', 'ایمیل', 'شهر', 'مرحله', 'برچسب‌ها', 'یادداشت'],
        ['علی محمدی', '09123456789', 'ali@example.com', 'مشهد', 'مشتری', 'عمده‌فروش، آیفون', 'خرید عمده هر ماه'],
        ['زهرا کریمی', '09351234567', '', 'تهران', 'سرنخ', '', 'از طریق اینستاگرام آمده'],
    ];
    $out = "\xEF\xBB\xBF";
    foreach ($rows as $r) {
        $out .= implode(',', array_map(function ($v) { return '"' . str_replace('"', '""', $v) . '"'; }, $r)) . "\r\n";
    }
    return $out;
}
