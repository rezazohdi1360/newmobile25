<?php
/**
 * چندزبانه‌سازی سایت عمومی: فارسی (پیش‌فرض، در ریشه) + انگلیسی (/en/) + عربی (/ar/)
 *
 *  - زبان از پیشوند آدرس تشخیص داده می‌شود (مثل abedherb.com): /en/product.php?id=1
 *    قاعده‌ی بازنویسی در .htaccess است؛ لینک‌های نسبی سایت خودبه‌خود پیشوند را حفظ می‌کنند.
 *  - ترجمه‌ی رابط: خروجی صفحه قبل از ارسال، با دیکشنری (lang/en.php, lang/ar.php) و ترجمه‌های
 *    ثبت‌شده در جدول i18n_texts (نام محصول/دسته و ...) برگردانده می‌شود. متنِ بدون ترجمه فارسی می‌ماند.
 *  - هدر html (lang/dir)، تبدیل ارقام، hreflang و منوی انتخاب زبان (پرچم + FA/EN/AR) اضافه می‌شود.
 *  - پنل مدیریت و فایل‌های غیر HTML دست نمی‌خورند.
 */

function i18n_langs() {
    return [
        'fa' => ['code' => 'FA', 'name' => 'فارسی',   'dir' => 'rtl', 'hreflang' => 'fa-IR', 'locale' => 'fa-IR'],
        'en' => ['code' => 'EN', 'name' => 'English', 'dir' => 'ltr', 'hreflang' => 'en',    'locale' => 'en-US'],
        'ar' => ['code' => 'AR', 'name' => 'العربية', 'dir' => 'rtl', 'hreflang' => 'ar',    'locale' => 'ar-EG'],
    ];
}

/** مسیر پایه‌ی برنامه (مثلاً /mobile-store یا خالی) */
function i18n_base() {
    $b = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
    return rtrim($b === '.' ? '' : $b, '/');
}

/** [زبان, باقی‌مانده‌ی آدرس بعد از پیشوند (با / اول)] از روی REQUEST_URI */
function i18n_parse_uri() {
    $uri  = $_SERVER['REQUEST_URI'] ?? '/';
    $path = (string)parse_url($uri, PHP_URL_PATH);
    $qs   = isset($_SERVER['QUERY_STRING']) && $_SERVER['QUERY_STRING'] !== '' ? '?' . $_SERVER['QUERY_STRING'] : '';
    $base = i18n_base();
    $rest = ($base !== '' && strpos($path, $base) === 0) ? substr($path, strlen($base)) : $path;
    if ($rest === '' || $rest[0] !== '/') $rest = '/' . $rest;
    if (preg_match('#^/(en|ar)(/.*)?$#', $rest, $m)) return [$m[1], ($m[2] ?? '/') . $qs];
    return ['fa', $rest . $qs];
}

/** آدرس همین صفحه در زبان دیگر (مسیر نسبت به دامنه) */
function i18n_url($lang) {
    [, $rest] = i18n_parse_uri();
    return i18n_base() . ($lang === 'fa' ? '' : '/' . $lang) . $rest;
}

function i18n_origin() {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    return ($https ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost');
}

// ═══════════════════════════════ ذخیره‌ی ترجمه‌ها ═══════════════════════════════
function i18n_ensure(PDO $pdo) {
    static $done = false;
    if ($done) return;
    $done = true;
    if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) !== 'mysql') return;
    $pdo->exec("CREATE TABLE IF NOT EXISTS i18n_texts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        lang VARCHAR(5) NOT NULL,
        src_hash CHAR(32) NOT NULL,
        src TEXT NOT NULL,
        dst TEXT NOT NULL,
        is_term TINYINT NOT NULL DEFAULT 0,
        auto_made TINYINT NOT NULL DEFAULT 0,
        updated_at DATETIME NULL,
        UNIQUE KEY uq_lang_src (lang, src_hash)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");
}

function i18n_norm($s) {
    $s = str_replace(['ي', 'ك', "\xC2\xA0", '&zwnj;', '&#8204;'], ['ی', 'ک', ' ', "\u{200C}", "\u{200C}"], (string)$s);
    return trim(preg_replace('/\s+/u', ' ', $s));
}

/** دیکشنری یک زبان: ['static' => [fa=>tr], 'exact' => [fa=>tr], 'terms' => [fa=>tr]] (نتیجه کش می‌شود) */
function i18n_dict($lang, $pdo = null) {
    static $cache = [];
    if (isset($cache[$lang])) return $cache[$lang];
    $f = __DIR__ . '/../lang/' . $lang . '.php';
    $static = is_file($f) ? (array)(require $f) : [];
    $exact = []; $terms = [];
    foreach ($static as $k => $v) $exact[i18n_norm($k)] = $v;
    if ($pdo instanceof PDO) {
        try {
            i18n_ensure($pdo);
            $st = $pdo->prepare("SELECT src, dst, is_term FROM i18n_texts WHERE lang = ? AND dst <> ''");
            $st->execute([$lang]);
            foreach ($st->fetchAll() as $r) {
                $k = i18n_norm($r['src']);
                $exact[$k] = $r['dst'];
                if (!empty($r['is_term'])) $terms[$k] = $r['dst'];
            }
        } catch (Throwable $e) {}
    }
    return $cache[$lang] = ['static' => $static, 'exact' => $exact, 'terms' => $terms];
}

/** عبارت‌های جایگزین‌شونده (مرتب از بلند به کوتاه) در تکه‌های ۱۲۰تایی regex */
function i18n_chunks($lang) {
    static $cache = [];
    if (isset($cache[$lang])) return $cache[$lang];
    $d = $GLOBALS['I18N_PDO'] ?? null;
    $dict = i18n_dict($lang, $d);
    $phr = [];
    foreach ($dict['static'] as $k => $v) $phr[i18n_norm($k)] = $v;
    foreach ($dict['terms'] as $k => $v) $phr[$k] = $v;
    uksort($phr, function ($a, $b) { return mb_strlen($b) <=> mb_strlen($a); });
    $chunks = [];
    foreach (array_chunk(array_keys($phr), 120) as $keys) {
        $alts = [];
        foreach ($keys as $k) {
            if ($k === '') continue;
            // فاصله‌ی داخل عبارت: هر نوع فاصله/نیم‌فاصله‌ی چسبیده پذیرفته شود
            $alts[] = preg_replace('/\\\\ /', '\s+', preg_quote($k, '/'));
        }
        $chunks[] = '/(?<![\x{0620}-\x{064A}\x{0660}-\x{0669}\x{0671}-\x{06D3}\x{06F0}-\x{06F9}\x{200C}])(?:' . implode('|', $alts) . ')(?![\x{0620}-\x{064A}\x{0660}-\x{0669}\x{0671}-\x{06D3}\x{06F0}-\x{06F9}\x{200C}])/u';
    }
    return $cache[$lang] = ['phr' => $phr, 'rx' => $chunks];
}

function i18n_patterns($lang) {
    static $c = null;
    if ($c === null) { $f = __DIR__ . '/../lang/patterns.php'; $c = is_file($f) ? (array)(require $f) : []; }
    return $c[$lang] ?? [];
}

function i18n_digits($s, $lang) {
    if ($lang === 'en') {
        return strtr($s, [
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
            '٬'=>',','٫'=>'.','٪'=>'%','،'=>',','؟'=>'?','؛'=>';',
        ]);
    }
    $s = strtr($s, ['٪'=>'٪']);
    return strtr($s, ['۰'=>'٠','۱'=>'١','۲'=>'٢','۳'=>'٣','۴'=>'٤','۵'=>'٥','۶'=>'٦','۷'=>'٧','۸'=>'٨','۹'=>'٩']);
}

/** ترجمه‌ی یک متن (گره‌ی متنی/مقدار صفت). $digits=false برای اسکریپت */
function i18n_tr($s, $lang, $digits = true) {
    if ($s === '' || !preg_match('/[\x{0600}-\x{06FF}]/u', $s)) return $s;
    static $memo = [];
    $mk = $lang . ($digits ? '1' : '0') . $s;
    if (isset($memo[$mk])) return $memo[$mk];
    $lead = ''; $trail = '';
    if (preg_match('/^(\s*)(.*?)(\s*)$/su', $s, $m)) { $lead = $m[1]; $core = $m[2]; $trail = $m[3]; } else { $core = $s; }
    $core = str_replace(['&zwnj;', '&#8204;'], "\u{200C}", $core);
    $dict = i18n_dict($lang, $GLOBALS['I18N_PDO'] ?? null);
    $key = i18n_norm($core);
    if (isset($dict['exact'][$key])) {
        $out = $dict['exact'][$key];
    } else {
        $ch = i18n_chunks($lang);
        $out = $core;
        foreach (i18n_patterns($lang) as $pt) $out = preg_replace($pt[0], $pt[1], $out);
        foreach ($ch['rx'] as $rx) {
            $out = preg_replace_callback($rx, function ($m) use ($ch) {
                $k = i18n_norm($m[0]);
                return $ch['phr'][$k] ?? $m[0];
            }, $out);
        }
    }
    if ($digits) $out = i18n_digits($out, $lang);
    return $memo[$mk] = $lead . $out . $trail;
}

// ═══════════════════════════════ پردازش خروجی ═══════════════════════════════
const I18N_ATTRS = 'placeholder|title|alt|aria-label|value|content|data-title|data-label|data-text|data-msg|data-confirm|onclick|onsubmit|label';

function i18n_tag($tag, $lang) {
    if (!preg_match('/[\x{0600}-\x{06FF}]/u', $tag)) return $tag;
    return preg_replace_callback('/\b(' . I18N_ATTRS . ')=(["\'])(.*?)\2/su', function ($m) use ($lang) {
        if ($m[1] === 'content' && false) return $m[0];
        $isJs = in_array($m[1], ['onclick', 'onsubmit'], true);
        return $m[1] . '=' . $m[2] . i18n_tr($m[3], $lang, !$isJs) . $m[2];
    }, $tag);
}

function i18n_translate_html($html, $lang) {
    $parts = preg_split('/(<script\b.*?<\/script>|<style\b.*?<\/style>|<!--.*?-->|<[^>]+>)/is', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
    $locale = i18n_langs()[$lang]['locale'];
    foreach ($parts as $i => $p) {
        if ($p === '') continue;
        if ($p[0] === '<') {
            if (strncasecmp($p, '<script', 7) === 0) {
                $parts[$i] = str_replace(['fa-IR', "'fa'"], [$locale, "'" . $lang . "'"], i18n_tr($p, $lang, false));
            } elseif (strncasecmp($p, '<style', 6) === 0 || strncmp($p, '<!--', 4) === 0) {
                continue;
            } else {
                $parts[$i] = i18n_tag($p, $lang);
            }
        } else {
            $parts[$i] = i18n_tr($p, $lang, true);
        }
    }
    return implode('', $parts);
}

function i18n_json_walk($v, $lang) {
    if (is_string($v)) return i18n_tr($v, $lang, true);
    if (is_array($v)) { foreach ($v as $k => $x) $v[$k] = i18n_json_walk($x, $lang); }
    return $v;
}

function i18n_flag($lang) {
    // پرچم ساده‌ی SVG (ایران / بریتانیا-آمریکا ساده‌شده / عربی=سبز)
    if ($lang === 'fa') return '<svg viewBox="0 0 24 16" width="22" height="15" aria-hidden="true"><rect width="24" height="16" rx="2" fill="#fff"/><rect width="24" height="5.3" rx="2" fill="#239f40"/><rect y="10.7" width="24" height="5.3" rx="2" fill="#da0000"/><circle cx="12" cy="8" r="2" fill="none" stroke="#da0000" stroke-width="1"/></svg>';
    if ($lang === 'en') return '<svg viewBox="0 0 24 16" width="22" height="15" aria-hidden="true"><rect width="24" height="16" rx="2" fill="#1e3a8a"/><path d="M0 0l24 16M24 0L0 16" stroke="#fff" stroke-width="3"/><path d="M0 0l24 16M24 0L0 16" stroke="#dc2626" stroke-width="1.2"/><path d="M12 0v16M0 8h24" stroke="#fff" stroke-width="5"/><path d="M12 0v16M0 8h24" stroke="#dc2626" stroke-width="3"/></svg>';
    return '<svg viewBox="0 0 24 16" width="22" height="15" aria-hidden="true"><rect width="24" height="16" rx="2" fill="#0f7a3d"/><path d="M5 9.5h14" stroke="#fff" stroke-width="1.6" stroke-linecap="round"/><path d="M8 6.5c1.5-2 6.5-2 8 0" stroke="#fff" stroke-width="1.4" fill="none" stroke-linecap="round"/></svg>';
}

function i18n_switcher_css() {
    return '<style id="i18n-sw-css">'
        . '.i18n-sw{position:relative;display:inline-block;font-family:inherit}'
        . '.i18n-sw>button{display:inline-flex;align-items:center;gap:7px;background:var(--paper,#fff);color:var(--ink,#0f172a);border:1px solid var(--line,#e2e8f0);border-radius:12px;padding:9px 12px;font:inherit;font-size:13px;font-weight:800;cursor:pointer;line-height:1}'
        . '.i18n-sw>button:hover{border-color:var(--gold,#f97316)}'
        . '.i18n-sw>button svg{border-radius:2px;box-shadow:0 0 0 1px rgba(0,0,0,.12)}'
        . '.i18n-sw>button:after{content:"";border:4px solid transparent;border-top-color:currentColor;margin-top:4px}'
        . '.i18n-sw ul{display:none;position:absolute;top:calc(100% + 6px);inset-inline-end:0;min-width:150px;list-style:none;margin:0;padding:6px;background:var(--paper,#fff);border:1px solid var(--line,#e2e8f0);border-radius:12px;box-shadow:0 18px 36px -12px rgba(15,23,42,.35);z-index:99999}'
        . '.i18n-sw.open ul{display:block}'
        . '.i18n-sw li a{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;color:var(--ink,#0f172a);text-decoration:none;font-size:13px;font-weight:600;white-space:nowrap}'
        . '.i18n-sw li a:hover,.i18n-sw li a.on{background:var(--gold-pale,#fff1e6);color:var(--gold,#f97316)}'
        . '.i18n-float{position:fixed;bottom:16px;inset-inline-end:16px;z-index:99998}'
        . '.i18n-float ul{top:auto;bottom:calc(100% + 6px)}'
        . '</style>';
}

/** HTML منوی زبان (کشوی کرکره‌ای با پرچم + کد، مثل abedherb). $float=true برای صفحات بدون هدر */
function i18n_switcher_html($float = false) {
    $cur = defined('I18N_LANG') ? I18N_LANG : 'fa';
    $L = i18n_langs();
    $h = '<div class="i18n-sw' . ($float ? ' i18n-float' : '') . '" data-i18n-sw>'
       . '<button type="button" aria-haspopup="true" aria-label="' . htmlspecialchars($L[$cur]['name']) . '">' . i18n_flag($cur) . '<span>' . $L[$cur]['code'] . '</span></button><ul role="menu">';
    foreach ($L as $k => $v) {
        $h .= '<li><a role="menuitem" hreflang="' . $v['hreflang'] . '" lang="' . $k . '" class="' . ($k === $cur ? 'on' : '') . '" href="' . htmlspecialchars(i18n_url($k)) . '">' . i18n_flag($k) . '<span>' . $v['name'] . '</span></a></li>';
    }
    return $h . '</ul></div>'
       . '<script>(function(){var s=document.currentScript.previousElementSibling;if(!s||s.__i)return;s.__i=1;var b=s.querySelector("button");b.addEventListener("click",function(e){e.stopPropagation();s.classList.toggle("open")});document.addEventListener("click",function(){s.classList.remove("open")})})();</script>';
}

function i18n_ltr_css() {
    return '<style id="i18n-ltr">'
        . 'html[dir=ltr] body{direction:ltr;text-align:left}'
        . 'html[dir=ltr] .sh2-menu{right:auto;left:0}'
        . 'html[dir=ltr] .sh2-badge{right:auto;left:-8px}'
        . 'html[dir=ltr] input,html[dir=ltr] textarea,html[dir=ltr] select{text-align:left}'
        . 'html[dir=ltr] .product-title-en{text-align:left}'
        . '</style>';
}

function i18n_finish($html, $lang) {
    // جدا از زبان: فقط برای صفحه‌های کامل HTML
    $isFull = (bool)preg_match('/<html[\s>]/i', $html);
    $L = i18n_langs();

    if ($lang !== 'fa') $html = i18n_translate_html($html, $lang);
    if (!$isFull) return $html;

    // lang / dir
    $html = preg_replace_callback('/<html\b([^>]*)>/i', function ($m) use ($lang, $L) {
        $a = preg_replace('/\s(lang|dir)=(["\']).*?\2/i', '', $m[1]);
        return '<html lang="' . $lang . '" dir="' . $L[$lang]['dir'] . '"' . $a . '>';
    }, $html, 1);

    $head = '';
    $o = i18n_origin();
    foreach ($L as $k => $v) $head .= '<link rel="alternate" hreflang="' . $v['hreflang'] . '" href="' . htmlspecialchars($o . i18n_url($k)) . '">';
    $head .= '<link rel="alternate" hreflang="x-default" href="' . htmlspecialchars($o . i18n_url('fa')) . '">';
    $head .= i18n_switcher_css();
    if ($L[$lang]['dir'] === 'ltr') $head .= i18n_ltr_css();
    if (stripos($html, '</head>') !== false) $html = preg_replace('/<\/head>/i', str_replace('\\', '\\\\', $head) . '</head>', $html, 1);

    // اگر صفحه هدر مشترک (با منوی زبان) نداشت، منوی شناور اضافه شود
    if (strpos($html, 'data-i18n-sw') === false && preg_match('/<body\b[^>]*>/i', $html)) {
        $sw = i18n_switcher_html(true);
        $html = preg_replace('/<\/body>/i', str_replace('\\', '\\\\', $sw) . '</body>', $html, 1);
    }
    return $html;
}

function i18n_output_callback($buf) {
    $lang = defined('I18N_LANG') ? I18N_LANG : 'fa';
    if ($buf === '' || $buf === false) return $buf;
    $ct = '';
    foreach (headers_list() as $h) if (stripos($h, 'content-type:') === 0) $ct = strtolower($h);
    if ($ct !== '' && strpos($ct, 'text/html') === false) {
        if ($lang !== 'fa' && strpos($ct, 'json') !== false) {
            $j = json_decode($buf, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($j)) return json_encode(i18n_json_walk($j, $lang), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
        return $buf;
    }
    if (strlen($buf) > 0 && ($buf[0] === '{' || $buf[0] === '[') && $lang !== 'fa') {
        $j = json_decode($buf, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($j)) return json_encode(i18n_json_walk($j, $lang), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    if (substr($buf, 0, 4) === '%PDF' || substr($buf, 0, 2) === 'PK') return $buf;
    return i18n_finish($buf, $lang);
}

/** راه‌اندازی (از config/database.php بعد از theme_boot) */
function i18n_boot(PDO $pdo) {
    if (PHP_SAPI === 'cli' || defined('I18N_LANG')) return;
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $name = basename($script);
    if (strpos($script, '/admin/') !== false
        || preg_match('/^(cron_|setup_|debug|diagnose|test_|check|create_user|import|download\.php|invoice\.php|payment\.php|logout\.php)/', $name)) {
        define('I18N_LANG', 'fa');
        return;
    }
    [$lang, ] = i18n_parse_uri();
    // /en بدون اسلش پایانی → ریدایرکت (لینک‌های نسبی نیاز به اسلش دارند)
    $path = (string)parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    if ($lang !== 'fa' && preg_match('#/(en|ar)$#', $path) && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
        header('Location: ' . $path . '/' . (!empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : ''), true, 301);
        exit;
    }
    define('I18N_LANG', $lang);
    $GLOBALS['I18N_PDO'] = $pdo;
    ob_start('i18n_output_callback');
}
