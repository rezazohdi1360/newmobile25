<?php
/**
 * Google reCAPTCHA v2 («من ربات نیستم»)
 * کلیدها از پنل CRM (بخش «تنظیمات reCAPTCHA») در جدول site_settings ذخیره می‌شوند.
 * تا وقتی هر دو کلید وارد و فعال‌سازی نشده باشد، بررسی انجام نمی‌شود (سایت بدون خطا کار می‌کند).
 */
require_once __DIR__ . '/../config/site.php';

function recaptcha_conf(PDO $pdo) {
    return [
        'enabled' => site_get($pdo, 'recaptcha_enabled', '0') === '1',
        'site'    => trim((string)site_get($pdo, 'recaptcha_site_key', '')),
        'secret'  => trim((string)site_get($pdo, 'recaptcha_secret_key', '')),
    ];
}
function recaptcha_enabled(PDO $pdo) {
    $c = recaptcha_conf($pdo);
    return $c['enabled'] && $c['site'] !== '' && $c['secret'] !== '';
}
/** HTML ویجت؛ اگر غیرفعال باشد رشته‌ی خالی برمی‌گرداند */
function recaptcha_widget(PDO $pdo) {
    if (!recaptcha_enabled($pdo)) return '';
    $c = recaptcha_conf($pdo);
    return '<script src="https://www.google.com/recaptcha/api.js" async defer></script>'
         . '<div class="g-recaptcha" data-sitekey="' . htmlspecialchars($c['site'], ENT_QUOTES, 'UTF-8') . '"></div>';
}
/** بررسی پاسخ کاربر. خروجی: [true, ''] یا [false, 'پیام خطا'] */
function recaptcha_verify(PDO $pdo) {
    if (!recaptcha_enabled($pdo)) return [true, ''];
    $resp = (string)($_POST['g-recaptcha-response'] ?? '');
    if ($resp === '') return [false, 'لطفاً تیک «من ربات نیستم» را بزنید.'];
    if (!function_exists('curl_init')) return [false, 'افزونه cURL در PHP فعال نیست (در php.ini خط extension=curl را فعال کنید).'];
    $c  = recaptcha_conf($pdo);
    $ch = curl_init('https://www.google.com/recaptcha/api/siteverify');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => http_build_query(['secret' => $c['secret'], 'response' => $resp, 'remoteip' => $_SERVER['REMOTE_ADDR'] ?? '']),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
    ]);
    $ca = __DIR__ . '/../config/cacert.pem';
    if (is_file($ca)) curl_setopt($ch, CURLOPT_CAINFO, $ca);
    $out = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if ($out === false) return [false, 'ارتباط با سرور reCAPTCHA برقرار نشد: ' . $err];
    $j = json_decode($out, true);
    if (!empty($j['success'])) return [true, ''];
    $codes = implode(', ', (array)($j['error-codes'] ?? []));
    if (strpos($codes, 'invalid-input-secret') !== false || strpos($codes, 'missing-input-secret') !== false)
        return [false, 'کلید مخفی (Secret Key) reCAPTCHA نادرست است.'];
    return [false, 'تأیید reCAPTCHA ناموفق بود؛ دوباره تلاش کنید.'];
}
