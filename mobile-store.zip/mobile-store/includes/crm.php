<?php
/**
 * ماژول CRM (مدیریت ارتباط با مشتری)
 *  - جدول crm_contacts: مشتریان و سرنخ‌ها (مرحله، منبع، برچسب، یادداشت، تاریخ پیگیری بعدی)
 *  - جدول crm_activities: تاریخچه‌ی تماس، پیامک، ایمیل، جلسه و یادداشت برای هر مشتری
 *  - همگام‌سازی خودکار از کاربران سایت، سفارش‌ها (مهمان‌ها) و پیام‌های فرم «تماس با ما»
 * جدول‌ها در اولین ورود به صفحه‌ی CRM خودکار ساخته می‌شوند (مثل ماژول ایمیل).
 */
require_once __DIR__ . '/../config/site.php';
require_once __DIR__ . '/coupons.php';   // fa_digits / en_digits / jalali_str / jalali_to_date

// ════════════════════════════════════════════════════════════
//  تعریف‌ها
// ════════════════════════════════════════════════════════════
function crm_stages() {
    return [
        'lead'     => ['🌱 سرنخ',        'bg-sky-100 text-sky-700'],
        'prospect' => ['🤝 در حال مذاکره', 'bg-violet-100 text-violet-700'],
        'customer' => ['✅ مشتری',        'bg-emerald-100 text-emerald-700'],
        'vip'      => ['👑 مشتری ویژه',   'bg-amber-100 text-amber-700'],
        'inactive' => ['💤 غیرفعال',      'bg-slate-200 text-slate-600'],
    ];
}
function crm_activity_types() {
    return [
        'call'    => '📞 تماس تلفنی',
        'sms'     => '💬 پیامک',
        'email'   => '✉️ ایمیل',
        'meeting' => '🏪 جلسه / مراجعه حضوری',
        'note'    => '📝 یادداشت',
    ];
}
function crm_sources() {
    return ['manual' => 'دستی', 'user' => 'ثبت‌نام در سایت', 'order' => 'سفارش', 'contact_form' => 'فرم تماس', 'import' => 'ورود از فایل'];
}

// ════════════════════════════════════════════════════════════
//  ساخت جدول‌ها
// ════════════════════════════════════════════════════════════
function crm_ensure(PDO $pdo) {
    static $done = false;
    if ($done) return;
    $done = true;
    if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) !== 'mysql') return;
    $pdo->exec("CREATE TABLE IF NOT EXISTS crm_contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NULL,
        name VARCHAR(150) NOT NULL,
        phone VARCHAR(30) NULL,
        email VARCHAR(190) NULL,
        city VARCHAR(80) NULL,
        stage VARCHAR(20) NOT NULL DEFAULT 'lead',
        source VARCHAR(20) NOT NULL DEFAULT 'manual',
        tags VARCHAR(255) NULL,
        notes TEXT NULL,
        next_followup DATE NULL,
        last_contact_at DATETIME NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        KEY idx_phone (phone),
        KEY idx_email (email),
        KEY idx_user (user_id),
        KEY idx_stage (stage),
        KEY idx_followup (next_followup)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS crm_activities (
        id INT AUTO_INCREMENT PRIMARY KEY,
        contact_id INT NOT NULL,
        type VARCHAR(20) NOT NULL DEFAULT 'note',
        note TEXT NULL,
        created_at DATETIME NOT NULL,
        KEY idx_contact (contact_id, id),
        CONSTRAINT fk_crm_act_contact FOREIGN KEY (contact_id) REFERENCES crm_contacts(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");
}

// ════════════════════════════════════════════════════════════
//  ابزارهای کمکی
// ════════════════════════════════════════════════════════════
/** شماره موبایل ایران → 09123456789 (اگر قابل تشخیص نبود، فقط ارقام برگردانده می‌شود) */
function crm_norm_phone($p) {
    $p = preg_replace('/\D+/', '', en_digits((string)$p));
    if ($p === '') return '';
    if (strpos($p, '0098') === 0) $p = '0' . substr($p, 4);
    elseif (strpos($p, '98') === 0 && strlen($p) === 12) $p = '0' . substr($p, 2);
    elseif (strlen($p) === 10 && $p[0] === '9') $p = '0' . $p;
    return $p;
}
function crm_norm_email($e) {
    $e = mb_strtolower(trim((string)$e));
    return filter_var($e, FILTER_VALIDATE_EMAIL) ? $e : '';
}
/** برچسب‌ها: جداشده با «،» یا «,» → رشته‌ی تمیز */
function crm_clean_tags($s) {
    $parts = preg_split('/[,،\n]+/u', (string)$s);
    $out = [];
    foreach ($parts as $t) {
        $t = trim(mb_substr(trim($t), 0, 30));
        if ($t !== '' && !in_array($t, $out, true)) $out[] = $t;
        if (count($out) >= 10) break;
    }
    return implode('،', $out);
}
function crm_tag_list($s) {
    return array_values(array_filter(array_map('trim', preg_split('/[,،]+/u', (string)$s)), 'strlen'));
}
function crm_now() { return date('Y-m-d H:i:s'); }

// ════════════════════════════════════════════════════════════
//  آمار سفارش‌ها (تطبیق با کاربر، موبایل یا ایمیل)
// ════════════════════════════════════════════════════════════
function crm_order_index(PDO $pdo) {
    static $idx = null;
    if ($idx !== null) return $idx;
    $idx = ['orders' => [], 'user' => [], 'phone' => [], 'email' => []];
    try {
        $rows = $pdo->query("SELECT id, order_code, user_id, phone, email, total, status, created_at FROM orders ORDER BY id DESC")->fetchAll();
    } catch (Throwable $e) { return $idx; }
    foreach ($rows as $o) {
        $id = (int)$o['id'];
        $idx['orders'][$id] = $o;
        if ($o['user_id']) $idx['user'][(int)$o['user_id']][] = $id;
        if ($ph = crm_norm_phone($o['phone'])) $idx['phone'][$ph][] = $id;
        if ($em = crm_norm_email($o['email'])) $idx['email'][$em][] = $id;
    }
    return $idx;
}
/** سفارش‌های یک مشتری (بدون تکرار، جدیدترین اول) */
function crm_contact_orders(PDO $pdo, array $c) {
    $idx = crm_order_index($pdo);
    $ids = [];
    if (!empty($c['user_id']) && isset($idx['user'][(int)$c['user_id']])) $ids = array_merge($ids, $idx['user'][(int)$c['user_id']]);
    if (($ph = crm_norm_phone($c['phone'] ?? '')) && isset($idx['phone'][$ph])) $ids = array_merge($ids, $idx['phone'][$ph]);
    if (($em = crm_norm_email($c['email'] ?? '')) && isset($idx['email'][$em])) $ids = array_merge($ids, $idx['email'][$em]);
    $ids = array_unique($ids);
    rsort($ids);
    return array_map(function ($id) use ($idx) { return $idx['orders'][$id]; }, $ids);
}
/** [تعداد سفارش غیرلغوشده، جمع خرید، تاریخ آخرین سفارش] */
function crm_order_stats(array $orders) {
    $n = 0; $sum = 0; $last = null;
    foreach ($orders as $o) {
        if ($o['status'] === 'cancelled') continue;
        $n++; $sum += (float)$o['total'];
        if ($last === null || $o['created_at'] > $last) $last = $o['created_at'];
    }
    return [$n, $sum, $last];
}

// ════════════════════════════════════════════════════════════
//  همگام‌سازی از کاربران، سفارش‌ها و پیام‌های فرم تماس
//  فقط مشتری‌های جدید اضافه می‌شوند؛ اطلاعات ثبت‌شده‌ی مدیر هیچ‌وقت بازنویسی نمی‌شود.
//  خروجی: [تعداد افزوده‌شده، تعداد ارتقا به «مشتری»]
// ════════════════════════════════════════════════════════════
function crm_sync(PDO $pdo) {
    crm_ensure($pdo);
    $now = crm_now();

    // نقشه‌ی مشتری‌های موجود
    $byUser = []; $byPhone = []; $byEmail = [];
    foreach ($pdo->query("SELECT id, user_id, phone, email FROM crm_contacts")->fetchAll() as $c) {
        if ($c['user_id']) $byUser[(int)$c['user_id']] = (int)$c['id'];
        if ($p = crm_norm_phone($c['phone'])) $byPhone[$p] = (int)$c['id'];
        if ($e = crm_norm_email($c['email'])) $byEmail[$e] = (int)$c['id'];
    }
    $ins = $pdo->prepare("INSERT INTO crm_contacts (user_id, name, phone, email, city, stage, source, created_at, updated_at)
                          VALUES (?,?,?,?,?,?,?,?,?)");
    $added = 0;
    $add = function ($userId, $name, $phone, $email, $city, $stage, $source, $createdAt) use ($pdo, &$byUser, &$byPhone, &$byEmail, $ins, $now, &$added) {
        $phone = crm_norm_phone($phone); $email = crm_norm_email($email);
        if ($userId && isset($byUser[$userId])) return;
        if ($phone && isset($byPhone[$phone])) return;
        if ($email && isset($byEmail[$email])) return;
        $name = trim((string)$name);
        if ($name === '') $name = $phone ?: ($email ?: 'بدون نام');
        if (!$phone && !$email && !$userId) return;   // هیچ راه ارتباطی ندارد
        $ins->execute([$userId ?: null, mb_substr($name, 0, 150), $phone ?: null, $email ?: null,
            $city ? mb_substr((string)$city, 0, 80) : null, $stage, $source, $createdAt ?: $now, $now]);
        $id = (int)$pdo->lastInsertId();
        if ($userId) $byUser[$userId] = $id;
        if ($phone) $byPhone[$phone] = $id;
        if ($email) $byEmail[$email] = $id;
        $added++;
    };

    // ۱) کاربران ثبت‌نام‌شده (به‌جز مدیران)
    foreach ($pdo->query("SELECT id, name, email, phone, created_at FROM users WHERE role <> 'admin'")->fetchAll() as $u) {
        $add((int)$u['id'], $u['name'], $u['phone'], $u['email'], null, 'lead', 'user', $u['created_at']);
    }
    // ۲) خریداران مهمان / سفارش‌ها
    try {
        foreach ($pdo->query("SELECT user_id, customer_name, phone, email, city, created_at FROM orders WHERE status <> 'cancelled' ORDER BY id")->fetchAll() as $o) {
            $add($o['user_id'] ? (int)$o['user_id'] : 0, $o['customer_name'], $o['phone'], $o['email'], $o['city'], 'customer', 'order', $o['created_at']);
        }
    } catch (Throwable $e) {}
    // ۳) پیام‌های فرم «تماس با ما»
    try {
        foreach ($pdo->query("SELECT from_name, phone, from_email, created_at FROM mail_messages WHERE direction='in' AND source='contact_form' ORDER BY id")->fetchAll() as $m) {
            $add(0, $m['from_name'], $m['phone'], $m['from_email'], null, 'lead', 'contact_form', $m['created_at']);
        }
    } catch (Throwable $e) {}

    // ۴) سرنخ‌هایی که سفارش ثبت کرده‌اند → «مشتری»
    $promoted = 0;
    $idx = crm_order_index($pdo);
    $leads = $pdo->query("SELECT id, user_id, phone, email FROM crm_contacts WHERE stage IN ('lead','prospect')")->fetchAll();
    $up = $pdo->prepare("UPDATE crm_contacts SET stage='customer', updated_at=? WHERE id=?");
    foreach ($leads as $c) {
        [$n] = crm_order_stats(crm_contact_orders($pdo, $c));
        if ($n > 0) { $up->execute([$now, $c['id']]); $promoted++; }
    }
    return [$added, $promoted];
}

// ════════════════════════════════════════════════════════════
//  شمارنده‌ها (برای داشبورد و صفحه‌ی CRM)
// ════════════════════════════════════════════════════════════
/** تعداد پیگیری‌هایی که موعدشان امروز یا گذشته است */
function crm_due_count(PDO $pdo) {
    try {
        crm_ensure($pdo);
        $st = $pdo->prepare("SELECT COUNT(*) FROM crm_contacts WHERE next_followup IS NOT NULL AND next_followup <= ? AND stage <> 'inactive'");
        $st->execute([date('Y-m-d')]);
        return (int)$st->fetchColumn();
    } catch (Throwable $e) { return 0; }
}

// ════════════════════════════════════════════════════════════
//  فیلتر لیست (مشترک بین صفحه‌ی لیست و چاپ)
//  خروجی: [شرط WHERE، پارامترها، ORDER BY]
// ════════════════════════════════════════════════════════════
function crm_list_filter($q, $stage, $due) {
    $where = ['1=1']; $params = [];
    if ($stage !== '') { $where[] = 'stage = ?'; $params[] = $stage; }
    if ($due) { $where[] = "next_followup IS NOT NULL AND next_followup <= ? AND stage <> 'inactive'"; $params[] = date('Y-m-d'); }
    if ($q !== '') {
        $qq = '%' . $q . '%'; $np = crm_norm_phone($q);
        $where[] = '(name LIKE ? OR phone LIKE ? OR email LIKE ? OR city LIKE ? OR tags LIKE ? OR notes LIKE ?)';
        array_push($params, $qq, $np !== '' ? '%' . $np . '%' : $qq, $qq, $qq, $qq, $qq);
    }
    return [implode(' AND ', $where), $params, $due ? 'next_followup ASC, id DESC' : 'updated_at DESC, id DESC'];
}
